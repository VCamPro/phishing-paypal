/*! 2024 dl-pp-latm@paypal.com ver(1.0.8) */
/*
* mktconf.js v1.0.8 - 10-17-2024
* Copyright (c) 2024 dl-pp-latm@paypal.com
*/
(function () {
    'use strict';

    (function () {

      function _iterableToArrayLimit(arr, i) {
        var _i = null == arr ? null : 'undefined' != typeof Symbol && arr[Symbol.iterator] || arr['@@iterator'];
        if (null != _i) {
          var _s,
            _e,
            _x,
            _r,
            _arr = [],
            _n = !0,
            _d = !1;
          try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
              if (Object(_i) !== _i) return;
              _n = !1;
            } else for (; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
          } catch (err) {
            _d = !0, _e = err;
          } finally {
            try {
              if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally {
              if (_d) throw _e;
            }
          }
          return _arr;
        }
      }
      function _typeof(obj) {
        '@babel/helpers - typeof';

        return _typeof = 'function' == typeof Symbol && 'symbol' == typeof Symbol.iterator ? function (obj) {
          return typeof obj;
        } : function (obj) {
          return obj && 'function' == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? 'symbol' : typeof obj;
        }, _typeof(obj);
      }
      function _slicedToArray(arr, i) {
        return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
      }
      function _arrayWithHoles(arr) {
        if (Array.isArray(arr)) return arr;
      }
      function _unsupportedIterableToArray(o, minLen) {
        if (!o) return;
        if (typeof o === 'string') return _arrayLikeToArray(o, minLen);
        var n = Object.prototype.toString.call(o).slice(8, -1);
        if (n === 'Object' && o.constructor) n = o.constructor.name;
        if (n === 'Map' || n === 'Set') return Array.from(o);
        if (n === 'Arguments' || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
      }
      function _arrayLikeToArray(arr, len) {
        if (len == null || len > arr.length) len = arr.length;
        for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
        return arr2;
      }
      function _nonIterableRest() {
        throw new TypeError('Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.');
      }
      var mktconf = window.mktconf = window.mktconf || {};
      mktconf.loadRedactRegEx = function () {
        return {
          redactedEmail: /([a-z0-9_\-.+]+)@\w+(\.\w+)*|(email=)[^&/?]+/gi,
          redactedUSSSN: /(\b\d{3}[ -.]\d{2}[ -.]\d{4}\b)|(SSN=)[^&/?]+/gi,
          redactedIPAddress: /(\d{1,3}(\.\d{1,3}){3}|[0-9A-F]{4}(:[0-9A-F]{4}){5}(::|(:0000)+)|(IPAddress)[^&/?]+)/gi,
          redactedZipCode: /((postcode=)|(zipcode=)|(zip=))[^&/?]+/gi,
          redactedUserName: /((username=)|(login=)|(userid))[^&/?]+/gi,
          redactedPassword: /((password=)|(passwd=)|(pass=))[^&/?]+/gi,
          redactedCredentials: /(login( cred(ential)?s| info(rmation)?)?|cred(ential)?s) ?:\s*\S+\s+\/?\s*\S+/gi,
          redactedVisaCreditCard: /\b4[0-9]{12}(?:[0-9]{3})?\b/gi,
          redactedDinersCard: /\b3(?:0[0-5]|[68][0-9])[0-9]{11}\b/gi,
          redactedMasterCard: /\b(?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12}\b/gi,
          redactedAmexCard: /\b3[47][0-9]{13}\b/gi,
          redactedDiscoverCard: /\b6(?:011|5[0-9]{2})[0-9]{12}\b/gi,
          redactedTelNumber: /((tel=)|(telephone=)|(phone=)|(mobile=)|(mob=))[\d+\s][^&/?]+/gi,
          redactedName: /((firstname=)|(first_name=)|(lastname=)|(last_name=)|(name=)|(surname=))[^&/?]+/gi,
          redactedLocation: /((location=)|(location_lng=)|(location_lat=)|(longitude=)|(latitude=))[^&/?]+/gi
        };
      };
      var FraudnetPageRegEx = /walletweb:.*bank:confirminstantly/i;
      mktconf.isFNEnabled = function (page) {
        var isEnabled = false;
        if (FraudnetPageRegEx.test(page || '')) {
          isEnabled = true;
        }
        return isEnabled;
      };
      var compByURLPath = {
        '/myaccount/summary': 'summarynodeweb'
      };
      mktconf.initCompByURLPath = function () {
        var path = window.location.pathname;
        var normalizedPath = path.replace(/\/+$/, '');
        if (compByURLPath[normalizedPath]) {
          return compByURLPath[normalizedPath];
        }
        for (var _i = 0, _Object$entries = Object.entries(compByURLPath); _i < _Object$entries.length; _i++) {
          var _Object$entries$_i = _slicedToArray(_Object$entries[_i], 2),
            key = _Object$entries$_i[0],
            value = _Object$entries$_i[1];
          var regex = new RegExp('^'.concat(key));
          if (regex.test(normalizedPath)) {
            return value;
          }
        }
        return '';
      };
      var pers_acc_upg_fin = {
        'name': 'pers_acc_upg_fin',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:business:activation:businessSetup|main:onbrd:falconnode::(done|congrats(default|partner|)|partnerDone)|main:activation:commercesetupnodeweb'
          },
          'session': {
            'key': 'persupg',
            'type': 'end'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch0/acctu00+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Enh-CNWuz9gBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/Ez7PCNGbz9gBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/HzDvCLaDz9gBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/jM6-CMG8v9gBEJy7qMwD'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant upgrade',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 8: congrats',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Thanks for signing up',
            'dimension9': 'step 8: congrats',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }]
      };
      var biz_acc_su_end = {
        'name': 'biz_acc_su_end',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:business:activation:businessSetup|main:onbrd:falconnode::(done|congrats(default|partner|)|partnerDone)|main:activation:commercesetupnodeweb'
          },
          'session': {
            'key': 'mercsu',
            'type': 'end'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch0/bizac00+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Mrs6CKX83dgBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/GaLzCKKQz9gBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/1_qJCLD6ztgBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/pnOjCJ70ztgBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'MerchantSignup'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: MerchantSUFin',
            'event_action': 'sign up finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 8: congrats',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Thanks for signing up',
            'dimension9': 'step 8: congrats',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantaccountsignupfinish'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_MSU_SIGNUP_FINISH',
            'event_category': 'MerchantSUFin',
            'event_action': 'MerchantSUFin',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var pwd_recovery_start = {
        'name': 'pwd_recovery_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:(authflow:(:::|sms_challenge::(enter_security_code|change_sms)|password_recovery::(create_password_done|create_password)|card_challenge::(enter_card_number|change_card)|email_challenge::(enter_security_code|change_email)|ivr_challenge::(ivr_polling|change_ivr)|identity_document_challenge::upload_document|security_questions_challenge::enter_answers)|authchallenge::submit::authflow:password-recovery:change:)'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu000/passw0+standard'
          }
        }]
      };
      var pwd_recovery_end = {
        'name': 'pwd_recovery_end',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:(authchallenge::submit::authflow:(password-recovery:change:|email-recovery:done:)|authflow:(password_recovery::(create_password_done|create_password)|emailrecovery::foundone))'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu000/passw00+standard'
          }
        }]
      };
      var xolite_end_1 = {
        'name': 'xolite_end_1',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:billing:hagrid:billingwithoutpurchase:member:submitButtonFullEvent|main:xo:lite:dumbledore:member:custom-continueButtonApproveMemberPayment|main:subscriptions:createsubscriptions:buyerflow:consent:subscriptions_v1:done',
            'flnm': 'Hagrid|Dumbledore|'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/herme00+standard',
            'u2': {
              'type': 'var',
              'path': 'laDataLayer.mrid',
              'defaultVal': 'NA'
            },
            'u3': {
              'type': 'int',
              'path': 'laDataLayer.amt'
            },
            'u4': {
              'type': 'var',
              'path': 'laDataLayer.curr',
              'defaultVal': 'NA'
            },
            'u10': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/w3DCCJKhz9gBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/JdISCJqUz9gBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/jWNpCI3Ev9gBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/lFV9COe4v9gBEJy7qMwD'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'attempted checkout',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.comp',
              'defaultVal': 'unknown'
            },
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.mrid',
              'defaultVal': 'NA'
            },
            'value': {
              'type': 'int',
              'path': 'laDataLayer.amt'
            },
            'dimension6': {
              'type': 'var',
              'path': 'laDataLayer.rsta'
            },
            'dimension23': {
              'type': 'var',
              'path': 'laDataLayer.flnm',
              'defaultVal': 'Hermione'
            },
            'dimension24': {
              'type': 'var',
              'path': 'laDataLayer.curr',
              'defaultVal': 'NA'
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_TXN_CONSXO_FIN',
            'event_category': 'attempted checkout',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.comp',
              'defaultVal': 'unknown'
            },
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.mrid',
              'defaultVal': 'NA'
            },
            'value': {
              'type': 'int',
              'path': 'laDataLayer.amt'
            },
            'dimension6': {
              'type': 'var',
              'path': 'laDataLayer.rsta'
            },
            'dimension23': {
              'type': 'var',
              'path': 'laDataLayer.flnm',
              'defaultVal': 'Hermione'
            },
            'dimension24': {
              'type': 'var',
              'path': 'laDataLayer.curr',
              'defaultVal': 'NA'
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: HermesFlowTxnFin',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.comp',
              'defaultVal': 'unknown'
            },
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.mrid',
              'defaultVal': 'NA'
            },
            'value': {
              'type': 'int',
              'path': 'laDataLayer.amt'
            },
            'dimension6': {
              'type': 'var',
              'path': 'laDataLayer.rsta'
            },
            'dimension23': {
              'type': 'var',
              'path': 'laDataLayer.flnm',
              'defaultVal': 'Hermione'
            },
            'dimension24': {
              'type': 'var',
              'path': 'laDataLayer.curr',
              'defaultVal': 'NA'
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'Transaction-HermesFlowTxnEnd-HermesFlow',
            'cd[MerchantID]': {
              'type': 'var',
              'path': 'laDataLayer.mrid',
              'defaultVal': 'NA'
            },
            'cd[MerchantTPV]': {
              'type': 'int',
              'path': 'laDataLayer.amt'
            },
            'cd[MerchantTransaction]': {
              'type': 'var',
              'path': 'laDataLayer.curr',
              'defaultVal': 'NA'
            }
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_US'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['de|uk|gb', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_EMEA'
          }
        }]
      };
      var mer_mx_installment = {
        'name': 'mer_mx_installment',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['mx|br', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:businessweb:profile::main:installmentSelection',
            'isInstActive': 'true'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/pp_la0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant installments',
            'event_action': 'enable installments',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/3fT1CP6G99MCELXZ6tkD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'MERCHANT_INSTALLMENT_ENABLE'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantinstallmentenable'
          }
        }]
      };
      var pro_su_start = {
        'name': 'pro_su_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:onbrd:falconnode::checkAccount',
            'prod': 'pro_2_0|pro_3_0'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch00/merch001+standard'
          }
        }]
      };
      var pro_su_end_app = {
        'name': 'pro_su_end_app',
        'trigger': {
          'type': 'fn',
          'name': 'matchPgTxt',
          'sel': '.statusHeader',
          'text': 'success'
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch00/merch0+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/t_vyCLyvstwBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/LzQ3CMmtstwBEKv66t8D'
          }
        }]
      };
      var pro_su_end_rev = {
        'name': 'pro_su_end_rev',
        'trigger': {
          'type': 'fn',
          'name': 'matchPgTxt',
          'sel': '.statusHeader',
          'text': 'review'
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch00/merch00+standard'
          }
        }]
      };
      var pro_su_end_dec = {
        'name': 'pro_su_end_dec',
        'trigger': {
          'type': 'fn',
          'name': 'matchPgTxt',
          'sel': '.statusHeader',
          'text': 'decline'
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch00/merch000+standard'
          }
        }]
      };
      var biz_check_acc = {
        'name': 'biz_check_acc',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:onbrd:falconnode::checkAccount'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 3: enter email address',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Check Account',
            'dimension9': 'step 3: enter email address',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }]
      };
      var biz_create_pwd = {
        'name': 'biz_create_pwd',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:onbrd:falconnode::createPassword'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 4: enter password',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Create Password',
            'dimension9': 'step 4: enter password',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }]
      };
      var biz_acc_su_start = {
        'name': 'biz_acc_su_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:onbrd:falconnode::create$|main:onbrd:falconnode::singlePageSignup'
          },
          'session': {
            'key': 'mercsu',
            'type': 'start'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch0/bizac0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: MerchantSUStart',
            'event_action': 'sign up start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 5: enter business info and account created',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Create Business Account',
            'dimension8': 'active',
            'dimension9': 'step 5: enter business info and account created',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            },
            'dimension46': 'true'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/po-UCKKa--ABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/-CfpCL-v4OABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/VjrHCNvj6-ABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/Au6mCJma--ABEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantaccountsignupstart'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_MSU_SIGNUP_START',
            'event_category': 'MerchantSUStart',
            'event_action': 'MerchantSUStart',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var biz_bus_info = {
        'name': 'biz_bus_info',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:onbrd:falconnode::businessinfo'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 6: select business type',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Enter Business Info',
            'dimension9': 'step 6: select business type',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }]
      };
      var biz_pers_info = {
        'name': 'biz_pers_info',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:onbrd:falconnode::personalInfo'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 7: enter personal info',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Enter Personal Info',
            'dimension9': 'step 7: enter personal info',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }]
      };
      var pers_acc_upg_start = {
        'name': 'pers_acc_upg_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:onbrd:falconnode::(upgradeBusinessAccount|businessTypeSelection|upgradeDecision|upgradeBusinessTypeSelection|businessInfo)',
            'acnt': 'personal|premier'
          },
          'session': {
            'key': 'persupg',
            'type': 'start'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch0/acctu0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant upgrade',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 1: upgrade to business account',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Upgrade to Business Account',
            'dimension9': 'step 1: upgrade to business account',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/JidPCN39_OABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/uYKZCJfF7eABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/IuC7CM_E7eABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/mcsACLXF7eABEJy7qMwD'
          }
        }]
      };
      var biz_acc_su_minimal_acc = {
        'name': 'biz_acc_su_minimal_acc',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:onbrd:falconnode::getStarted|main:onbrd:falconnode::welcome',
            'status': 'min_account_created|unactivated_account_created'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch0/pp_gb0+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/SW16CLSf2a4DEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/M4QKCJa02a4DELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/Ln4hCM3M3a4DEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/Bc0zCNCtpa4DEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'FB_MERCHANTMINIMALACCOUNT'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'Merchant Sign UP',
            'event_action': 'Minimal account setup',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantminimalaccount'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_MER_MINACC_SETUP',
            'event_category': 'Merchant Sign UP',
            'event_action': 'MerchantSUMINACC',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var biz_acc_su_minimal_oldflow = {
        'name': 'biz_acc_su_minimal_oldflow',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:onbrd:falconnode::businessInfo',
            'status': 'min_account_created'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch0/pp_gb0+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/SW16CLSf2a4DEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/M4QKCJa02a4DELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/Ln4hCM3M3a4DEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/Bc0zCNCtpa4DEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'FB_MERCHANTMINIMALACCOUNT'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'Merchant Sign UP',
            'event_action': 'Minimal account setup',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantminimalaccount'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_MER_MINACC_SETUP',
            'event_category': 'Merchant Sign UP',
            'event_action': 'MerchantSUMINACC',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var oct_flow_start = {
        'name': 'oct_flow_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:businessweb:money:transfer:main:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/merch0+standard'
          }
        }]
      };
      var oct_flow_end = {
        'name': 'oct_flow_end',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'fltp': 'oct_flow',
            'pgrp': 'main:businessweb:money:transfer:success'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/merch00+standard'
          }
        }]
      };
      var ln_click = {
        'name': 'ln_click',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl'
          },
          'once': false
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'in-page link tracking',
            'event_action': {
              'type': 'var',
              'obj': 'data',
              'path': 'link'
            },
            'event_label': {
              'type': 'var',
              'obj': 'data',
              'path': 'lu'
            }
          }
        }]
      };
      var form_submit = {
        'name': 'form_submit',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'fs',
            'flnm': 'form_submit',
            'status': 'success'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': {
              'type': 'var',
              'obj': 'data',
              'path': 'ec',
              'defaultVal': 'forms'
            },
            'event_action': {
              'type': 'var',
              'obj': 'data',
              'path': 'ea',
              'defaultVal': 'submit'
            },
            'event_label': {
              'type': 'var',
              'obj': 'data',
              'path': 'el',
              'defaultVal': 'generic'
            }
          }
        }]
      };
      var pardot_im_event = {
        'name': 'pardot_im_event',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im'
          }
        },
        'vendors': [{
          'name': 'pd',
          'vars': {
            'piAId': '926803',
            'piCId': '5717'
          }
        }]
      };
      var brc_aoc_landing = {
        'name': 'brc_aoc_landing',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['sg|sk|jp|br|mx|c2|hk', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:help:brc::brcArticle:improve-website-ux:::|main:help:brc::brcArticle:protect-your-business-from-cybercrime:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/pp_ap0+standard'
          }
        }]
      };
      var scroll_event = {
        'name': 'scroll_event',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'sd',
            'st': 'percent'
          },
          'once': false
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'scroll',
            'event_action': {
              'type': 'var',
              'obj': 'data',
              'path': 'sd',
              'defaultVal': '0',
              'concat': {
                'append': ' percent scrolled'
              }
            },
            'event_label': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_scrolldepth'
          }
        }]
      };
      var ppcom_money_hub_viewed_event = {
        'name': 'ppcom_money_hub_viewed_event',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:moneyhub:home:::',
            'event_name': 'ppcom_moneyhub_page_viewed'
          }
        },
        'vendors': [{
          'name': 'adobe'
        }]
      };
      var ppcom_header_signin_signup_clicked = {
        'name': 'ppcom_header_signin_signup_clicked',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg:personal:homepage:home:::|main:mktg:personal:homepage:home-uncookied-consumer:::|main:mktg:personal:homepage:home-cookied-consumer:::|main:mktg:personal:product:digital-wallet-how-paypal-works:::|main:mktg:personal:product:digital-wallet-ways-to-pay:::|main:mktg:personal:product:digital-wallet-ways-to-pay/buy-now-pay-later:::|main:mktg:personal:product:digital-wallet-rewards:::|main:mktg:personal:product:digital-wallet-ways-to-pay/credit-services:::|main:mktg:personal:product:digital-wallet-ways-to-pay/checkout-with-paypal:::|main:mktg:personal:product:digital-wallet:::|main:mktg:personal:product:digital-wallet-send-receive-money:::|main:mktg:personal:product:digital-wallet-send-receive-money/send-money:::|main:mktg:personal:product:digital-wallet-send-receive-money/request-money:::|main:mktg:personal:product:digital-wallet-send-receive-money/giving:::|main:mktg:personal:product:digital-wallet-send-receive-money/start-selling:::|main:mktg:personal:product:digital-wallet-manage-money:::|main:mktg:personal:product:digital-wallet-ways-to-pay/add-payment-method:::|main:mktg:personal:security:digital-wallet-security-and-protection:::|main:mktg:personal:product:digital-wallet-manage-money/direct-deposit:::|main:mktg:personal:product:digital-wallet-manage-money/add-cash:::|main:mktg:personal:product:digital-wallet-manage-money/pay-bills:::|main:mktg:personal:product:digital-wallet-manage-money/start-saving:::|main:mktg:personal:product:digital-wallet-manage-money/crypto:::|main:mktg:moneyhub:home:::|main:mktg:both:product:account-selection',
            'event_name': 'ppcom_header_login_clicked|ppcom_header_signup_clicked'
          }
        },
        'vendors': [{
          'name': 'adobe'
        }]
      };
      var ppcom_hero_button_clicked = {
        'name': 'ppcom_hero_button_clicked',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg:personal:homepage:home:::|main:mktg:personal:homepage:home-uncookied-consumer:::|main:mktg:personal:homepage:home-cookied-consumer:::|main:mktg:personal:product:digital-wallet-how-paypal-works:::|main:mktg:personal:product:digital-wallet-ways-to-pay:::|main:mktg:personal:product:digital-wallet-ways-to-pay/buy-now-pay-later:::|main:mktg:personal:product:digital-wallet-rewards:::|main:mktg:personal:product:digital-wallet-ways-to-pay/credit-services:::|main:mktg:personal:product:digital-wallet-ways-to-pay/checkout-with-paypal:::|main:mktg:personal:product:digital-wallet:::|main:mktg:personal:product:digital-wallet-send-receive-money:::|main:mktg:personal:product:digital-wallet-send-receive-money/send-money:::|main:mktg:personal:product:digital-wallet-send-receive-money/request-money:::|main:mktg:personal:product:digital-wallet-send-receive-money/giving:::|main:mktg:personal:product:digital-wallet-send-receive-money/start-selling:::|main:mktg:personal:product:digital-wallet-manage-money:::|main:mktg:personal:product:digital-wallet-ways-to-pay/add-payment-method:::|main:mktg:personal:security:digital-wallet-security-and-protection:::|main:mktg:personal:product:digital-wallet-manage-money/direct-deposit:::|main:mktg:personal:product:digital-wallet-manage-money/add-cash:::|main:mktg:personal:product:digital-wallet-manage-money/pay-bills:::|main:mktg:personal:product:digital-wallet-manage-money/start-saving:::|main:mktg:personal:product:digital-wallet-manage-money/crypto:::|main:mktg:moneyhub:home:::|main:mktg:both:product:account-selection',
            'link': '^Hero'
          }
        },
        'vendors': [{
          'name': 'adobe'
        }]
      };
      var setup_xo = {
        'name': 'setup_xo',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:buttonfactory:setup_checkout_exp'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/pp_gb006+standard'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_checkoutbuttonfinish'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/checkoutbuttonfinish'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'checkout exp',
            'event_action': 'click on Copy Code',
            'event_label': 'buttonfactory setup-checkout exp'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/F_tdCMiAyIACEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/QO4XCLfA54ACELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/4SpZCJaByIACEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/Kc06CImGyIACEJy7qMwD'
          }
        }]
      };
      var cape_cc_application_start = {
        'name': 'cape_cc_application_start',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'event_name': 'cbcc_applctn_billing_info_page_shown',
            'page': 'capeuinodeweb/index.dust|capeui/credit-application/co/billing'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu002/pp_na0+standard'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-992191228/qkyKCLuY5boDEPzFjtkD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/consumercreditcardapplicationstart'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'Consumer Credit Card',
            'event_action': 'Application Start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_consumercreditcardapplicationstart'
          }
        }]
      };
      var cape_cc_application_finish = {
        'name': 'cape_cc_application_finish',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'event_name': 'cbcc_applctn_accept_terms_and_apply_pressed',
            'page': 'capeuinodeweb/index.dust|capeui/credit-application/co/terms'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu002/pp_na00+standard'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-992191228/BoQzCOjCsboDEPzFjtkD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/consumercreditcardapplicationfinish'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'Consumer Credit Card',
            'event_action': 'Application Finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_consumercreditcardapplicationfinish'
          }
        }]
      };
      var cape_cc_application_approved = {
        'name': 'cape_cc_application_approved',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'event_name': 'cbcc_applctn_decision_approved_page_shown',
            'page': 'capeuinodeweb/index.dust|capeui/credit-application/co/decision'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu002/pp_na000+standard'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-992191228/RNusCP6u5boDEPzFjtkD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/consumercreditcardapplicationapproved'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'Consumer Credit Card',
            'event_action': 'Application Approved',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_consumercreditcardapplicationapproved'
          }
        }]
      };
      var credit_app_start_new = {
        'name': 'credit_app_start_new',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'capeuinodeweb/index.dust|capeui/credit-application/paypal-credit/da/us/billing',
            'event_name': 'usppc_billing_info_shown'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu002/ppcre0+standard',
            'u1': {
              'type': 'var',
              'path': ['ensighten.buyerId', 'buyerId', 'fpti.cust']
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PPCreditAppStart',
            'event_action': 'start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer credit',
            'event_action': 'step 1: billing info',
            'event_label': 'application start',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Confirm Billing Info'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/QWdLCOPLgZQDEPzFjtkD'
          }
        }]
      };
      var credit_app_succ_new = {
        'name': 'credit_app_succ_new',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'capeuinodeweb/index.dust|capeui/credit-application/paypal-credit/da/us/decision',
            'event_name': 'usppc_approval_page_shown'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu002/ppcre00+standard',
            'u1': {
              'type': 'var',
              'path': ['ensighten.buyerId', 'buyerId', 'fpti.cust']
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'ProductSignup-CreditApproved-PayPalCreditApply'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PPCreditAppFinApproved',
            'event_action': 'finish approved',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer credit',
            'event_action': 'step 4: decision',
            'event_label': 'approved',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Decision Page'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ADON_PPCREDIT_APPLICATN_FINAPPROVED_US',
            'event_category': 'consumer credit',
            'event_action': 'step 4: decision',
            'event_label': 'approved',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Decision Page'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/ns46CLP1sNwBEPzFjtkD'
          }
        }]
      };
      var appr_uk_2 = {
        'name': 'appr_uk_2',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['gb|uk', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'capeui/credit-application/paypal-credit/da/gb/credit-offer',
            'event_name': 'step5_shown'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu003/ppcre00+standard',
            'u1': {
              'type': 'var',
              'path': ['ensighten.buyerId', 'buyerId', 'fpti.cust']
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer credit',
            'event_action': 'step 3: terms and conditions',
            'event_label': 'show terms and conditions',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Review Terms and Conditions'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/5KGaCKLWzdwBEKv66t8D'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'ProductSignup-CreditApproved-PayPalCreditApply'
          }
        }]
      };
      var succ_end_uk_2 = {
        'name': 'succ_end_uk_2',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['gb|uk', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'capeui/credit-application/paypal-credit/da/gb/credit-agreement',
            'event_name': 'sign_contract_click'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu002/ppcre003+standard',
            'u1': {
              'type': 'var',
              'path': ['ensighten.buyerId', 'buyerId', 'fpti.cust']
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_UKCreditApplicationFinish'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer credit',
            'event_action': 'step 4: decision',
            'event_label': 'approved',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Decision Page'
          }
        }]
      };
      var start_uk_2 = {
        'name': 'start_uk_2',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['gb|uk', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'capeui/credit-application/paypal-credit/da/gb/personal',
            'event_name': 'step1_shown'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu002/ppcre002+standard',
            'u1': {
              'type': 'var',
              'path': ['ensighten.buyerId', 'buyerId', 'fpti.cust']
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_UKCreditApplicationStart'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer credit',
            'event_action': 'step 1: billing info',
            'event_label': 'application start',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Confirm Billing Info'
          }
        }]
      };
      var dec_end_uk = {
        'name': 'dec_end_uk',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['gb|uk', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:creditapplyweb:decisionpage:DECLINED::::|capeui/credit-application/paypal-credit/da/gb/decision'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu002/ppcre004+standard',
            'u1': {
              'type': 'var',
              'path': ['ensighten.buyerId', 'buyerId', 'fpti.cust']
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer credit',
            'event_action': 'step 4: decision',
            'event_label': 'declined',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Decision Page'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_UKCreditApplicationDeclined'
          }
        }]
      };
      var fundraiser_setCharity_1 = {
        'name': 'fundraiser_setCharity_1',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'pgrp': 'main:cause:fundraiser:hub:',
            'link': 'featuredCharityHeartClicked',
            'charityFavorited': 'true'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu001/pp_gb0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'Fundraiser',
            'event_action': 'Set Favorite Charity',
            'event_label': {
              'type': 'fn',
              'name': 'fetchSanatizedURL'
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_fundraiser_setfavouritecharity'
          }
        }]
      };
      var fundraiser_setCharity_2 = {
        'name': 'fundraiser_setCharity_2',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'pgrp': 'main:cause:fundraiser:hub:',
            'link': 'npoHeartClicked',
            'npoHeartSelected': 'true'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu001/pp_gb0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'Fundraiser',
            'event_action': 'Set Favorite Charity',
            'event_label': {
              'type': 'fn',
              'name': 'fetchSanatizedURL'
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_fundraiser_setfavouritecharity'
          }
        }]
      };
      var fundraiser_setCharity_3 = {
        'name': 'fundraiser_setCharity_3',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'pgrp': 'main:cause:fundraiser:set-preferred:',
            'link': 'setPreferredCharityConfirmed'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu001/pp_gb0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'Fundraiser',
            'event_action': 'Set Favorite Charity',
            'event_label': {
              'type': 'fn',
              'name': 'fetchSanatizedURL'
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_fundraiser_setfavouritecharity'
          }
        }]
      };
      var donate_cause = {
        'name': 'donate_cause',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:cause:fundraiser:hub:landing|main:cause:fundraiser:hub:search|main:cause:fundraiser:hub:profile',
            'link': 'donateButton'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'donate to charity',
            'event_action': 'donate',
            'event_label': 'finish',
            'event_value': {
              'type': 'int',
              'path': 'laDataLayer.amt'
            }
          }
        }, {
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu001/pp_gb00+standard'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_fundraiser_donatenow'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/TNwhCKT6tLYZEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/vA8FCNeztbYZELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/ZgIPCOqFrLYZEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/sRc3CNOdtbYZEJy7qMwD'
          }
        }]
      };
      var xolite_start = {
        'name': 'xolite_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:xo:lite:hermione:member:review'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/herme0+standard',
            'u2': {
              'type': 'var',
              'path': 'laDataLayer.mrid',
              'defaultVal': 'NA'
            },
            'u3': {
              'type': 'int',
              'path': 'laDataLayer.amt'
            },
            'u4': {
              'type': 'var',
              'path': 'laDataLayer.curr',
              'defaultVal': 'NA'
            },
            'u10': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: HermesFlowTxnStart',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.comp',
              'defaultVal': 'unknown'
            },
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.mrid',
              'defaultVal': 'NA'
            },
            'value': {
              'type': 'int',
              'path': 'laDataLayer.amt'
            },
            'dimension6': {
              'type': 'var',
              'path': 'laDataLayer.rsta'
            },
            'dimension23': {
              'type': 'var',
              'path': 'laDataLayer.flnm',
              'defaultVal': 'Hermione'
            },
            'dimension24': {
              'type': 'var',
              'path': 'laDataLayer.curr',
              'defaultVal': 'NA'
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Qvd-CJi14OABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/6skCCNO04OABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/nOhVCJzp6-ABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/YIRBCKjp6-ABEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_US'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['de|uk|gb', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_EMEA'
          }
        }]
      };
      var xolite_end = {
        'name': 'xolite_end',
        'trigger': {
          'type': 'fn',
          'name': 'handleClick',
          'sel': '#payment-submit-btn'
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/herme00+standard',
            'u2': {
              'type': 'var',
              'path': 'laDataLayer.mrid',
              'defaultVal': 'NA'
            },
            'u3': {
              'type': 'int',
              'path': 'laDataLayer.amt'
            },
            'u4': {
              'type': 'var',
              'path': 'laDataLayer.curr',
              'defaultVal': 'NA'
            },
            'u10': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/w3DCCJKhz9gBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/JdISCJqUz9gBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/jWNpCI3Ev9gBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/lFV9COe4v9gBEJy7qMwD'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'attempted checkout',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.comp',
              'defaultVal': 'unknown'
            },
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.mrid',
              'defaultVal': 'NA'
            },
            'value': {
              'type': 'int',
              'path': 'laDataLayer.amt'
            },
            'dimension6': {
              'type': 'var',
              'path': 'laDataLayer.rsta'
            },
            'dimension23': {
              'type': 'var',
              'path': 'laDataLayer.flnm',
              'defaultVal': 'Hermione'
            },
            'dimension24': {
              'type': 'var',
              'path': 'laDataLayer.curr',
              'defaultVal': 'NA'
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_TXN_CONSXO_FIN',
            'event_category': 'attempted checkout',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.comp',
              'defaultVal': 'unknown'
            },
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.mrid',
              'defaultVal': 'NA'
            },
            'value': {
              'type': 'int',
              'path': 'laDataLayer.amt'
            },
            'dimension6': {
              'type': 'var',
              'path': 'laDataLayer.rsta'
            },
            'dimension23': {
              'type': 'var',
              'path': 'laDataLayer.flnm',
              'defaultVal': 'Hermione'
            },
            'dimension24': {
              'type': 'var',
              'path': 'laDataLayer.curr',
              'defaultVal': 'NA'
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: HermesFlowTxnFin',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.comp',
              'defaultVal': 'unknown'
            },
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.mrid',
              'defaultVal': 'NA'
            },
            'value': {
              'type': 'int',
              'path': 'laDataLayer.amt'
            },
            'dimension6': {
              'type': 'var',
              'path': 'laDataLayer.rsta'
            },
            'dimension23': {
              'type': 'var',
              'path': 'laDataLayer.flnm',
              'defaultVal': 'Hermione'
            },
            'dimension24': {
              'type': 'var',
              'path': 'laDataLayer.curr',
              'defaultVal': 'NA'
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'Transaction-HermesFlowTxnEnd-HermesFlow',
            'cd[MerchantID]': {
              'type': 'var',
              'path': 'laDataLayer.mrid',
              'defaultVal': 'NA'
            },
            'cd[MerchantTPV]': {
              'type': 'int',
              'path': 'laDataLayer.amt'
            },
            'cd[MerchantTransaction]': {
              'type': 'var',
              'path': 'laDataLayer.curr',
              'defaultVal': 'NA'
            }
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_US'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['de|uk|gb', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_EMEA'
          }
        }]
      };
      var checkout_payin4_start = {
        'name': 'checkout_payin4_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:xo:lite:dumbledore:member:review',
            'link': 'process_pay_later',
            'selected_funding_option': 'PAY_LATER_FR|PAY_LATER_US|PAY_LATER_AU'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/pp_na0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'pay in 4',
            'event_action': 'start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ADON_BNPLPAYIN4_ACTVN_STRT',
            'event_category': 'pay in 4',
            'event_action': 'start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/1l2gCJjyussDEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/wBI3CJH3v8sDELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/P9zXCKCDu8sDEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/AswgCIfYv8sDEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_US'
          }
        }]
      };
      var checkout_payin4_finish = {
        'name': 'checkout_payin4_finish',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us|fr|au', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:xo:lite:hermione:member:review|main:xo:lite:dumbledore:member:review',
            'chosen_funding_option': 'pay_in_four'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/pp_na00+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'pay in 4',
            'event_action': 'finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ADON_BNPLPAYIN4_ACTVN_FIN',
            'event_category': 'pay in 4',
            'event_action': 'finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'Transaction-Payin4-complete'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/QkBFCI_MzJQDEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/DkaTCOLvzJQDELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/CM8nCMr11JQDEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/6QBvCKffnpQDEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_US'
          }
        }]
      };
      var checkout_payin3_finish = {
        'name': 'checkout_payin3_finish',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['uk|gb|it|es', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:xo:lite:hermione:member:review|main:xo:lite:dumbledore:member:review',
            'chosen_funding_option': 'pay_in_four'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/pp_em00+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'pay in 3',
            'event_action': 'finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ADON_BNPLPAYIN3_ACTVN_FIN',
            'event_category': 'pay in 3',
            'event_action': 'finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'Transaction-Payin3-complete'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/i3jHCL_F05cYEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/Fv77CI3n2pcYELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/fFT0CK222pcYEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/MkkiCLv93pcYEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['de|uk|gb', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_EMEA'
          }
        }]
      };
      var checkout_payin3_start = {
        'name': 'checkout_payin3_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:xo:lite:dumbledore:member:review',
            'link': 'process_pay_later',
            'selected_funding_option': 'PAY_LATER_GB|PAY_LATER_SHORT_TERM_IT|PAY_LATER_SHORT_TERM_ES'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/pp_em0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'pay in 3',
            'event_action': 'start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ADON_BNPLPAYIN3_ACTVN_STRT',
            'event_category': 'pay in 3',
            'event_action': 'start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/JqDZCL_03ZcYEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/1t5ZCOn93ZcYELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/A7pxCOfL0pcYEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/TfFYCN2J2pcYEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['de|uk|gb', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_EMEA'
          }
        }]
      };
      var checkout_bnpl_iiw_start = {
        'name': 'checkout_bnpl_iiw_start',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['de', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:xo:lite:dumbledore:member:review',
            'link': 'process_pay_later',
            'selected_funding_option': 'PAY_LATER_DE'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/pp_em000+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'Installments in Wallet(IIW)',
            'event_action': 'Txn Start',
            'event_label': 'Pay in 3,6,12,24'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ADON_BNPLPAYIN361224_ACTVN_STRT',
            'event_category': 'Installments in Wallet(IIW)',
            'event_action': 'Txn Start',
            'event_label': 'Pay in 3,6,12,24'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_iiwpayinstart'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/iiwpayinstart'
          }
        }]
      };
      var checkout_bnpl_iiw_finish = {
        'name': 'checkout_bnpl_iiw_finish',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['de', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:xo:lite:dumbledore:member:review',
            'chosen_funding_option': 'pay_in_four'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/pp_em001+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'Installments in Wallet(IIW)',
            'event_action': 'Txn Finish',
            'event_label': 'Pay in 3,6,12,24'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ADON_BNPLPAYIN361224_ACTVN_FIN',
            'event_category': 'Installments in Wallet(IIW)',
            'event_action': 'Txn Finish',
            'event_label': 'Pay in 3,6,12,24'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_iiwpayinfinish'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/iiwpayinfinish'
          }
        }]
      };
      var checkout_payin30_start = {
        'name': 'checkout_payin30_start',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['de', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:xo:lite:dumbledore:member:review',
            'link': 'process_pay_later',
            'selected_funding_option': 'PAY_LATER_PAY_IN_1_DE'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/pp_em002+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'PAY IN 30',
            'event_action': 'Txn Start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_payin30start'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-1006288171/YG3VCPa87cwDEKv66t8D'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/payin30start'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['de|uk|gb', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_EMEA'
          }
        }]
      };
      var checkout_payin30_finish = {
        'name': 'checkout_payin30_finish',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['de', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:xo:lite:dumbledore:member:review',
            'link': 'process_review',
            'chosen_funding_option': 'pay_in_1'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/pp_em003+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'PAY IN 30',
            'event_action': 'Txn Finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_payin30finish'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-1006288171/E7vACO3L7cwDEKv66t8D'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/payin30finish'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['de|uk|gb', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_EMEA'
          }
        }]
      };
      var xolite_start_1 = {
        'name': 'xolite_start_1',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:xo:lite:hagrid:member:review|main:xo:lite:dumbledore:member:review',
            'flnm': 'Hagrid|Dumbledore|ec:hermes:'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/herme0+standard',
            'u2': {
              'type': 'var',
              'path': 'laDataLayer.mrid',
              'defaultVal': 'NA'
            },
            'u3': {
              'type': 'int',
              'path': 'laDataLayer.amt'
            },
            'u4': {
              'type': 'var',
              'path': 'laDataLayer.curr',
              'defaultVal': 'NA'
            },
            'u10': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: HermesFlowTxnStart',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.comp',
              'defaultVal': 'unknown'
            },
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.mrid',
              'defaultVal': 'NA'
            },
            'value': {
              'type': 'int',
              'path': 'laDataLayer.amt'
            },
            'dimension6': {
              'type': 'var',
              'path': 'laDataLayer.rsta'
            },
            'dimension23': {
              'type': 'var',
              'path': 'laDataLayer.flnm',
              'defaultVal': 'Hermione'
            },
            'dimension24': {
              'type': 'var',
              'path': 'laDataLayer.curr',
              'defaultVal': 'NA'
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Qvd-CJi14OABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/6skCCNO04OABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/nOhVCJzp6-ABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/YIRBCKjp6-ABEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_US'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['de|uk|gb', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_EMEA'
          }
        }]
      };
      var setup_xo_standard = {
        'name': 'setup_xo_standard',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:activation:commercesetupnodeweb:AddUser'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/pp_gb001+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/ah-oCKKv4IACEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/XhI4CMbQ6IACELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/PaMWCPLM6IACEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/Z8ErCK_U6IACEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/checkoutdeveloperlandingpage'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_checkout_devLandingPage'
          }
        }]
      };
      var mac_zettle_consent = {
        'name': 'mac_zettle_consent',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:connect:::thirdPartyLogin:consent_bank_grouping:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/pp_gb000+standard'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/zettlesignupconsent'
          }
        }]
      };
      var pers_acc_su_fin = {
        'name': 'pers_acc_su_fin',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:onbrd:organic:wallet:(selectIntent|addcard):::|consonbdnodeweb/.*/signup/usePayPal.dust|main:onbrd:signup:organic:intent_selection'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/persa00+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Hv52CLWGs8cBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/jBTSCN2l9NcBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/T0apCKytv9gBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/g-dgCM_sztgBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'ConsumerSignup'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PersAcctSUFin',
            'event_action': 'sign up finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 4: success',
            'page_path': '/welcome/signup/intent_selection',
            'page_title': 'Select Intent',
            'dimension9': 'step 4: success',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            },
            'dimension46': 'true'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_CONSACCT_SIGNUP_FIN',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 4: success',
            'page_path': '/welcome/signup/intent_selection',
            'page_title': 'Select Intent',
            'dimension9': 'step 4: success',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            },
            'dimension46': 'true'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/consumersignupfinish'
          }
        }]
      };
      var ztl_su_start = {
        'name': 'ztl_su_start',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'zettle:onboarding:signup'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/pp_na0+standard'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-992191228/yC-UCIKpz8gCEPzFjtkD'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'zettle',
            'event_action': 'signup start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_MERCHACCT_STRT',
            'event_category': 'zettle',
            'event_action': 'signup start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/zettleussignupstart'
          }
        }]
      };
      var ztl_su_finish = {
        'name': 'ztl_su_finish',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'zettle:onboarding:complete',
            'status': 'APPROVED'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/pp_na00+standard'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-992191228/aAQeCLyLz8gCEPzFjtkD'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'zettle',
            'event_action': 'signup finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_MERCHACCT_FIN',
            'event_category': 'zettle',
            'event_action': 'signup finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/zettleussignupfinish'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'FB_PP_NA_ONBOARDING_ZETTLE_SIGNUP_FINISH'
          }
        }]
      };
      var ztl_su_finish_reg = {
        'name': 'ztl_su_finish_reg',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'zettle:onboarding:complete',
            'status': 'NEED_DATA|IN_REVIEW'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/pp_na000+standard'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-992191228/ekgYCLelrPkCEPzFjtkD'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'zettle',
            'event_action': 'registered user',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_MERCHACCT_REG',
            'event_category': 'zettle',
            'event_action': 'registered user',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/zettleregistereduser'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_zettleregistereduser'
          }
        }]
      };
      var credit_app_start = {
        'name': 'credit_app_start',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:creditapplyweb:billinginfopage:::::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu002/ppcre0+standard',
            'u1': {
              'type': 'var',
              'path': ['ensighten.buyerId', 'buyerId', 'fpti.cust']
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PPCreditAppStart',
            'event_action': 'start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer credit',
            'event_action': 'step 1: billing info',
            'event_label': 'application start',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Confirm Billing Info'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/QWdLCOPLgZQDEPzFjtkD'
          }
        }]
      };
      var credit_app_succ = {
        'name': 'credit_app_succ',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:creditapplyweb:decisionpage:APPROVED::::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu002/ppcre00+standard',
            'u1': {
              'type': 'var',
              'path': ['ensighten.buyerId', 'buyerId', 'fpti.cust']
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'ProductSignup-CreditApproved-PayPalCreditApply'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PPCreditAppFinApproved',
            'event_action': 'finish approved',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer credit',
            'event_action': 'step 4: decision',
            'event_label': 'approved',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Decision Page'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ADON_PPCREDIT_APPLICATN_FINAPPROVED_US',
            'event_category': 'consumer credit',
            'event_action': 'step 4: decision',
            'event_label': 'approved',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Decision Page'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/ns46CLP1sNwBEPzFjtkD'
          }
        }]
      };
      var credit_app_decl = {
        'name': 'credit_app_decl',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:creditapplyweb:decisionpage:DECLINED::::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu002/ppcre000+standard',
            'u1': {
              'type': 'var',
              'path': ['ensighten.buyerId', 'buyerId', 'fpti.cust']
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PPCreditAppFinDeclined',
            'event_action': 'finish declined',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer credit',
            'event_action': 'step 4: decision',
            'event_label': 'declined',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Decision Page'
          }
        }]
      };
      var credit_psu_start = {
        'name': 'credit_psu_start',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:creditapplyweb:newcust:::::'
          },
          'session': {
            'key': 'psucredit',
            'type': 'start'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/persa0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PersAcctSUStart',
            'event_action': 'sign up start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'credit application'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_CONSACCT_SIGNUP_STRT',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'credit application'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/6yJwCJSV--ABEPzFjtkD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/consumersignupstart'
          }
        }]
      };
      var start_uk = {
        'name': 'start_uk',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['gb|uk', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:creditapplyweb:(applypage:::::|newcust:::::)'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu002/ppcre002+standard',
            'u1': {
              'type': 'var',
              'path': ['ensighten.buyerId', 'buyerId', 'fpti.cust']
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_UKCreditApplicationStart'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer credit',
            'event_action': 'step 1: billing info',
            'event_label': 'application start',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Confirm Billing Info'
          }
        }]
      };
      var appr_uk = {
        'name': 'appr_uk',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['gb|uk', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:creditapplyweb:contractpage:CONSUMERCREDIT::::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu003/ppcre00+standard',
            'u1': {
              'type': 'var',
              'path': ['ensighten.buyerId', 'buyerId', 'fpti.cust']
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer credit',
            'event_action': 'step 3: terms and conditions',
            'event_label': 'show terms and conditions',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Review Terms and Conditions'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/5KGaCKLWzdwBEKv66t8D'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'ProductSignup-CreditApproved-PayPalCreditApply'
          }
        }]
      };
      var succ_end_uk = {
        'name': 'succ_end_uk',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['gb|uk', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:creditapplyweb:contractpage:CONSUMERCREDIT::::',
            'link': 'creditContractAgreeToTermsGB'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu002/ppcre003+standard',
            'u1': {
              'type': 'var',
              'path': ['ensighten.buyerId', 'buyerId', 'fpti.cust']
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_UKCreditApplicationFinish'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer credit',
            'event_action': 'step 4: decision',
            'event_label': 'approved',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Decision Page'
          }
        }]
      };
      var credit_app_per_info = {
        'name': 'credit_app_per_info',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:creditapplyweb:personalinfopage:::::'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer credit',
            'event_action': 'step 2: personal info',
            'event_label': 'enter personal info',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Enter Personal Info'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_FUNDINGINST_PPCREDIT_APPLICATN_PRSNLINFO',
            'event_category': 'consumer credit',
            'event_action': 'step 2: personal info',
            'event_label': 'enter personal info',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Enter Personal Info'
          }
        }]
      };
      var credit_app_terms = {
        'name': 'credit_app_terms',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:creditapplyweb:termspage:::::'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer credit',
            'event_action': 'step 3: terms and conditions',
            'event_label': 'show terms and conditions',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Review Terms and Conditions'
          }
        }]
      };
      var bizdebit_start = {
        'name': 'bizdebit_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:debitcardweb:debitcard:.*:createCard'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch00/merch003+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/rdmKCJ-hg4oZEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/xFPSCNmog4oZELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/2mV-CKjEhIoZEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/7m_4CJ69hIoZEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_BDMCsignupstart'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantdebitsignupstart'
          }
        }]
      };
      var bizdebit_aprv = {
        'name': 'bizdebit_aprv',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:debitcardweb:debitcard:.*createCard:enrollSuccess:loaded'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch00/merch004+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/JBXxCIaez9gBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/NyTpCO3n3dgBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/BJjwCKm8v9gBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/IcJxCPHwztgBEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantdebitsignup'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_merchantdebitsignup'
          }
        }]
      };
      var bizdebit_aprv_2 = {
        'name': 'bizdebit_aprv_2',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:debitcardweb:debitcard:US:createCard:instantCardEnrollSuccess:loaded|main:debitcardweb:debitcard:US:createCard:cardCreation:loaded',
            'event_name': 'bdmc_enroll_instant_card_enroll_success_screen_shown|bdmc_enroll_card_creation_screen_shown'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch00/merch004+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/JBXxCIaez9gBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/NyTpCO3n3dgBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/BJjwCKm8v9gBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/IcJxCPHwztgBEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantdebitsignup'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_merchantdebitsignup'
          }
        }]
      };
      var mac_xo = {
        'name': 'mac_xo',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:merchanthub:appcenter:checkout|main:mktg:business:merchant-integration:get-started:::|main:mktg:::api:::|main:developer:docs:checkout|main:developer:docs:business:checkout:set-up-standard-payments|main:mktg:business:product:business-accept-payments/checkout/integration:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/pp_gb0+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/eQogCJXu3oACEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/k1r_CKHfx4ACELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/g-CbCLDx3oACEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/hYVlCJrhx4ACEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/checkoutlandingpage'
          }
        }]
      };
      var chk_doc_click = {
        'name': 'chk_doc_click',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:developer:docs:checkout',
            'event_action': 'main-section-click',
            'event_category': 'checkout',
            'event_label': 'docs_checkout_standard',
            'link': 'Read the guide'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/pp_gb008+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/spSeCJ3_i6sDEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/BKYmCJ2ExasDELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/pMlYCPiVjKsDEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/dGUrCKLuxKsDEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_developercheckoutreadtheguide'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/developercheckoutreadtheguide'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'developer checkout',
            'event_action': 'read the guide click',
            'event_label': {
              'type': 'fn',
              'name': 'fetchSanatizedURL'
            }
          }
        }]
      };
      var pp_early_dd_finish = {
        'name': 'pp_early_dd_finish',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us|ca', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'directdepositnodeweb/default',
            'pglk': 'main:policydashboardweb:process:compliance:debitcard:personal:US|submit'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu005/pp_na00+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/G_2GCNehz8gCEPzFjtkD'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'early direct deposit',
            'event_action': 'signup finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/earlydirectdepositsignupfinish'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_directdeposit_signupfinish'
          }
        }]
      };
      var bnpl_msg = {
        'name': 'bnpl_msg',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:product:promoportal:messaging:::|main:mktg:product:promoportal:get_started'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/pp_gb004+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_action': 'landing page',
            'event_category': 'bnpl messaging center',
            'event_label': {
              'type': 'fn',
              'name': 'fetchSanatizedURL'
            }
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/paylater/messaging'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/7cNhCPr6kfQCEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/atPuCPvevfQCEJy7qMwD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/LRQuCLP-kfQCEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/x4ZtCKfhvfQCELXZ6tkD'
          }
        }]
      };
      var xo_start = {
        'name': 'xo_start',
        'trigger': {
          'type': 'fn',
          'name': 'fireImmediate'
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/herme0+standard',
            'u2': {
              'type': 'var',
              'path': 'pre.payee.res.data.merchant.id',
              'defaultVal': 'NA'
            },
            'u3': {
              'type': 'int',
              'path': 'pre.cart.res.data.purchase.amounts.total.amount'
            },
            'u4': {
              'type': 'var',
              'path': 'pre.cart.res.data.purchase.amounts.total.currency_code',
              'defaultVal': 'NA'
            },
            'u10': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: HermesFlowTxnStart',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.comp',
              'defaultVal': 'unknown'
            },
            'event_label': {
              'type': 'var',
              'path': 'pre.payee.res.data.merchant.id',
              'defaultVal': 'NA'
            },
            'value': {
              'type': 'int',
              'path': 'pre.cart.res.data.purchase.amounts.total.amount'
            },
            'dimension23': {
              'type': 'var',
              'path': 'pre.checkoutAppData.res.data.flow_id',
              'defaultVal': 'Hermes'
            },
            'dimension24': {
              'type': 'var',
              'path': 'pre.cart.res.data.purchase.amounts.total.currency_code',
              'defaultVal': 'NA'
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Qvd-CJi14OABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/6skCCNO04OABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/nOhVCJzp6-ABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/YIRBCKjp6-ABEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_US'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['de|uk|gb', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_EMEA'
          }
        }]
      };
      var xo_end = {
        'name': 'xo_end',
        'trigger': {
          'type': 'fn',
          'name': 'fireButtonClick'
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/herme00+standard',
            'u2': {
              'type': 'var',
              'path': 'pre.payee.res.data.merchant.id',
              'defaultVal': 'NA'
            },
            'u3': {
              'type': 'int',
              'path': 'pre.cart.res.data.purchase.amounts.total.amount'
            },
            'u4': {
              'type': 'var',
              'path': 'pre.cart.res.data.purchase.amounts.total.currency_code',
              'defaultVal': 'NA'
            },
            'u10': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/w3DCCJKhz9gBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/JdISCJqUz9gBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/jWNpCI3Ev9gBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/lFV9COe4v9gBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'Transaction-HermesFlowTxnEnd-HermesFlow',
            'cd[MerchantID]': {
              'type': 'var',
              'path': 'pre.payee.res.data.merchant.id',
              'defaultVal': 'NA'
            },
            'cd[MerchantTPV]': {
              'type': 'int',
              'path': 'pre.cart.res.data.purchase.amounts.total.amount'
            },
            'cd[MerchantTransaction]': {
              'type': 'var',
              'path': 'pre.cart.res.data.purchase.amounts.total.currency_code',
              'defaultVal': 'NA'
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'attempted checkout',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.comp',
              'defaultVal': 'unknown'
            },
            'event_label': {
              'type': 'var',
              'path': 'pre.payee.res.data.merchant.id',
              'defaultVal': 'NA'
            },
            'value': {
              'type': 'int',
              'path': 'pre.cart.res.data.purchase.amounts.total.amount'
            },
            'dimension23': {
              'type': 'var',
              'path': 'pre.checkoutAppData.res.data.flow_id',
              'defaultVal': 'Hermes'
            },
            'dimension24': {
              'type': 'var',
              'path': 'pre.cart.res.data.purchase.amounts.total.currency_code',
              'defaultVal': 'NA'
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_TXN_CONSXO_FIN',
            'event_category': 'attempted checkout',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.comp',
              'defaultVal': 'unknown'
            },
            'event_label': {
              'type': 'var',
              'path': 'pre.payee.res.data.merchant.id',
              'defaultVal': 'NA'
            },
            'value': {
              'type': 'int',
              'path': 'pre.cart.res.data.purchase.amounts.total.amount'
            },
            'dimension23': {
              'type': 'var',
              'path': 'pre.checkoutAppData.res.data.flow_id',
              'defaultVal': 'Hermes'
            },
            'dimension24': {
              'type': 'var',
              'path': 'pre.cart.res.data.purchase.amounts.total.currency_code',
              'defaultVal': 'NA'
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: HermesFlowTxnFin',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.comp',
              'defaultVal': 'unknown'
            },
            'event_label': {
              'type': 'var',
              'path': 'pre.payee.res.data.merchant.id',
              'defaultVal': 'NA'
            },
            'value': {
              'type': 'int',
              'path': 'pre.cart.res.data.purchase.amounts.total.amount'
            },
            'dimension23': {
              'type': 'var',
              'path': 'pre.checkoutAppData.res.data.flow_id',
              'defaultVal': 'Hermes'
            },
            'dimension24': {
              'type': 'var',
              'path': 'pre.cart.res.data.purchase.amounts.total.currency_code',
              'defaultVal': 'NA'
            }
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_US'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['de|uk|gb', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_EMEA'
          }
        }]
      };
      var pp_early_dd_start = {
        'name': 'pp_early_dd_start',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us|ca', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:homeinfonodeweb:info:cashaccount::disclosure:terms:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu005/pp_na0+standard'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-992191228/YYvhCI2CzsgCEPzFjtkD'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'early direct deposit',
            'event_action': 'signup start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/earlydirectdepositsignupstart'
          }
        }]
      };
      var honey_mobile = {
        'name': 'honey_mobile',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['au', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'honey:main:mobile_complete'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-10648833/consu005/pp_gb00+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'honey event',
            'event_action': 'mobile sign up/plugin install',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-965352860/JYbZCJLo4-ABEJy7qMwD'
          }
        }]
      };
      var honey_desktop = {
        'name': 'honey_desktop',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['au', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'honey:main:welcome'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-10648833/consu005/pp_gb0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'honey event',
            'event_action': 'desktop sign up/plugin install',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-965352860/i-ooCPXl4-ABEJy7qMwD'
          }
        }]
      };
      var honey_landing = {
        'name': 'honey_landing',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['au', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'honey:landing_page:paypal:main'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-10648833/campa0/pp_gb0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'honey event',
            'event_action': 'landing page',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-965352860/5sIBCOHQ_uABEJy7qMwD'
          }
        }]
      };
      var inv_cr8_start = {
        'name': 'inv_cr8_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:inv3:manage::invoices:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch00/invoi0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant invoicing',
            'event_action': 'create',
            'event_label': 'start'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_FUNDINGINST_INVOICE_MNGE_STRT',
            'event_category': 'merchant invoicing',
            'event_action': 'create',
            'event_label': 'start'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/kgrlCPbK7eABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/w4X2CJiG_eABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/ixL0CK2D_eABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/JM1aCPvG7eABEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/requestmoneystart'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_invoice_requestmoneystart'
          }
        }]
      };
      var inv_cr8_end = {
        'name': 'inv_cr8_end',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:inv3:manage:msg:(invsent|scheduled|invshared):::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch00/invoi00+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/ORSkCI-tz9gBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/E_iRCMbcv9gBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/7c-3CPH_ztgBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/4IoFCNnH3dgBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'ProductSignup-InvoiceFin-Invoice'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant invoicing',
            'event_action': 'create',
            'event_label': 'finish'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_FUNDINGINST_INVOICE_MNGE_FIN',
            'event_category': 'merchant invoicing',
            'event_action': 'create',
            'event_label': 'finish'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/requestmoneyfinish'
          }
        }]
      };
      var inv_cr8_dt_start = {
        'name': 'inv_cr8_dt_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'pgrp': 'main:inv3:desktopmanage:::',
            'link': 'CreateInvoice|CreateEstimate|CreateRecurring'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch00/invoi0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant invoicing',
            'event_action': 'create',
            'event_label': 'start'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_FUNDINGINST_INVOICE_MNGE_STRT',
            'event_category': 'merchant invoicing',
            'event_action': 'create',
            'event_label': 'start'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/kgrlCPbK7eABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/w4X2CJiG_eABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/ixL0CK2D_eABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/JM1aCPvG7eABEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/requestmoneystart'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_invoice_requestmoneystart'
          }
        }]
      };
      var inv_cr8_dt_end = {
        'name': 'inv_cr8_dt_end',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'pgrp': 'main:inv3:desktopcreate:invoice:|main:inv3:desktopcreate:recurring:',
            'link': 'SendInvoice|CreateShare|SaveAsTemplate|ItemUnitPrice'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch00/invoi00+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/ORSkCI-tz9gBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/E_iRCMbcv9gBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/7c-3CPH_ztgBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/4IoFCNnH3dgBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'ProductSignup-InvoiceFin-Invoice'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant invoicing',
            'event_action': 'create',
            'event_label': 'finish'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_FUNDINGINST_INVOICE_MNGE_FIN',
            'event_category': 'merchant invoicing',
            'event_action': 'create',
            'event_label': 'finish'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/requestmoneyfinish'
          }
        }]
      };
      var inv_pay_finish = {
        'name': 'inv_pay_finish',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:inv3:payerinv::paymentdone:::|main:inv3:payerinv::paymentdone::paymentPending:|main:inv3:desktoppayer::paymentdone:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch00/pp_gb0+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/70JpCNuW3NwBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/0oYFCJ750twBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/ox4kCO6X3NwBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/VFg3COGG79wBEJy7qMwD'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant invoicing',
            'event_action': 'pay invoice',
            'event_label': 'finish'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/sendmoneyfinish'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_FUNDINGINST_INVOICE_PAY_FIN',
            'event_category': 'merchant invoicing',
            'event_action': 'pay invoice',
            'event_label': 'finish'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_invoice_sendmoneyfinish'
          }
        }]
      };
      var mpp_mp_start = {
        'name': 'mpp_mp_start',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg:personal:product:money-pools:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/money0+standard'
          }
        }]
      };
      var land_uk = {
        'name': 'land_uk',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['gb|uk', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:mktg:personal::paypal-virtual-credit|main:mktg:personal:product:digital-wallet-ways-to-pay/credit-services'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu002/ppcre001+standard',
            'u1': {
              'type': 'var',
              'path': ['ensighten.buyerId', 'buyerId', 'fpti.cust']
            }
          }
        }]
      };
      var rd_curr = {
        'name': 'rd_curr',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['au', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg:general::ecommerce2020:::|main:mktg:business:enterprise:ecommerceindex2021:::',
            'link': 'Pullout-Prmrycta-Offer-ScndCTA-Download Now|The future of ticketing\\| Download Now|The future of ticketing\\| Download the report|editorial \\| Download the report'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/curre00+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/-s7GCLuR2oMDEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/mobilecommercedownload'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_mobilecommercedownload'
          }
        }]
      };
      var con_sel = {
        'name': 'con_sel',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg::signup:accountselect:::',
            'link': 'personal-account|personal|Personal Account \\| Next'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/apac_0+standard'
          }
        }]
      };
      var mer_sel = {
        'name': 'mer_sel',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg::signup:accountselect:::',
            'link': 'merchant-account|business|Business Account \\| Next'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/apac_00+standard'
          }
        }]
      };
      var mpp_404 = {
        'name': 'mpp_404',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:mktg:::page-not-found'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': '404 error',
            'event_action': {
              'type': 'fn',
              'name': 'constructUrl'
            },
            'event_label': {
              'type': 'var',
              'path': 'document.referrer',
              'defaultVal': 'none'
            },
            'content_group1': {
              'type': 'var',
              'path': 'dataLayer.pageType'
            }
          }
        }]
      };
      var acc_sel = {
        'name': 'acc_sel',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg::signup:(accountselect|account-selection):::|main:mktg:sem::account-selection-signup:::|main:mktg:both:product:account-selection:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/accou0+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/lyoPCKTM7eABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/sFBBCPmR4uABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/DF8-CP-R4uABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/5AoqCNHM7eABEJy7qMwD'
          }
        }]
      };
      var borderless_cm_form_submit = {
        'name': 'borderless_cm_form_submit',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['jp|sg|hk|br|mx', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg:business::business-borderless-commerce:::',
            'pglk': 'main:mktg:business::business-borderless-commerce\\|pardot-form-submit'
          }
        },
        'vendors': [{
          'name': 'li',
          'vars': {
            'url': 'paypal.com/crossborderdownloadreportformsubmit'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'download_report',
            'event_action': 'submit_form',
            'event_label': {
              'type': 'fn',
              'name': 'fetchSanatizedURL'
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_downloadreportformsubmit'
          }
        }]
      };
      var pp_partner_cnt_finish = {
        'name': 'pp_partner_cnt_finish',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:mktg:business::partner-program-contactsupport-submission'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/pp_gb00+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/CVEPCMKpstwBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/rpt-CIWistwBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/BjdqCMH3u9wBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/VnmjCJ__u9wBEJy7qMwD'
          }
        }]
      };
      var pp_merchant_cnt_start = {
        'name': 'pp_merchant_cnt_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:::contact-us:::|main:mktg:::contact-sales:::|main:mktg:::business-contact-sales:::|main:mktg:::grow-business:::|main:mktg:business::contact-sales:::|main:mktg:business::contact:::|main:mktg:business:product:business-contact-sales:::|main:mktg:business:campaign:campaigns-business/contact:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/pp_gb000+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/s86DCNawq_sBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/odXuCKuptvsBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/vPdkCPqUlvsBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/y3vRCLmvqfsBEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantcontactstart'
          }
        }]
      };
      var pp_merchant_cnt_finish = {
        'name': 'pp_merchant_cnt_finish',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:mktg:::contact-us-complete|main:mktg:::merchant\\/contact-us-complete|main:mktg:business::business-contact-sales-thank-you|main:mktg:business:product:business-contact-sales-thank-you|main:mktg:business::contact-sales-thank-you|main:mktg:business:product:business-contact-sales/thank-you|main:mktg:::contact-sales-thank-you|main:mktg:business::grow-business-thank-you|main:mktg:business::contact-sales/thank-you'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/pp_gb001+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/ESn_CMH17eABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/h-rfCN6r_eABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/whuMCPyr_eABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/NUdnCLP57eABEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantcontactfinish'
          }
        }]
      };
      var con_sel_click = {
        'name': 'con_sel_click',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us|gb|ca|ie', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'pgrp': 'main:mktg::signup:accountselect|main:mktg:for-you:account:create-account',
            'link': 'Personal|PersonalControl|sign-up-for-personal-account'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 1: account selection'
          }
        }]
      };
      var mer_sel_click = {
        'name': 'mer_sel_click',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us|gb|ca|ie', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'pgrp': 'main:mktg::signup:accountselect|main:mktg:for-you:account:create-account',
            'link': 'Business|BusinessControl|account-selection|sign-up-for-free'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 1: account selection'
          }
        }]
      };
      var prod_sel_pageview = {
        'name': 'prod_sel_pageview',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:mktg:personal::product-selection'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 2: product selection',
            'dimension9': 'step 2: product selection'
          }
        }]
      };
      var mpp_offer = {
        'name': 'mpp_offer',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pglk': 'main:mktg:personal::offers\\|save_to_wallet'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'save offer to wallet',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': {
              'type': 'var',
              'path': 'fpti.link'
            }
          }
        }]
      };
      var pp_home_land = {
        'name': 'pp_home_land',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:mktg:personal::home-dw|main:mktg:personal::home|main:mktg:personal:homepage:home|main:mktg:business:product:business|main:mktg:business::home',
            'event_name': 'ppcom_page_viewed'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pphom0+standard'
          }
        }]
      };
      var emailClick = {
        'name': 'emailClick',
        'trigger': {
          'type': 'fn',
          'name': 'eventClick',
          'sel': 'a[href^="mailto:"]'
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'mailto',
            'event_action': {
              'type': 'var',
              'path': 'mktconf.evntData.href',
              'defaultVal': 'email tracking'
            },
            'event_label': ''
          }
        }]
      };
      var outboundLinkClick = {
        'name': 'outboundLinkClick',
        'trigger': {
          'type': 'fn',
          'name': 'eventClick',
          'sel': 'a:not([href*="paypal.com"])',
          'once': false
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'exit links',
            'event_action': {
              'type': 'var',
              'path': 'mktconf.evntData.hostname',
              'defaultVal': 'hostname'
            },
            'event_label': {
              'type': 'var',
              'path': 'mktconf.evntData.pathname'
            },
            'transport_type': 'beacon'
          }
        }]
      };
      var videoPlay = {
        'name': 'videoPlay',
        'trigger': {
          'type': 'fn',
          'name': 'eventClick',
          'sel': 'a[href$=".mp4"], button[class*="mpp-media-btn"]',
          'once': false
        },
        'capture': 'data-video-id',
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'video',
            'event_action': 'play',
            'event_label': {
              'type': 'var',
              'path': ['mktconf.evntData.id', 'mktconf.evntData.data-video-id'],
              'defaultVal': 'videoId'
            }
          }
        }]
      };
      var videoPlay_youTube = {
        'name': 'videoPlay_youTube',
        'trigger': {
          'type': 'fn',
          'name': 'eventClick',
          'sel': 'a[class="youtube-player-modal"], #player, button[data-video-id]',
          'once': false
        },
        'capture': 'data-video-id',
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'video',
            'event_action': 'youtube play',
            'event_label': {
              'type': 'var',
              'path': ['mktconf.evntData.id', 'mktconf.evntData.data-video-id'],
              'defaultVal': 'videoId'
            }
          }
        }]
      };
      var downloadFiles = {
        'name': 'downloadFiles',
        'trigger': {
          'type': 'fn',
          'name': 'eventClick',
          'sel': 'a[href$=".pdf"], a[href$=".xlsx"]',
          'once': false
        },
        'capture': 'data-pa-click',
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'downloads',
            'event_action': {
              'type': 'fn',
              'name': 'mapValue',
              'args': [['mktconf.evntData.href', 'mktconf.evntData.className'], {
                '.pdf': 'pdf',
                '.xlsx': 'excel',
                'itunes.apple.com': 'app ios',
                'play.google.com': 'app google',
                'apple': 'app ios',
                'google': 'app google'
              }],
              'defaultVal': 'file download'
            },
            'event_label': {
              'type': 'var',
              'path': 'mktconf.evntData.data-pa-click'
            }
          }
        }]
      };
      var navigationTracking_head = {
        'name': 'navigationTracking_head',
        'trigger': {
          'type': 'fn',
          'name': 'eventClick',
          'sel': '#main-menu a',
          'once': false
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'navigation tracking',
            'event_action': 'main menu',
            'event_label': {
              'type': 'var',
              'path': 'mktconf.evntData.textContent',
              'defaultVal': 'header value'
            }
          }
        }]
      };
      var navigationTracking_foot = {
        'name': 'navigationTracking_foot',
        'trigger': {
          'type': 'fn',
          'name': 'eventClick',
          'sel': 'footer a',
          'once': false
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'navigation tracking',
            'event_action': 'footer menu',
            'event_label': {
              'type': 'var',
              'path': 'mktconf.evntData.textContent',
              'defaultVal': 'footer value'
            }
          }
        }]
      };
      var qrc_su_start = {
        'name': 'qrc_su_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'pgrp': 'main:mktg:business:campaign:qr-code-download|main:mktg:business:product:adapt-your-business|main:mktg:business:product:adapt-your-business',
            'lgin': 'out'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_gb003+standard'
          }
        }]
      };
      var qrc_su_fin = {
        'name': 'qrc_su_fin',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'pgrp': 'main:mktg:business:campaign:qr-code-download',
            'pglk': 'main:mktg:business:campaign:qr-code-download\\|Hero\\|Download Your QR Code|main:mktg:business:campaign:qr-code-download\\|Hero\\|QR-Code herunterladen|main:mktg:business:campaign:qr-code-download\\|Hero\\|Téléchargez votre QR code|main:mktg:business:campaign:qr-code-download\\|Hero\\|Descargar código QR',
            'lgin': 'in'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_gb004+standard'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/qrgeneration'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/RcArCJmAvPQCEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/ouPTCILLvfQCEJy7qMwD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/0BP_CJPwkfQCEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/yc5nCP3rkfQCELXZ6tkD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_qrgeneration'
          }
        }]
      };
      var bnpl_book_meeting = {
        'name': 'bnpl_book_meeting',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg:business::enterprise/buy-now-pay-later:::|main:mktg:enterprise::enterprise/pay-later:::|main:mktg:business::buy-now-pay-later:::',
            'link': 'Enterprise Form|Book a Meeting|Book Consultation|pardot-form-submit-button|Prendre rendez-vous'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_gb008+standard'
          }
        }]
      };
      var payin4_landing_page = {
        'name': 'payin4_landing_page',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us|fr|au', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:::pay-in-4:::|main:mktg:personal::4x:::|main:mktg:business::business-buy-now-pay-later:::|main:mktg:personal:product:digital-wallet-ways-to-pay/buy-now-pay-later:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_na00+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'pay in 4',
            'event_action': 'landing page',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ADON_BNPLPAYIN4_XX_LOAD_LNDGPG',
            'event_category': 'pay in 4',
            'event_action': 'landing page',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var pp_merchant_ent_cnt_start = {
        'name': 'pp_merchant_ent_cnt_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:::enterprise-contact-sales:::|main:mktg:enterprise:product:enterprise-contact-sales:::|main:mktg:enterprise::enterprise-contact-sales:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/pp_gb002+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'enterprise form',
            'event_action': 'form start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_enterprisemerchantformcontactusstart'
          }
        }]
      };
      var pp_merchant_ent_cnt_finish = {
        'name': 'pp_merchant_ent_cnt_finish',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:business:product:enterprise-contact-sales-thank-you:::|main:mktg:enterprise:product:enterprise-contact-sales-thank-you:::|main:mktg:enterprise:product:enterprise-contact-sales/thank-you:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/pp_gb003+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'enterprise form',
            'event_action': 'form complete',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/mjQWCJrVoO4BEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/IE21CPW_wO4BELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/QufeCM3BwO4BEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/KdwpCMrBwO4BEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/enterprisemerchantcontactfinish'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_enterprisemerchantformcontactusfinish'
          }
        }]
      };
      var download_ios_app = {
        'name': 'download_ios_app',
        'trigger': {
          'type': 'fn',
          'name': 'eventClick',
          'sel': 'a[href*="itunes.apple.com"], a[class*="app-badge app-badge--apple"]',
          'once': false
        },
        'capture': 'data-pa-click',
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'downloads',
            'event_action': 'app ios',
            'event_label': {
              'type': 'var',
              'path': 'mktconf.evntData.data-pa-click'
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_CONSAPP_INSTALL_LOAD_LNDGPG_IOS',
            'event_category': 'downloads',
            'event_action': 'app ios',
            'event_label': {
              'type': 'var',
              'path': 'mktconf.evntData.data-pa-click'
            }
          }
        }, {
          'name': 'dc',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_na00f+standard'
          }
        }]
      };
      var download_android_app = {
        'name': 'download_android_app',
        'trigger': {
          'type': 'fn',
          'name': 'eventClick',
          'sel': 'a[href*="play.google.com"], a[class*="app-badge app-badge--google"]',
          'once': false
        },
        'capture': 'data-pa-click',
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'downloads',
            'event_action': 'app google',
            'event_label': {
              'type': 'var',
              'path': 'mktconf.evntData.data-pa-click'
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_CONSAPP_INSTALL_LOAD_LNDGPG_ANDRD',
            'event_category': 'downloads',
            'event_action': 'app google',
            'event_label': {
              'type': 'var',
              'path': 'mktconf.evntData.data-pa-click'
            }
          }
        }, {
          'name': 'dc',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_na00e+standard'
          }
        }]
      };
      var mpp_partner_checkout = {
        'name': 'mpp_partner_checkout',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:merchanthub:appcenter:partners|main:mktg:business::partner-directory:::|main:mktg:business::partner-solutions:::|main:mktg:business:sem:merchant-solutions-partners:::|main:mktg:enterprise:product:business-platforms-and-marketplaces/solutions:::|main:mktg:business::partners-directory:::|main:mktg:business::solution-providers:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_gb00b+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/ohoOCKfAyYACEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/2E97CPvb6IACELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/gUJVCNnFyYACEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/lC6kCNLHyYACEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/checkoutpartnerlandingpage'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_checkout_partnerLP'
          }
        }]
      };
      var mpp_fraud_sec_form_start = {
        'name': 'mpp_fraud_sec_form_start',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us|ca', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:business::enterprise-advanced-fraud-security:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_na00i+standard'
          }
        }]
      };
      var mac_request_money = {
        'name': 'mac_request_money',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:merchanthub:appcenter:request_money|main:mktg:personal:buy:requesting-payments:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/pp_gb002+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/KY20CLf36IACEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/c6KhCLbhyYACELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/ha2uCKTh4IACEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/I1x4CIbeyYACEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/emailpaymentslandingpage'
          }
        }]
      };
      var pardot_mpp_event = {
        'name': 'pardot_mpp_event',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgsf': 'business|enterprise'
          }
        },
        'vendors': [{
          'name': 'pd',
          'vars': {
            'piAId': '926803',
            'piCId': '5717'
          }
        }]
      };
      var mpp_mobile_apps = {
        'name': 'mpp_mobile_apps',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:personal:product:digital-wallet:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_gb00d+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/50g-CPa94oMDEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/w1WuCP_dioQDELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/eptpCN7aioQDEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/pFOhCP3ok4QDEJy7qMwD'
          }
        }]
      };
      var mpp_qrc_dwnld = {
        'name': 'mpp_qrc_dwnld',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:business:campaign:qr-code-download'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_gb00f+standard'
          }
        }]
      };
      var mpp_uk_acceptpymt = {
        'name': 'mpp_uk_acceptpymt',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['gb|it|uk', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:business:product:business-accept-payments:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_em0+standard'
          }
        }]
      };
      var mpp_uk_business = {
        'name': 'mpp_uk_business',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['gb|it|uk', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:business:product:business:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_em00+standard'
          }
        }]
      };
      var mpp_uk_enterprise_reg = {
        'name': 'mpp_uk_enterprise_reg',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['gb|uk|fr|de', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:business::enterprise/buy-now-pay-later:::|main:mktg:business::enterprise/pay-later:::'
          }
        },
        'vendors': [{
          'name': 'li',
          'vars': {
            'url': 'paypal.com/bnplregisterationfinish'
          }
        }]
      };
      var mpp_de_expressxo = {
        'name': 'mpp_de_expressxo',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['de', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg:business:product:enterprise-express:::',
            'pglk': 'main:mktg:business:product:enterprise-express\\|pardot-form-submit'
          }
        },
        'vendors': [{
          'name': 'li',
          'vars': {
            'url': 'paypal.com/expressregisterationfinish'
          }
        }]
      };
      var mpp_merchfees_it = {
        'name': 'mpp_merchfees_it',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['it', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:business::merchant-fees:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_gb00h+standard'
          }
        }]
      };
      var pardot_mpp_home_page = {
        'name': 'pardot_mpp_home_page',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'event_name': 'ppcom_page_viewed'
          }
        },
        'vendors': [{
          'name': 'pd',
          'vars': {
            'piAId': '926803',
            'piCId': '5717'
          }
        }]
      };
      var landing = {
        'name': 'landing',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:ppwc:::homepage:::|Landing Page|main:mktg:business::paypal-working-capital:::|main:mktg:general::camp-paypal-working-capital-pre-approval:::|main:mktg:business:product:paypal-working-capital:::|workingcapitalnodeweb/react/root.dust|workingcapitalnodeweb/react/root.dust:landingPageV3'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch001/ppwcl0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PPWCLanding',
            'event_action': 'landing page',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/2S9QCJK9iIwDEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/xx35CIbfpowDELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/tS21CL_NiYwDEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/id_0CLiC4YsDEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_ppwclandingpage'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ADDON_PPWC_LOAD_LANDINGPAGE',
            'event_category': 'PPWCLanding',
            'event_action': 'PPWCLanding',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var pardot_mpp_contact_sales = {
        'name': 'pardot_mpp_contact_sales',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:::contact-us:::|main:mktg:::contact-sales:::|main:mktg:::business-contact-sales:::|main:mktg:::grow-business:::|main:mktg:business::contact-sales:::'
          }
        },
        'vendors': [{
          'name': 'pd',
          'vars': {
            'piAId': '926803',
            'piCId': '5717'
          }
        }]
      };
      var smart_chat = {
        'name': 'smart_chat',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:help:chat:sales:widget:::',
            'comp': 'smartchat'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_gb00j+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/33hnCJaoxvsCEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/FYLCCL-ix_sCELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/xIonCKCex_sCEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/zfp4CLqRx_sCEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/openchat'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_openchat'
          }
        }]
      };
      var mpp_master_creditcard = {
        'name': 'mpp_master_creditcard',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:personal:internal:digital-wallet-manage-money/paypal-cashback-mastercard:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu001/pp_na0+standard'
          }
        }]
      };
      var mpp_cshbck_master_card = {
        'name': 'mpp_cshbck_master_card',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg:business:product:cashback-card:::',
            'link': 'DvcHero-PrmryCTA-cta\\| Apply Now'
          }
        },
        'vendors': [{
          'name': 'gads',
          'vars': {
            'send_to': 'AW-992191228/DbYGCKXGt74DEPzFjtkD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_businesscashbackmastercardapplynow'
          }
        }]
      };
      var mpp_spotify_premium_landing = {
        'name': 'mpp_spotify_premium_landing',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us|uk|gb|ca|de', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:::spotify-premium-offer:::',
            'event_name': 'ppcom_page_viewed'
          }
        },
        'vendors': [{
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/xxr8CJu36pEYEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/t0S4CLnPhZIYELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/vCKKCI6qhZIYEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/Y6YtCPXJhZIYEJy7qMwD'
          }
        }]
      };
      var pp_merchant_ent_cnt_start_new = {
        'name': 'pp_merchant_ent_cnt_start_new',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:enterprise::contact-sales:::',
            'page_segment': 'enterprise'
          },
          'session': {
            'key': 'entcnt',
            'type': 'start'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/pp_gb002+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'enterprise form',
            'event_action': 'form start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_enterprisemerchantformcontactusstart'
          }
        }]
      };
      var mpp_googleplay_getgamin = {
        'name': 'mpp_googleplay_getgamin',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg:personal:campaign:google-play-2023:::',
            'pglk': 'main:mktg:personal:campaign:google-play-2023\\|info-hero-get-gaming'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_gb01+standard'
          }
        }]
      };
      var pp_merchant_ent_cnt_finish_new = {
        'name': 'pp_merchant_ent_cnt_finish_new',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'fs',
            'page': 'main:mktg:enterprise::contact-sales:::\\|form_action_submitted',
            'status': 'success'
          },
          'session': {
            'key': 'entcnt',
            'type': 'end'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/pp_gb003+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'enterprise form',
            'event_action': 'form complete',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/mjQWCJrVoO4BEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/IE21CPW_wO4BELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/QufeCM3BwO4BEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/KdwpCMrBwO4BEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/enterprisemerchantcontactfinish'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_enterprisemerchantformcontactusfinish'
          }
        }]
      };
      var mpp_partner_enterprise_form_submit = {
        'name': 'mpp_partner_enterprise_form_submit',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'fs',
            'page': 'main:mktg:enterprise:product:enterprise-become-a-partner:::\\|form_action_submitted',
            'status': 'success',
            'flnm': 'form_submit'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_na00_+standard'
          }
        }]
      };
      var mpp_enterprise_roadmap_form = {
        'name': 'mpp_enterprise_roadmap_form',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg:business:product:enterprise-business-roadmap/free-business-assessment:::',
            'event_name': 'enterprise_contactsales_cta_clicked',
            'pglk': 'main:mktg:business:product:enterprise-business-roadmap/free-business-assessment\\|FormContainer-Primary-Get Your Free Roadmap'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_na01+standard'
          }
        }]
      };
      var mpp_download_playbook_form = {
        'name': 'mpp_download_playbook_form',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg:business:product:enterprise-business-roadmap:::',
            'event_name': 'enterprise_contactsales_cta_clicked',
            'pglk': 'main:mktg:business:product:enterprise-business-roadmap\\|FormContainer-Primary-Form \\| Download Playbook'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_na010+standard'
          }
        }]
      };
      var mpp_crypto_stable_coin_start = {
        'name': 'mpp_crypto_stable_coin_start',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg:personal:product:digital-wallet-manage-money/crypto/pyusd:::',
            'event_name': 'consumer_button_cta_clicked',
            'link': 'Hero-Primary-Get Started|CardContentSectionItem-Primary-Get Started with PayPal USD'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_na00z+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/l95nCJ3g-eAYEPzFjtkD'
          }
        }]
      };
      var ppcom_page_viewed_im_events = {
        'name': 'ppcom_page_viewed_im_events',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:personal:homepage:home:::|main:mktg:personal:homepage:home-uncookied-consumer:::|main:mktg:personal:homepage:home-cookied-consumer:::|main:mktg:personal:product:digital-wallet-how-paypal-works:::|main:mktg:personal:product:digital-wallet-ways-to-pay:::|main:mktg:personal:product:digital-wallet-ways-to-pay/buy-now-pay-later:::|main:mktg:personal:product:digital-wallet-rewards:::|main:mktg:personal:product:digital-wallet-ways-to-pay/credit-services:::|main:mktg:personal:product:digital-wallet-ways-to-pay/checkout-with-paypal:::|main:mktg:personal:product:digital-wallet:::|main:mktg:personal:product:digital-wallet-send-receive-money:::|main:mktg:personal:product:digital-wallet-send-receive-money/send-money:::|main:mktg:personal:product:digital-wallet-send-receive-money/request-money:::|main:mktg:personal:product:digital-wallet-send-receive-money/giving:::|main:mktg:personal:product:digital-wallet-send-receive-money/start-selling:::|main:mktg:personal:product:digital-wallet-manage-money:::|main:mktg:personal:product:digital-wallet-ways-to-pay/add-payment-method:::|main:mktg:personal:security:digital-wallet-security-and-protection:::|main:mktg:personal:product:digital-wallet-manage-money/direct-deposit:::|main:mktg:personal:product:digital-wallet-manage-money/add-cash:::|main:mktg:personal:product:digital-wallet-manage-money/pay-bills:::|main:mktg:personal:product:digital-wallet-manage-money/start-saving:::|main:mktg:personal:product:digital-wallet-manage-money/crypto:::|main:mktg:moneyhub:home:::|main:mktg:both:product:account-selection',
            'event_name': 'ppcom_page_viewed'
          }
        },
        'vendors': [{
          'name': 'adobe'
        }]
      };
      var mpp_customize_ai_form_submit = {
        'name': 'mpp_customize_ai_form_submit',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg:business:campaign:campaigns-how-to-customize-customer-journey-with-ai:::|main:mktg:business:campaign:campaign-how-to-customize-customer-journey-with-ai:::',
            'event_name': 'enterprise_button_cta_clicked',
            'link': 'FormContainer-Primary-Read Now'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_na012+standard'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/customizejourneywithaiformsubmit'
          }
        }]
      };
      var mpp_innovation_form_submit = {
        'name': 'mpp_innovation_form_submit',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg:business:campaign:campaigns-enterprise/innovations:::|main:mktg:business:campaign:campaign-enterprise/innovations:::',
            'event_name': 'enterprise_button_cta_clicked',
            'link': 'FormContainer-Primary-Get In Touch form CTA'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_na011+standard'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/innovationsformsubmit'
          }
        }]
      };
      var mpp_consumer_app_dwnld_uk = {
        'name': 'mpp_consumer_app_dwnld_uk',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg:business:campaign:campaign-tap-to-pay-iphone:::',
            'event_name': 'smb_gettheapp_cta_clicked',
            'link': 'SplitSection-AppDownload-App Store Button|Hero-AppDownload-App Store Button|CardContentSectionItem-AppDownload-App Store Button'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu005/pp_em0+standard'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_ZettleappdownloadTTPLP'
          }
        }]
      };
      var mpp_hero_ebook_dwnld_au = {
        'name': 'mpp_hero_ebook_dwnld_au',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['au', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg:business:campaign:campaign-enterprise/utilities:::',
            'event_name': 'enterprise_button_cta_clicked',
            'link': 'Hero-Primary-Download the eBook'
          }
        },
        'vendors': [{
          'name': 'li',
          'vars': {
            'url': 'paypal.com/utilitiesebookdownload'
          }
        }]
      };
      var mpp_ecommerce_report_dwnld_au = {
        'name': 'mpp_ecommerce_report_dwnld_au',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['au', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:mktg:business:campaign:campaign-enterprise/ecommerce-index-2024:::',
            'event_name': 'enterprise_button_cta_clicked',
            'link': 'Hero-Primary-AU-ecommerce-Hero \\| Read the Report|SplitSection-Primary-Read the Report|CardContentSectionItem-Primary-AU\\| eCommerce\\| Download Report Now'
          }
        },
        'vendors': [{
          'name': 'li',
          'vars': {
            'url': 'paypal.com/ecommindex2024report'
          }
        }]
      };
      var merc_acc_summ = {
        'name': 'merc_acc_summ',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:businessweb:mep:dashboard:'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/accou0/merch0+standard'
          }
        }]
      };
      var biz_acc_su_end_mep = {
        'name': 'biz_acc_su_end_mep',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:businessweb:mep:dashboard:main|main:merchanthub:appcenter:main|main:businessweb:mep:dashboard:',
            'pglk': 'main:onbrd:falconnode::(personalInfo\\|personalInfoSubmitButton|create\\|createContinueButton|selfCertify\\|selfCertifySubmitButton|businessInfo\\|continueButton)|\\|doneButton'
          },
          'session': {
            'key': 'mercsu',
            'type': 'end'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch0/bizac00+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Mrs6CKX83dgBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/GaLzCKKQz9gBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/1_qJCLD6ztgBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/pnOjCJ70ztgBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'MerchantSignup'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: MerchantSUFin',
            'event_action': 'sign up finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 8: congrats',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Thanks for signing up',
            'dimension9': 'step 8: congrats',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantaccountsignupfinish'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_MSU_SIGNUP_FINISH',
            'event_category': 'MerchantSUFin',
            'event_action': 'MerchantSUFin',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var pers_acc_upg_fin_mep = {
        'name': 'pers_acc_upg_fin_mep',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:businessweb:mep:dashboard:main',
            'pglk': 'main:onbrd:falconnode::(personalInfo\\|personalInfoSubmitButton|create\\|createContinueButton|selfCertify\\|selfCertifySubmitButton|businessInfo\\|continueButton)'
          },
          'session': {
            'key': 'persupg',
            'type': 'end'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch0/acctu00+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Enh-CNWuz9gBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/Ez7PCNGbz9gBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/HzDvCLaDz9gBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/jM6-CMG8v9gBEJy7qMwD'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant upgrade',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 8: congrats',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Thanks for signing up',
            'dimension9': 'step 8: congrats',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }]
      };
      var biz_acc_su_get_started = {
        'name': 'biz_acc_su_get_started',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:businessweb:mep:dashboard:main:paypal_assistant_top',
            'link': 'add_profile_info'
          },
          'session': {
            'key': 'mercsu',
            'type': 'start'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant sign-up',
            'event_action': 'get started',
            'event_label': {
              'type': 'fn',
              'name': 'fetchSanatizedURL'
            }
          }
        }]
      };
      var biz_acc_su_end_2 = {
        'name': 'biz_acc_su_end_2',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:businessweb:mep:dashboard:',
            'pglk': 'main:unifiedonboardnodeweb\\|doneButton'
          },
          'session': {
            'key': 'mercsu',
            'type': 'end'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch0/bizac00+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Mrs6CKX83dgBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/GaLzCKKQz9gBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/1_qJCLD6ztgBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/pnOjCJ70ztgBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'MerchantSignup'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: MerchantSUFin',
            'event_action': 'sign up finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 8: congrats',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Thanks for signing up',
            'dimension9': 'step 8: congrats',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantaccountsignupfinish'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_MSU_SIGNUP_FINISH',
            'event_category': 'MerchantSUFin',
            'event_action': 'MerchantSUFin',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var mer_appcntr = {
        'name': 'mer_appcntr',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'flow': 'PP_COMMERCE_PLATFORM'
          }
        }
      };
      var mac_landing = {
        'name': 'mac_landing',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:merchanthub:appcenter:marketplaces'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/gbl_a0+standard'
          }
        }]
      };
      var mac_zettle = {
        'name': 'mac_zettle',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:merchanthub:appcenter:izettle'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/pp_gb00+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/gv-5CNmlvPQCEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/GcEHCKqpvPQCEJy7qMwD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/hQ-wCPKNkvQCEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/hOw-CJ2MkvQCELXZ6tkD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_zettle_appLoad'
          }
        }]
      };
      var mac_bonanza = {
        'name': 'mac_bonanza',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:merchanthub:appcenter:bonanza'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/gbl_a0+standard'
          }
        }]
      };
      var mac_grailed = {
        'name': 'mac_grailed',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:merchanthub:appcenter:grailed'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/gbl_a0+standard'
          }
        }]
      };
      var mac_wish = {
        'name': 'mac_wish',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:merchanthub:appcenter:wish'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/gbl_a0+standard'
          }
        }]
      };
      var mac_google = {
        'name': 'mac_google',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:merchanthub:appcenter:google'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/gbl_a0+standard'
          }
        }]
      };
      var mac_walmart = {
        'name': 'mac_walmart',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:merchanthub:appcenter:walmart'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/gbl_a0+standard'
          }
        }]
      };
      var mac_swappa = {
        'name': 'mac_swappa',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:merchanthub:appcenter:swappa'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/gbl_a0+standard'
          }
        }]
      };
      var mac_request_money_get_started = {
        'name': 'mac_request_money_get_started',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'event_name': 'appcenter_get_started_click'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/pp_gb004+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/E_-eCJe6xaUDEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/iqGcCLWJv6UDELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/0_CNCPLWxaUDEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/KYBaCJX9i6UDEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/requestmoneygetstarted'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_action': 'on click get stared',
            'event_category': 'appcenter request money',
            'event_label': {
              'type': 'fn',
              'name': 'fetchSanatizedURL'
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_requestmoneygetstarted'
          }
        }]
      };
      var mer_itx_start = {
        'name': 'mer_itx_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:businessweb:money:withdraw-funds:transfer-to::',
            'link': 'instant'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/merch0+standard'
          }
        }]
      };
      var mer_itx_end = {
        'name': 'mer_itx_end',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:businessweb:money:instant-funds:transfer-success::',
            'fltp': 'instant'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/merch00+standard'
          }
        }]
      };
      var cons_add_bank_start = {
        'name': 'cons_add_bank_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:moneynodeweb:money:banks:new|main:walletweb:wallet:(add:bankadd|bank)',
            'acnt': 'personal|premier'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/consw000+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/hITHCMqPvNwBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/hKFfCPqPvNwBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/caDzCOW9stwBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/H-5fCLjjzdwBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_consumerwalletaddbankstart'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_FUNDINGINST_CONS_ADDBANK_STRT',
            'event_category': 'account activity',
            'event_action': {
              'type': 'var',
              'obj': 'data',
              'path': 'acnt'
            },
            'event_label': 'link bank account start'
          }
        }]
      };
      var cons_add_bank_end_v2 = {
        'name': 'cons_add_bank_end_v2',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:moneynodeweb:(banks:new:confirmation|money:banks:confirmation|banks:confirmation:success)',
            'acnt': 'personal|premier'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/consu0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'account activity',
            'event_action': {
              'type': 'var',
              'obj': 'data',
              'path': 'acnt'
            },
            'event_label': 'link bank account'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_FUNDINGINST_CONS_ADDBANK_FIN',
            'event_category': 'account activity',
            'event_action': {
              'type': 'var',
              'obj': 'data',
              'path': 'acnt'
            },
            'event_label': 'link bank account'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/7FWPCK68stwBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/Ri5WCNndzdwBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/albtCN2NvNwBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/8nBhCM6NvNwBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_consumerwalletaddbankfinish'
          }
        }]
      };
      var cons_add_card_start = {
        'name': 'cons_add_card_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:walletweb:wallet::card:addcard|main:moneynodeweb:cards:new:manual',
            'acnt': 'personal|premier'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/consw0+standard'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_consumerwalletaddcardstart'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_FUNDINGINST_CONS_ADDCARD_STRT',
            'event_category': 'account activity',
            'event_action': {
              'type': 'var',
              'obj': 'data',
              'path': 'acnt'
            },
            'event_label': 'link card start'
          }
        }]
      };
      var cons_add_card_end = {
        'name': 'cons_add_card_end',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:walletweb:wallet::card:(addcardsuccess|completeconfirmation)|main:moneynodeweb:(new:manual:success|cards:confirmation:success)',
            'acnt': 'personal|premier'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/consw00+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'account activity',
            'event_action': {
              'type': 'var',
              'obj': 'data',
              'path': 'acnt'
            },
            'event_label': 'link card'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_FUNDINGINST_CONS_ADDCARD_FIN',
            'event_category': 'account activity',
            'event_action': {
              'type': 'var',
              'obj': 'data',
              'path': 'acnt'
            },
            'event_label': 'link card'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/2uP1COGRvNwBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/5rgVCLqRvNwBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/Bnw0CO2_stwBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/ZWJFCJ_lzdwBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_consumerwalletaddcard'
          }
        }]
      };
      var mer_add_bank_start = {
        'name': 'mer_add_bank_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:moneynodeweb:money:banks:new|main:walletweb:wallet:(add:bankadd|bank)',
            'acnt': 'business'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/merch0+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/dPI1CInYzdwBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/WKSRCPq3stwBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/FwUSCJCIvNwBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/0giECKWIvNwBEJy7qMwD'
          }
        }]
      };
      var mer_add_bank_end_v2 = {
        'name': 'mer_add_bank_end_v2',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:moneynodeweb:(banks:new:confirmation|money:banks:confirmation|banks:confirmation:success)',
            'acnt': 'business'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/merch00+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'account activity',
            'event_action': {
              'type': 'var',
              'obj': 'data',
              'path': 'acnt'
            },
            'event_label': 'link bank account'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/eDyxCPOCvNwBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/aujJCILUzdwBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/cal3CI6DvNwBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/b1AjCOvXzdwBEJy7qMwD'
          }
        }]
      };
      var mer_add_card_start = {
        'name': 'mer_add_card_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:walletweb:wallet::card:addcard|main:moneynodeweb:cards:new:manual',
            'acnt': 'business'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/merch000+standard'
          }
        }]
      };
      var mer_add_card_end = {
        'name': 'mer_add_card_end',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:walletweb:wallet::card:(addcardsuccess|completeconfirmation)|main:moneynodeweb:(new:manual:success|cards:confirmation:success)',
            'acnt': 'business'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/merch001+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'account activity',
            'event_action': {
              'type': 'var',
              'obj': 'data',
              'path': 'acnt'
            },
            'event_label': 'link card'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/NDjxCMe6stwBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/XbjZCMG6stwBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/vsaJCNrbzdwBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/Eu4rCOPbzdwBEJy7qMwD'
          }
        }]
      };
      var pers_acc_su_fin_reusable = {
        'name': 'pers_acc_su_fin_reusable',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:walletweb:summary::main:::|main:moneynodeweb:(cards:new:manual|money:banks:new):::',
            'pglk': 'main:onbrd:organic:reusable:profile:|main:onbrd:organic:signup:create\\|/appData/action'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/persa00+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Hv52CLWGs8cBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/jBTSCN2l9NcBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/T0apCKytv9gBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/g-dgCM_sztgBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'ConsumerSignup'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PersAcctSUFin',
            'event_action': 'sign up finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 4: success',
            'page_path': '/welcome/signup/intent_selection',
            'page_title': 'Select Intent',
            'dimension9': 'step 4: success',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            },
            'dimension46': 'true'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_CONSACCT_SIGNUP_FIN',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 4: success',
            'page_path': '/welcome/signup/intent_selection',
            'page_title': 'Select Intent',
            'dimension9': 'step 4: success',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            },
            'dimension46': 'true'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/consumersignupfinish'
          }
        }]
      };
      var setup_xo_1 = {
        'name': 'setup_xo_1',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'pgrp': 'main:business:web:hostedcheckout',
            'event_name': 'copy_cta_clicked'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/pp_gb006+standard'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_checkoutbuttonfinish'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/checkoutbuttonfinish'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'checkout exp',
            'event_action': 'click on Copy Code',
            'event_label': 'buttonfactory setup-checkout exp'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/F_tdCMiAyIACEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/QO4XCLfA54ACELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/4SpZCJaByIACEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/Kc06CImGyIACEJy7qMwD'
          }
        }]
      };
      var pers_acc_su_start = {
        'name': 'pers_acc_su_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:onbrd:organic:(signup:account|reusable:signup):::|main:onbrd:signup:organic:(gsl-popup::|email_password)'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/persa0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PersAcctSUStart',
            'event_action': 'sign up start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 2: account credentials',
            'page_path': '/welcome/signup/email_password',
            'page_title': 'Create Email and Password',
            'dimension9': 'step 2: account credentials',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_CONSACCT_SIGNUP_STRT',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 2: account credentials',
            'page_path': '/welcome/signup/email_password',
            'page_title': 'Create Email and Password',
            'dimension9': 'step 2: account credentials',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/6yJwCJSV--ABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/OJx5CPOn4OABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/H1pZCL-W--ABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/12oUCNGp4OABEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/consumersignupstart'
          }
        }]
      };
      var pers_acc_su_start_new = {
        'name': 'pers_acc_su_start_new',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:onbrd:signup:organic:login_info',
            'event_name': 'onboard_signup_details_screen_shown'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/persa0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PersAcctSUStart',
            'event_action': 'sign up start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 2: account credentials',
            'page_path': '/welcome/signup/email_password',
            'page_title': 'Create Email and Password',
            'dimension9': 'step 2: account credentials',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_CONSACCT_SIGNUP_STRT',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 2: account credentials',
            'page_path': '/welcome/signup/email_password',
            'page_title': 'Create Email and Password',
            'dimension9': 'step 2: account credentials',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/6yJwCJSV--ABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/OJx5CPOn4OABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/H1pZCL-W--ABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/12oUCNGp4OABEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/consumersignupstart'
          }
        }]
      };
      var guest_acc_upg_start = {
        'name': 'guest_acc_upg_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:onbrd:signup:upgrade:start:::',
            'flow': 'newton'
          },
          'session': {
            'key': 'gupgd',
            'type': 'start'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/guest001+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/EcAMCKzA4OABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/LX3_CLjA4OABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/uS1JCO_B4OABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/Ha8zCPWl--ABEJy7qMwD'
          }
        }]
      };
      var guest_acc_upg_fin = {
        'name': 'guest_acc_upg_fin',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:onbrd:signup:upgrade:intent:::',
            'flow': 'newton'
          },
          'session': {
            'key': 'gupgd',
            'type': 'end'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/guest000+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/xz7CCO3ov9gBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/pfHGCLHcv9gBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/fj6fCJXg3dgBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/v0XzCN7J3dgBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'ConsumerSignup'
          }
        }]
      };
      var pers_acc_su_fin_dis = {
        'name': 'pers_acc_su_fin_dis',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:onbrd:organic:reusable:redirect_add_card:::',
            'flow': 'mppdisneynna',
            'account_status': 'success'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/persa00+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Hv52CLWGs8cBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/jBTSCN2l9NcBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/T0apCKytv9gBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/g-dgCM_sztgBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'ConsumerSignup'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PersAcctSUFin',
            'event_action': 'sign up finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 4: success',
            'page_path': '/welcome/signup/intent_selection',
            'page_title': 'Select Intent',
            'dimension9': 'step 4: success',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            },
            'dimension46': 'true'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_CONSACCT_SIGNUP_FIN',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 4: success',
            'page_path': '/welcome/signup/intent_selection',
            'page_title': 'Select Intent',
            'dimension9': 'step 4: success',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            },
            'dimension46': 'true'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/consumersignupfinish'
          }
        }]
      };
      var xoom_pers_acc_su_fin = {
        'name': 'xoom_pers_acc_su_fin',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:onbrd:signup:xoom:success:::'
          }
        },
        'vendors': [{
          'name': 'fb',
          'vars': {
            'id': '236564939871335',
            'ev': 'PageView',
            'cd[CustomerID]': {
              'type': 'var',
              'obj': 'data',
              'path': 'cust'
            }
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-986779018/T--DCJG7vv4BEIqbxNYD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_xoomconsumersignupfinish',
            'cd[CustomerID]': {
              'type': 'var',
              'obj': 'data',
              'path': 'cust'
            }
          }
        }, {
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/pp_na00+standard',
            'u1': {
              'type': 'var',
              'obj': 'data',
              'path': 'cust'
            }
          }
        }]
      };
      var xoom_pers_acc_su_start = {
        'name': 'xoom_pers_acc_su_start',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:onbrd:signup:linkaccount:start:::',
            'pglk': 'main:onbrd:signup:linkaccount:\\|next'
          }
        },
        'vendors': [{
          'name': 'fb',
          'vars': {
            'ev': 'fb_xoomconsumersignupstart'
          }
        }, {
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/pp_na0+standard'
          }
        }]
      };
      var xoom_pers_acc_su_fin_2 = {
        'name': 'xoom_pers_acc_su_fin_2',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:onbrd:signup:linkaccount:success:::',
            'account_status': 'success'
          }
        },
        'vendors': [{
          'name': 'fb',
          'vars': {
            'id': '236564939871335',
            'ev': 'PageView',
            'cd[CustomerID]': {
              'type': 'var',
              'obj': 'data',
              'path': 'cust'
            }
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-986779018/T--DCJG7vv4BEIqbxNYD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_xoomconsumersignupfinish',
            'cd[CustomerID]': {
              'type': 'var',
              'obj': 'data',
              'path': 'cust'
            }
          }
        }, {
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/pp_na00+standard',
            'u1': {
              'type': 'var',
              'obj': 'data',
              'path': 'cust'
            }
          }
        }]
      };
      var acc_su_start_edison = {
        'name': 'acc_su_start_edison',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'page': 'main:onbrd:signup:partner:profile',
            'tsrce': 'progressivenodeweb'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/pp_gb0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'partner onboarding sign-up',
            'event_action': 'edison signup start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/lnz0COPP0twBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/o96ECLXn29wBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/n0FcCJnp29wBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/ziAyCIHp29wBEJy7qMwD'
          }
        }]
      };
      var acc_su_fin_edison = {
        'name': 'acc_su_fin_edison',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:onbrd:signup:partner:success:',
            'account_status': 'success',
            'tsrce': 'progressivenodeweb'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/pp_gb00+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'partner onboarding sign-up',
            'event_action': 'edison signup complete',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/OLG8CLrj29wBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/-1lgCMLl29wBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/jsYHCIzl29wBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/ktZGCOTN0twBEJy7qMwD'
          }
        }]
      };
      var p2p_send_mon_start = {
        'name': 'p2p_send_mon_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:p2p:(unified:)?send::(email|review|phone):node::|main:consumer:p2p:(transfer:xb:country|gift:start)|main:p2p:transfer:xb:start'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/sendm0+standard',
            'u3': {
              'type': 'int',
              'path': 'laDataLayer.txn_amt',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: ConsumerSendMoneyStart',
            'event_action': 'start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/OTMTCOfK7eABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/w2KECKn__OABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/037lCIyD_eABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/A0crCM2C_eABEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['de|uk|gb', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_EMEA'
          }
        }]
      };
      var req_mon_start = {
        'name': 'req_mon_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:p2p:request:(multi)?:review:node::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/reqmo0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: ConsumerReqMoneyStart',
            'event_action': 'start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/vus5COnkvssDEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/A-3cCMmOj8sDELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/te1RCO-cj8sDEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/GM5ACKWjw8sDEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['de|uk|gb', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_EMEA'
          }
        }]
      };
      var req_mon_fin = {
        'name': 'req_mon_fin',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:p2p:request:(multi)?:done:node::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/reqmo00+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: ConsumerReqMoneyFin',
            'event_action': 'finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'request money',
            'event_action': 'request',
            'event_label': 'request',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_TXN_P2P_REQUESTMONEY_FIN',
            'event_category': 'request money',
            'event_action': 'request',
            'event_label': 'request',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/u749CI7__OABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/81qRCNmG4uABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/fJkqCOWM4uABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/rCVACL2O4uABEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['de|uk|gb', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_EMEA'
          }
        }]
      };
      var p2p_send_mon = {
        'name': 'p2p_send_mon',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:p2p:unified:send::done'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'send money/pay',
            'event_action': 'send',
            'event_label': 'send money to friends and family',
            'event_value': {
              'type': 'int',
              'path': 'laDataLayer.txn_amt',
              'defaultVal': ''
            },
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_TXN_P2P_SENDMONEY_FIN',
            'event_category': 'send money/pay',
            'event_action': 'send',
            'event_label': 'send money to friends and family',
            'event_value': {
              'type': 'int',
              'path': 'laDataLayer.txn_amt',
              'defaultVal': ''
            },
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/sendm00+standard',
            'u3': {
              'type': 'int',
              'path': 'laDataLayer.txn_amt',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/vTMUCMDQv9gBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/n0oQCNmUz9gBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/noBcCKfa3dgBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/NFdZCMDJ3dgBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['de|uk|gb', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_EMEA'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'Transaction-SndMnyP2PPayFlow-P2PPayFlow'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: ConsumerSendMoneyFin',
            'event_action': 'finish',
            'event_label': 'send money to friends and family'
          }
        }]
      };
      var p2p_send_mon_int = {
        'name': 'p2p_send_mon_int',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:p2p:send::done',
            'pp_flow': 'xb'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'send money/pay',
            'event_action': 'send',
            'event_label': 'send to friends and family internationally',
            'event_value': {
              'type': 'int',
              'path': 'laDataLayer.txn_amt',
              'defaultVal': ''
            },
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_TXN_P2P_SENDMONEY_FIN',
            'event_category': 'send money/pay',
            'event_action': 'send',
            'event_label': 'send to friends and family internationally',
            'event_value': {
              'type': 'int',
              'path': 'laDataLayer.txn_amt',
              'defaultVal': ''
            },
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/sendm00+standard',
            'u3': {
              'type': 'int',
              'path': 'laDataLayer.txn_amt',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/vTMUCMDQv9gBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/n0oQCNmUz9gBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/noBcCKfa3dgBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/NFdZCMDJ3dgBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['de|uk|gb', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_EMEA'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'Transaction-SndMnyP2PPayFlow-P2PPayFlow'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: ConsumerSendMoneyFin',
            'event_action': 'finish',
            'event_label': 'send to friends and family internationally'
          }
        }]
      };
      var p2p_send_gift = {
        'name': 'p2p_send_gift',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:p2p:gift::done'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'send gift',
            'event_action': 'send',
            'event_label': 'send a gift',
            'event_value': {
              'type': 'int',
              'path': 'laDataLayer.txn_amt',
              'defaultVal': ''
            },
            'dimension11': {
              'type': 'var',
              'path': 'fpti.sndcur'
            },
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_TXN_P2P_SENDMONEY_FIN',
            'event_category': 'send gift',
            'event_action': 'send',
            'event_label': 'send a gift',
            'event_value': {
              'type': 'int',
              'path': 'laDataLayer.txn_amt',
              'defaultVal': ''
            },
            'dimension11': {
              'type': 'var',
              'path': 'fpti.sndcur'
            },
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/sendm00+standard',
            'u3': {
              'type': 'int',
              'path': 'laDataLayer.txn_amt',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/vTMUCMDQv9gBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/n0oQCNmUz9gBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/noBcCKfa3dgBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/NFdZCMDJ3dgBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['de|uk|gb', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_EMEA'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'Transaction-SndMnyP2PPayFlow-P2PPayFlow'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: ConsumerSendMoneyFin',
            'event_action': 'finish',
            'event_label': 'send a gift'
          }
        }]
      };
      var p2p_buy = {
        'name': 'p2p_buy',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:p2p:unified:buy::done'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'send money/pay',
            'event_action': 'pay',
            'event_label': 'pay for goods or services',
            'event_value': {
              'type': 'int',
              'path': 'laDataLayer.txn_amt',
              'defaultVal': ''
            },
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_TXN_P2P_SENDMONEY_FIN',
            'event_category': 'send money/pay',
            'event_action': 'pay',
            'event_label': 'pay for goods or services',
            'event_value': {
              'type': 'int',
              'path': 'laDataLayer.txn_amt',
              'defaultVal': ''
            },
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/sendm00+standard',
            'u3': {
              'type': 'int',
              'path': 'laDataLayer.txn_amt',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/vTMUCMDQv9gBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/n0oQCNmUz9gBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/noBcCKfa3dgBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/NFdZCMDJ3dgBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['de|uk|gb', 'fetchCountry']
          },
          'vars': {
            'ev': 'fb_EngagementTest2023_EMEA'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'Transaction-SndMnyP2PPayFlow-P2PPayFlow'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: ConsumerSendMoneyFin',
            'event_action': 'finish',
            'event_label': 'pay for goods or services'
          }
        }]
      };
      var p2p_mer_req_mny_start = {
        'name': 'p2p_mer_req_mny_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:p2p:tab-request::start:::'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'MERCHANT REQMONEY',
            'event_action': 'start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/pp_gb009+standard'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_merchantp2prequestmoneystart'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/_tcRCJHmkLQDEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/4wHoCPevxLQDELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/U6OxCNOFxrQDEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/dYouCLHGxLQDEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantp2prequestmoneystart'
          }
        }]
      };
      var p2p_mer_req_mny_fin = {
        'name': 'p2p_mer_req_mny_fin',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:p2p:request:multi:done:node::',
            'link': 'requestDone',
            'email': 'confirmed'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'MERCHANT REQMONEY',
            'event_action': 'finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/pp_gb00-+standard'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_merchantp2prequestmoneyfinish'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/y1C-CMSUxrQDEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/0f1qCPzSxLQDELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/uWXICLvTxLQDEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/X8VACPXaxLQDEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantp2prequestmoneyfinish'
          }
        }]
      };
      var p2p_mer_send_mny_start = {
        'name': 'p2p_mer_send_mny_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:p2p:tab-send::start:::'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'MERCHANT SENDMONEY',
            'event_action': 'start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/pp_gb00a+standard'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_merchantp2psendmoneystart'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/bqy0CM_f7LQDEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/JqPhCL_z7LQDELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/4YgqCNfz7LQDEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/-ZsQCPntubQDEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantp2psendmoneystart'
          }
        }]
      };
      var p2p_mer_send_mny_fin = {
        'name': 'p2p_mer_send_mny_fin',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:p2p:unified:send::done:node::',
            'link': 'send'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'MERCHANT SENDMONEY',
            'event_action': 'finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch000/pp_gb00b+standard'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_merchantp2psendmoneyfinish'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/s-QBCJGT77QDEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/7nwBCLiN77QDELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/BZ3TCJX87rQDEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/0v_KCOT2ubQDEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantp2psendmoneyfinish'
          }
        }]
      };
      var pad_enroll = {
        'name': 'pad_enroll',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['au', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im'
          }
        }
      };
      var pypl_savings_userinfo = {
        'name': 'pypl_savings_userinfo',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:policydashboardweb:process:compliance:hys:personal:US:hys_cip_w9:w9_cip_data_collection::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu001/pp_na001+standard'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-992191228/RxPLCLvLnr4DEPzFjtkD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/paypalsavinguserinfo'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_paypalsavinguserinfo'
          }
        }]
      };
      var mp_send_amt_ga = {
        'name': 'mp_send_amt_ga',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:pools:send::amount:::',
            'pglk': 'main:pools:campaign::page|chipIn'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'send money pools',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 1: send money',
            'page_path': '/pools/c/send/amount',
            'page_title': 'Chip in to a pool',
            'dimension9': 'step 1: send money',
            'dimension10': 'pools'
          }
        }]
      };
      var mp_send_note_ga = {
        'name': 'mp_send_note_ga',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:pools:(send::note:::|guest::note:::)'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'send money pools',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 2: add comment',
            'page_path': '/pools/c/send/note',
            'page_title': 'Add a comment',
            'dimension9': 'step 2: add comment',
            'dimension10': 'pools'
          }
        }]
      };
      var mp_send_review_ga = {
        'name': 'mp_send_review_ga',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:(pools:send::review:::|p2p:guest:preview:)'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'send money pools',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 3: review',
            'page_path': '/pools/c/send/review',
            'page_title': 'Confirm transfer',
            'dimension9': 'step 3: review',
            'dimension10': 'pools'
          }
        }]
      };
      var mp_create_pref_ga = {
        'name': 'mp_create_pref_ga',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:pools:create::preferences:::'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'create money pools',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 2: pool preferences',
            'page_path': '/pools/c/create/preferences',
            'page_title': 'How much can contributors pay?',
            'dimension9': 'step 2: pool preferences',
            'dimension10': 'pools'
          }
        }]
      };
      var mp_create_desc_ga = {
        'name': 'mp_create_desc_ga',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:pools:create::description:::'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'create money pools',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 3: pool description',
            'page_path': '/pools/c/create/description',
            'page_title': 'Describe your pool',
            'dimension9': 'step 3: pool description',
            'dimension10': 'pools'
          }
        }]
      };
      var mp_create_prev_ga = {
        'name': 'mp_create_prev_ga',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:pools:create::preview:::'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'create money pools',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 4: pool preview',
            'page_path': '/pools/c/create/preview',
            'page_title': 'Preview your money pool',
            'dimension9': 'step 4: pool preview',
            'dimension10': 'pools'
          }
        }]
      };
      var mp_create_prepub_ga = {
        'name': 'mp_create_prepub_ga',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:pools:create::prepublish:::'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'create money pools',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 5: pool prepublish',
            'page_path': '/pools/c/create/prepublish',
            'page_title': 'Ready to publish',
            'dimension9': 'step 5: pool prepublish',
            'dimension10': 'pools'
          }
        }]
      };
      var chipIn_send_guest = {
        'name': 'chipIn_send_guest',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:pools:guest::amount:::',
            'pglk': 'main:pools:guest::amount|next'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'send money pools',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 1: send money',
            'page_path': '/pools/c/send/amount',
            'page_title': 'Chip in to a pool',
            'dimension9': 'step 1: send money',
            'dimension10': 'pools'
          }
        }]
      };
      var chipIn_end_guest = {
        'name': 'chipIn_end_guest',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:(pools:campaign-xxx-send-success:::|transfer:guest:success:)'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'send money pools',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 4: transfer success',
            'page_path': '/pools/c/send/complete',
            'page_title': 'Chip in complete',
            'dimension9': 'step 4: transfer success',
            'dimension10': 'pools'
          }
        }]
      };
      var mp_fundraiser_create_finish = {
        'name': 'mp_fundraiser_create_finish',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:pools:campaign-create-success:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/pp_gb005+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/G1y2CNjA74AYEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/Js4lCMPU8IAYELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/98eXCJvg7YAYEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/DF18CP7d7YAYEJy7qMwD'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'fundraiser account',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'create fundraiser account finish'
          }
        }]
      };
      var mp_fundraiser_withdraw_start = {
        'name': 'mp_fundraiser_withdraw_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:pools:withdraw::amount:::',
            'event_name': 'dw_giving_fundraiser_transfer_screen_shown'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/pp_gb008+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'withdraw fundraiser for self',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'withdraw money start'
          }
        }]
      };
      var mp_fundraiser_withdraw_finish = {
        'name': 'mp_fundraiser_withdraw_finish',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:pools:withdraw::complete:::',
            'event_name': 'dw_giving_fundraiser_transfer_success_screen_shown'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/pp_gb009+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'withdraw fundraiser for self',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'withdraw money finish'
          }
        }]
      };
      var landing_mpp_workingcapital = {
        'name': 'landing_mpp_workingcapital',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:business:product:business-financial-services/working-capital:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch001/ppwcl0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PPWCLanding',
            'event_action': 'landing page',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/2S9QCJK9iIwDEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/xx35CIbfpowDELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/tS21CL_NiYwDEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/id_0CLiC4YsDEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_ppwclandingpage'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ADDON_PPWC_LOAD_LANDINGPAGE',
            'event_category': 'PPWCLanding',
            'event_action': 'PPWCLanding',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var account_selection_get_started_clicked = {
        'name': 'account_selection_get_started_clicked',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'ccpg': 'US',
            'event_name': 'general_button_cta_clicked',
            'link': 'AccountSelection-Get a Personal Account-Primary-Get a Personal Account'
          }
        },
        'vendors': [{
          'name': 'adobe'
        }]
      };
      var ppcms_payin4_contactsales_au = {
        'name': 'ppcms_payin4_contactsales_au',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['au', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:mktg:enterprise:product:business-enterprise/pay-in-4/thank-you:::',
            'event_name': 'ppcom_page_viewed',
            'pglk': 'main:mktg:business:product:business-enterprise/pay-in-4|FormContainer-Primary-Submit'
          }
        },
        'vendors': [{
          'name': 'li',
          'vars': {
            'url': 'paypal.com/entrpayin4contactsales'
          }
        }]
      };
      var ppdg_land = {
        'name': 'ppdg_land',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:consumer:gifts:home:'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/gener0/ppdgl0+standard'
          }
        }]
      };
      var ppdg_txn_start = {
        'name': 'ppdg_txn_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:consumer:gifts:cart:'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/gener0/ppdgs0+standard'
          }
        }]
      };
      var ppdg_txn_end = {
        'name': 'ppdg_txn_end',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:consumer:gifts:cart:success:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/gener0/ppdge0+standard'
          }
        }]
      };
      var ppme_start = {
        'name': 'ppme_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:ppme:create:welcome:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/gener0/paypa0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PayPalMeSUStart',
            'event_action': 'start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/ySx9COr1jZICEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/-lOeCOr_h5ICELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/In9gCJqGiJICEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/V1HwCLOZ6ZECEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/paypalmesignupstart'
          }
        }]
      };
      var ppme_end = {
        'name': 'ppme_end',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:ppme:create:done:::'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/gener0/paypa00+standard'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'ProductSignup-PayPalMeSUFin-PayPalMe'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PayPalMeSUFin',
            'event_action': 'finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/SXOTCKiR6ZECEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/V4m3CKmV6ZECELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/dMCgCJuZ6ZECEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/NbdxCPaa6ZECEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/paypalmesignupfinish'
          }
        }]
      };
      var pers_acc_su_fin_new = {
        'name': 'pers_acc_su_fin_new',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:onbrd:signup:organic:intent',
            'account_status': 'success',
            'event_name': 'onboard_create_account_success_occurred',
            'pglk': 'main:onbrd:signup:organic\\|paypalAccountData_emailPassword|main:onbrd:signup:organic\\|paypalAccountData_createAccountSubmitBtn'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/persa00+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Hv52CLWGs8cBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/jBTSCN2l9NcBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/T0apCKytv9gBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/g-dgCM_sztgBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'ConsumerSignup'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PersAcctSUFin',
            'event_action': 'sign up finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 4: success',
            'page_path': '/welcome/signup/intent_selection',
            'page_title': 'Select Intent',
            'dimension9': 'step 4: success',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            },
            'dimension46': 'true'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_CONSACCT_SIGNUP_FIN',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 4: success',
            'page_path': '/welcome/signup/intent_selection',
            'page_title': 'Select Intent',
            'dimension9': 'step 4: success',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            },
            'dimension46': 'true'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/consumersignupfinish'
          }
        }]
      };
      var pers_acc_su_fin_new_1 = {
        'name': 'pers_acc_su_fin_new_1',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:onbrd:organic:reusable:signup_success:::',
            'event_name': 'onboard_create_account_success_occurred',
            'pglk': 'main:onbrd:organic:reusable:profile:\\|paypalAccountData_emailPassword'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/persa00+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Hv52CLWGs8cBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/jBTSCN2l9NcBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/T0apCKytv9gBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/g-dgCM_sztgBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'ConsumerSignup'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PersAcctSUFin',
            'event_action': 'sign up finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 4: success',
            'page_path': '/welcome/signup/intent_selection',
            'page_title': 'Select Intent',
            'dimension9': 'step 4: success',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            },
            'dimension46': 'true'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_CONSACCT_SIGNUP_FIN',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 4: success',
            'page_path': '/welcome/signup/intent_selection',
            'page_title': 'Select Intent',
            'dimension9': 'step 4: success',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            },
            'dimension46': 'true'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/consumersignupfinish'
          }
        }]
      };
      var psu_credit_succ = {
        'name': 'psu_credit_succ',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:creditapplyweb:decisionpage:APPROVED::::'
          },
          'session': {
            'key': 'psucredit',
            'type': 'end'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/persa00+standard'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'ConsumerSignup'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PersAcctSUFin',
            'event_action': 'sign up finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'credit application'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_CONSACCT_SIGNUP_FIN',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'credit application'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-992191228/Hv52CLWGs8cBEPzFjtkD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/consumersignupfinish'
          }
        }]
      };
      var psu_credit_decl = {
        'name': 'psu_credit_decl',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:creditapplyweb:decisionpage:DECLINED::::'
          },
          'session': {
            'key': 'psucredit',
            'type': 'end'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/persa00+standard'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'ConsumerSignup'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PersAcctSUFin',
            'event_action': 'sign up finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'credit application'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_CONSACCT_SIGNUP_FIN',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'credit application'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-992191228/Hv52CLWGs8cBEPzFjtkD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/consumersignupfinish'
          }
        }]
      };
      var tesla_su_create = {
        'name': 'tesla_su_create',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:onbrd:organic:signup:(create|addresslookup)'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 3: personal details',
            'page_path': '/welcome/signup/name_address',
            'page_title': 'Enter Personal Info',
            'dimension9': 'step 3: personal details',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ADON_SIGNUP_ACTVN_PRSNLINFOPGLOAD',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 3: personal details',
            'page_path': '/welcome/signup/name_address',
            'page_title': 'Enter Personal Info',
            'dimension9': 'step 3: personal details',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }]
      };
      var tesla_su_create_1 = {
        'name': 'tesla_su_create_1',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:onbrd:signup:organic:basic_info'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 3: personal details',
            'page_path': '/welcome/signup/name_address',
            'page_title': 'Enter Personal Info',
            'dimension9': 'step 3: personal details',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ADON_SIGNUP_ACTVN_PRSNLINFOPGLOAD',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 3: personal details',
            'page_path': '/welcome/signup/name_address',
            'page_title': 'Enter Personal Info',
            'dimension9': 'step 3: personal details',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }]
      };
      var tesla_su_addcard_start = {
        'name': 'tesla_su_addcard_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:(onbrd:organic:wallet:addcard|progressive:welcome:complete:addcard)'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 5: add card',
            'page_path': '/welcome/signup/add_card',
            'page_title': 'Add Card',
            'dimension9': 'step 5: add card',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_FUNDINGINST_CONS_ADDCARD_STRT',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 5: add card',
            'page_path': '/welcome/signup/add_card',
            'page_title': 'Add Card',
            'dimension9': 'step 5: add card',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/consw0+standard'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_consumerwalletaddcardstart'
          }
        }]
      };
      var tesla_su_addcard_fin = {
        'name': 'tesla_su_addcard_fin',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'pglk': 'main:onbrd:organic:wallet:addcard\\|linkcard|main:onbrd:organic:wallet:selectIntent|addcard'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 5: add card',
            'page_title': 'Add Card',
            'dimension9': 'step 5: add card',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_FUNDINGINST_CONS_ADDCARD_FIN',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 5: add card',
            'page_title': 'Add Card',
            'dimension9': 'step 5: add card',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/consw00+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'account activity',
            'event_action': {
              'type': 'var',
              'obj': 'data',
              'path': 'acnt'
            },
            'event_label': 'link card'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/2uP1COGRvNwBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/5rgVCLqRvNwBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/Bnw0CO2_stwBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/ZWJFCJ_lzdwBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_consumerwalletaddcard'
          }
        }]
      };
      var tesla_su_addbank_start = {
        'name': 'tesla_su_addbank_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:onbrd:organic:wallet:addbank'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 6: add bank',
            'page_path': '/welcome/signup/add_bank',
            'page_title': 'Add Bank',
            'dimension9': 'step 6: add bank',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_FUNDINGINST_CONS_ADDBANK_STRT',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 6: add bank',
            'page_path': '/welcome/signup/add_bank',
            'page_title': 'Add Bank',
            'dimension9': 'step 6: add bank',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/consw000+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/hITHCMqPvNwBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/hKFfCPqPvNwBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/caDzCOW9stwBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/H-5fCLjjzdwBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_consumerwalletaddbankstart'
          }
        }]
      };
      var tesla_su_addbank_fin = {
        'name': 'tesla_su_addbank_fin',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'pglk': 'main:onbrd:organic:wallet:addbank'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 6: add bank',
            'page_path': '/welcome/signup/add_bank',
            'page_title': 'Add Bank',
            'dimension9': 'step 6: add bank',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_FUNDINGINST_CONS_ADDBANK_FIN',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 6: add bank',
            'page_path': '/welcome/signup/add_bank',
            'page_title': 'Add Bank',
            'dimension9': 'step 6: add bank',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/consu0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'account activity',
            'event_action': {
              'type': 'var',
              'obj': 'data',
              'path': 'acnt'
            },
            'event_label': 'link bank account'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/7FWPCK68stwBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/Ri5WCNndzdwBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/albtCN2NvNwBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/8nBhCM6NvNwBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_consumerwalletaddbankfinish'
          }
        }]
      };
      var tesla_su_buy = {
        'name': 'tesla_su_buy',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:onbrd:organic:bgc:buyselltransfer'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 7: activation',
            'page_path': '/welcome/signup/activation',
            'page_title': 'Sign Up Complete',
            'dimension8': 'active',
            'dimension9': 'step 7: activation',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ADON_SIGNUP_ACTVN_PGLOAD',
            'event_category': 'consumer sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 7: activation',
            'page_path': '/welcome/signup/activation',
            'page_title': 'Sign Up Complete',
            'dimension8': 'active',
            'dimension9': 'step 7: activation',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            }
          }
        }]
      };
      var ppcom_intent_selection = {
        'name': 'ppcom_intent_selection',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'pgsf': 'personal',
            'event_name': 'onboard_intent_selection_tile_pressed'
          }
        },
        'vendors': [{
          'name': 'adobe'
        }]
      };
      var ppcom_onboard_flow_details_tracking = {
        'name': 'ppcom_onboard_flow_details_tracking',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'event_name': 'onboard_signup_details_screen_shown',
            'pgsf': 'personal'
          }
        },
        'vendors': [{
          'name': 'adobe'
        }]
      };
      var ppcom_onboard_flow_phone_entry_tracking = {
        'name': 'ppcom_onboard_flow_phone_entry_tracking',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'event_name': 'onboard_phone_entry_screen_shown',
            'pgsf': 'personal'
          }
        },
        'vendors': [{
          'name': 'adobe'
        }]
      };
      var ppcom_onboard_flow_phone_confirmation_tracking = {
        'name': 'ppcom_onboard_flow_phone_confirmation_tracking',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'event_name': 'onboard_phone_confirmation_screen_shown',
            'pgsf': 'personal'
          }
        },
        'vendors': [{
          'name': 'adobe'
        }]
      };
      var ppcom_onboard_flow_password_details_tracking = {
        'name': 'ppcom_onboard_flow_password_details_tracking',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'event_name': 'onboard_password_details_screen_shown',
            'pgsf': 'personal'
          }
        },
        'vendors': [{
          'name': 'adobe'
        }]
      };
      var ppcom_onboard_flow_personal_info_tracking = {
        'name': 'ppcom_onboard_flow_personal_info_tracking',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'event_name': 'onboard_personal_info_screen_shown',
            'pgsf': 'personal'
          }
        },
        'vendors': [{
          'name': 'adobe'
        }]
      };
      var ppcom_onboard_flow_account_success_tracking = {
        'name': 'ppcom_onboard_flow_account_success_tracking',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'event_name': 'onboard_create_account_success_occurred',
            'pgsf': 'personal'
          }
        },
        'vendors': [{
          'name': 'adobe'
        }]
      };
      var qrc_su_fin_2 = {
        'name': 'qrc_su_fin_2',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'event_name': 'qrc_merchant_home_download_pressed'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_gb004+standard'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/qrgeneration'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/RcArCJmAvPQCEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/ouPTCILLvfQCEJy7qMwD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/0BP_CJPwkfQCEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/yc5nCP3rkfQCELXZ6tkD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_qrgeneration'
          }
        }]
      };
      var save_pypl_application_start = {
        'name': 'save_pypl_application_start',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'event_name': 'dw_savings_onboard_start_pressed',
            'page': 'savingsnodeweb/index.dust|main:savings:get_started'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu001/pp_na00+standard'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-992191228/lkH3COPOy7oDEPzFjtkD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/paypalsavingapplicationstart'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'PAYPAL SAVING',
            'event_action': 'Application Start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_paypalsavingapplicationstart'
          }
        }]
      };
      var finishline_offers = {
        'name': 'finishline_offers',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'event_name': 'shopping_merchant_code_pressed|shopping_merchant_deal_pressed',
            'store_name': 'Finish Line'
          }
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'shopping store',
            'event_action': 'click button',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-992191228/m-4_CJP1q_0BEPzFjtkD'
          }
        }]
      };
      var save_offers = {
        'name': 'save_offers',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'event_name': 'shopping_offer_detail_cta_pressed',
            'page_variant': 'Save Offer'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_na00m+standard'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-992191228/YE3lCL6jwPQCEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-965352860/ASJfCPHewfQCEJy7qMwD'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-1006288171/HdsaCM2WlvQCEKv66t8D'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-993701045/0kcVCPKqwPQCELXZ6tkD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_shoppingsaveoffer'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'shopping',
            'event_action': 'save offer',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var shop_now = {
        'name': 'shop_now',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'event_name': 'shopping_offer_detail_cta_pressed',
            'page_variant': 'Shop Now'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_gb00i+standard'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-992191228/DZaJCLCGwvQCEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-965352860/5X9rCJyzlvQCEJy7qMwD'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-1006288171/UnWsCLzOwPQCEKv66t8D'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-993701045/DSfnCPXOwPQCELXZ6tkD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_shopnow'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'shopping',
            'event_action': 'shop now',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var sb_shop_now = {
        'name': 'sb_shop_now',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'event_name': 'shopping_offer_deal_detail_button_pressed',
            'link_name': 'shop now'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_gb00i+standard'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-992191228/DZaJCLCGwvQCEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-965352860/5X9rCJyzlvQCEJy7qMwD'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-1006288171/UnWsCLzOwPQCEKv66t8D'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-993701045/DSfnCPXOwPQCELXZ6tkD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_shopnow'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'shopping',
            'event_action': 'shop now',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var sb_save_offers = {
        'name': 'sb_save_offers',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'event_name': 'shopping_offer_deal_detail_button_pressed',
            'link_name': 'save'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/mppmz0/pp_na00m+standard'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-992191228/YE3lCL6jwPQCEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-965352860/ASJfCPHewfQCEJy7qMwD'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-1006288171/HdsaCM2WlvQCEKv66t8D'
          }
        }, {
          'name': 'gads',
          'vars': {
            'send_to': 'AW-993701045/0kcVCPKqwPQCELXZ6tkD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_shoppingsaveoffer'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'shopping',
            'event_action': 'save offer',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var cons_acc_summ = {
        'name': 'cons_acc_summ',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:walletweb:summary::main'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/accou0/consu0+standard'
          }
        }]
      };
      var ppcom_landing_summary_page = {
        'name': 'ppcom_landing_summary_page',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'ccpg': 'US',
            'event_name': 'consumer_home_viewed'
          }
        },
        'vendors': [{
          'name': 'adobe'
        }]
      };
      var crypto_landing_page = {
        'name': 'crypto_landing_page',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'evnt_type': 'im',
            'event_name': 'crypto_wallet_info_screen_shown',
            'product': 'crypto'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/pp_na0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'crypto wallet',
            'event_action': 'landing page',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var crypto_start_activation = {
        'name': 'crypto_start_activation',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'evnt_type': 'cl',
            'event_name': 'crypto_info_confirmation_continue_pressed',
            'product': 'crypto'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/pp_na00+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'crypto wallet',
            'event_action': 'activation start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var crypto_finish_activation = {
        'name': 'crypto_finish_activation',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'evnt_type': 'ac',
            'event_name': 'crypto_account_info_confirm_screen_shown',
            'product': 'crypto'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/pp_na000+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'crypto wallet',
            'event_action': 'activation finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var crypto_finish_purchase = {
        'name': 'crypto_finish_purchase',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'evnt_type': 'ac',
            'event_name': 'crypto_buy_success_screen_shown',
            'product': 'crypto'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/pp_na001+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'crypto wallet',
            'event_action': 'purchase finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var crypto_finish_sell = {
        'name': 'crypto_finish_sell',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'evnt_type': 'ac',
            'event_name': 'crypto_sale_success_screen_shown',
            'product': 'crypto'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/pp_na002+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'crypto wallet',
            'event_action': 'sell finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var crypto_finish_first_purchase = {
        'name': 'crypto_finish_first_purchase',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'evnt_type': 'im',
            'event_name': 'crypto_first_purchase_success_interstitial_shown',
            'product': 'crypto'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/pp_na003+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'crypto wallet',
            'event_action': 'first purchase finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'CryptoFTU'
          }
        }]
      };
      var ccfullsu_start = {
        'name': 'ccfullsu_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'cl',
            'page': 'main:debitcards:enrollCard:eligibleLanding',
            'event_name': 'ucs_enroll_landing_get_card_pressed',
            'link': 'getCardButton'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu000/paypa0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'cash card full',
            'event_action': 'sign up start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.cust',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ADON_PPCASHCARD_SIGNUP_STRT',
            'event_category': 'cash card full',
            'event_action': 'sign up start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.cust',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Dv3NCJqq9pAYEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/aSw2CJaj7pAYELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/e1CvCM6Z7pAYEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/4yWnCKeH9ZAYEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'PPDC-EnrollmentStart'
          }
        }]
      };
      var ccfullsu_end = {
        'name': 'ccfullsu_end',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'ac',
            'page': 'main:debitcards:setPin:setPinIntro',
            'card_type': 'CONSUMER_DEBIT_CARD',
            'event_name': 'ucs_set_pin_enrollment_success_message_shown'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu000/paypa00+standard'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'PPDC-EnrollmentFinish'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/iYWoCK_3u9wBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/idEHCLKPt5kYELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/fvHFCNj8tpkYEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/myF9CMrHr5kYEJy7qMwD'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'cash card full',
            'event_action': 'sign up finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.cust',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ADON_PPCASHCARD_SIGNUP_FIN',
            'event_category': 'cash card full',
            'event_action': 'sign up finish',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.cust',
              'defaultVal': ''
            }
          }
        }]
      };
      var ccfullact_start = {
        'name': 'ccfullact_start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'main:debitcards:activateCard:enterCvv',
            'card_type': 'CONSUMER_DEBIT_CARD',
            'event_name': 'ucs_activate_cvv_screen_shown'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu000/paypa000+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/1qedCOHy75AYEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/86KVCLLV75AYELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/MLJZCMLa-5AYEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/WNzsCOXs9ZAYEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'PPDC-ActivationStart'
          }
        }]
      };
      var ccfullact_end = {
        'name': 'ccfullact_end',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'ac',
            'page': 'main:debitcards:activateCard:activateSuccess|main:debitcards:setPin:setPin',
            'card_type': 'CONSUMER_DEBIT_CARD',
            'event_name': 'ucs_activate_success_occurred'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu000/paypa001+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/AsZDCNvw-5AYEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/03UjCPrY75AYELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/qmJlCLK39pAYEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/KGjoCIH09ZAYEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'PPDC-ActivationFinish'
          }
        }]
      };
      var acc_su_consent_edison = {
        'name': 'acc_su_consent_edison',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:unifiedlogin:::login',
            'tsrce': 'conspartneronbnodeweb'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/pp_gb000+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'partner onboarding sign-up',
            'event_action': 'edison authorization page',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/k7V-CI7e29wBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/M3DACL7e29wBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/5pIKCKDe29wBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/Xo6GCPnK7twBEJy7qMwD'
          }
        }]
      };
      var biz_acc_su_start_new = {
        'name': 'biz_acc_su_start_new',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:unifiedonboardnodeweb',
            'page': 'main:unifiedonboardnodeweb:entry',
            'event_name': 'minimal_account_screen_shown'
          },
          'session': {
            'key': 'mercsu',
            'type': 'start'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch0/bizac0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: MerchantSUStart',
            'event_action': 'sign up start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 5: enter business info and account created',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Create Business Account',
            'dimension8': 'active',
            'dimension9': 'step 5: enter business info and account created',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            },
            'dimension46': 'true'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/po-UCKKa--ABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/-CfpCL-v4OABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/VjrHCNvj6-ABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/Au6mCJma--ABEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantaccountsignupstart'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_MSU_SIGNUP_START',
            'event_category': 'MerchantSUStart',
            'event_action': 'MerchantSUStart',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var biz_acc_su_minimal_unified = {
        'name': 'biz_acc_su_minimal_unified',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'event_name': 'welcome_screen_shown'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch0/pp_gb0+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/SW16CLSf2a4DEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/M4QKCJa02a4DELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/Ln4hCM3M3a4DEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/Bc0zCNCtpa4DEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'FB_MERCHANTMINIMALACCOUNT'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'Merchant Sign UP',
            'event_action': 'Minimal account setup',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantminimalaccount'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_MER_MINACC_SETUP',
            'event_category': 'Merchant Sign UP',
            'event_action': 'MerchantSUMINACC',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var biz_acc_su_start_new_1 = {
        'name': 'biz_acc_su_start_new_1',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'event_name': 'merchant_onboarding_entry_shown'
          },
          'session': {
            'key': 'mercsu',
            'type': 'start'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch0/bizac0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: MerchantSUStart',
            'event_action': 'sign up start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'merchant sign-up',
            'event_action': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            },
            'event_label': 'step 5: enter business info and account created',
            'page_path': {
              'type': 'var',
              'path': 'location.pathname',
              'defaultVal': ''
            },
            'page_title': 'Create Business Account',
            'dimension8': 'active',
            'dimension9': 'step 5: enter business info and account created',
            'dimension10': {
              'type': 'var',
              'path': 'dataLayer.application',
              'defaultVal': ''
            },
            'dimension46': 'true'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/po-UCKKa--ABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/-CfpCL-v4OABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/VjrHCNvj6-ABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/Au6mCJma--ABEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantaccountsignupstart'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_MSU_SIGNUP_START',
            'event_category': 'MerchantSUStart',
            'event_action': 'MerchantSUStart',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var biz_acc_su_minimal_unified_1 = {
        'name': 'biz_acc_su_minimal_unified_1',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pglk': '\\|createAccountButton',
            'event_name': 'merchant_onboarding_welcome_shown'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch0/pp_gb0+standard'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/SW16CLSf2a4DEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/M4QKCJa02a4DELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/Ln4hCM3M3a4DEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/Bc0zCNCtpa4DEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'FB_MERCHANTMINIMALACCOUNT'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'Merchant Sign UP',
            'event_action': 'Minimal account setup',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/merchantminimalaccount'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ONBOARD_MER_MINACC_SETUP',
            'event_category': 'Merchant Sign UP',
            'event_action': 'MerchantSUMINACC',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var zettle_signup_start_uk = {
        'name': 'zettle_signup_start_uk',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['gb|uk', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'event_name': 'merchant_onboarding_entry_shown',
            'product_ext': 'IZETTLE',
            'product': 'mep',
            'onboarding_complete': 'false'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/pp_em00+standard'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_UKZettleSignUpStart'
          }
        }]
      };
      var zettle_signup_finish_uk = {
        'name': 'zettle_signup_finish_uk',
        'enable': {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['gb|uk', 'fetchCountry']
        },
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'event_name': 'merchant_onboarding_done_shown',
            'product_ext': 'IZETTLE',
            'product': 'mep',
            'onboarding_complete': 'true'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch002/pp_em000+standard'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_UKZettleSignUpFinish'
          }
        }]
      };
      var cons_add_bank_end_v1 = {
        'name': 'cons_add_bank_end_v1',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:walletweb:wallet:add:bank',
            'goal': 'addbank:success|addBankSuccess',
            'acnt': 'personal|premier'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/consu0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'account activity',
            'event_action': {
              'type': 'var',
              'obj': 'data',
              'path': 'acnt'
            },
            'event_label': 'link bank account'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_FUNDINGINST_CONS_ADDBANK_FIN',
            'event_category': 'account activity',
            'event_action': {
              'type': 'var',
              'obj': 'data',
              'path': 'acnt'
            },
            'event_label': 'link bank account'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/7FWPCK68stwBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/Ri5WCNndzdwBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/albtCN2NvNwBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/8nBhCM6NvNwBEJy7qMwD'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'fb_consumerwalletaddbankfinish'
          }
        }]
      };
      var mer_add_bank_end_v1 = {
        'name': 'mer_add_bank_end_v1',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pgrp': 'main:walletweb:wallet:add:bank',
            'goal': 'addbank:success',
            'acnt': 'business'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/walle0/merch00+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'account activity',
            'event_action': {
              'type': 'var',
              'obj': 'data',
              'path': 'acnt'
            },
            'event_label': 'link bank account'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/eDyxCPOCvNwBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/aujJCILUzdwBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/cal3CI6DvNwBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/b1AjCOvXzdwBEJy7qMwD'
          }
        }]
      };
      var start = {
        'name': 'start',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'qual': 'businessInfoView'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch001/ppwca0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PPWCAppStart',
            'event_action': 'application start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Sa8pCJKb_eABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/xReICKnm7eABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/zaWkCIqs4uABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/2ml-CLKq4uABEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/ppworkingstart'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ADDON_PPWC_APPLICATION_STRT',
            'event_category': 'PPWCAppStart',
            'event_action': 'PPWCAppStart',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var approved = {
        'name': 'approved',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'qual': 'offerInfoView'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch001/ppwca002+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PPWCAppApproved',
            'event_action': 'approved',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Nd52CJrUzdwBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/4MXVCPeustwBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/Cq-2CJOnstwBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/WK3aCObVzdwBEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/ppworkingapproved'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_ADDON_PPWC_APL_FINISHAPPROVED',
            'event_category': 'PPWCApproved',
            'event_action': 'PPWCApproved',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var declined = {
        'name': 'declined',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'qual': 'decision.*'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch001/ppwca001+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PPWCAppDeclined',
            'event_action': 'declined',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/lx7dCPek4uABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/5-VWCMqk4uABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/VnKsCKGl4uABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/teJ6CIml4uABEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/ppworkingdeclined'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_ADDON_PPWC_APL_FINISHDECLINED',
            'event_category': 'PPWCDeclined',
            'event_action': 'PPWCDeclined',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var ineligible = {
        'name': 'ineligible',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'qual': 'eligibility.*'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch001/ppwca000+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PPWCAppIneligible',
            'event_action': 'ineligible',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/wfNOCPam4uABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/BHqDCOri7eABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/HFq9COia_eABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/Z32iCIun4uABEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/ppworkingelligible'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_ADDON_PPWC_APL_FINISHINELIGIBLE',
            'event_category': 'PPWCAppIneligible',
            'event_action': 'PPWCAppIneligible',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var funded = {
        'name': 'funded',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'pglk': 'workingcapitalnodeweb.*complete.*'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch001/ppwca00+standard'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'ProductSignup-PPWCLoanFunded-PayPalWorkingCapital'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PPWCAppFinLoanFunded',
            'event_action': 'funded',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/EuuRCLXO7eABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/IC7LCK3M7eABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/4_vyCKnO7eABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/oD4TCOOG_eABEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/ppworkingfunded'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_ADDON_PPWC_APPLICATION_FUNDED',
            'event_category': 'PPWCFunded',
            'event_action': 'PPWCFunded',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var start_new = {
        'name': 'start_new',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'workingcapitalnodeweb/public/templates/loanApplication/index.dust'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch001/ppwca0+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PPWCAppStart',
            'event_action': 'application start',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Sa8pCJKb_eABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/xReICKnm7eABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/zaWkCIqs4uABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/2ml-CLKq4uABEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/ppworkingstart'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_GA4_ADDON_PPWC_APPLICATION_STRT',
            'event_category': 'PPWCAppStart',
            'event_action': 'PPWCAppStart',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var ineligible_new = {
        'name': 'ineligible_new',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'workingcapitalnodeweb/public/templates/loanApplication/messages/info.dust'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch001/ppwca000+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PPWCAppIneligible',
            'event_action': 'ineligible',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/wfNOCPam4uABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/BHqDCOri7eABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/HFq9COia_eABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/Z32iCIun4uABEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/ppworkingelligible'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_ADDON_PPWC_APL_FINISHINELIGIBLE',
            'event_category': 'PPWCAppIneligible',
            'event_action': 'PPWCAppIneligible',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var funded_new = {
        'name': 'funded_new',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'welcomeModal'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch001/ppwca00+standard'
          }
        }, {
          'name': 'fb',
          'vars': {
            'ev': 'ProductSignup-PPWCLoanFunded-PayPalWorkingCapital'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PPWCAppFinLoanFunded',
            'event_action': 'funded',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/EuuRCLXO7eABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/IC7LCK3M7eABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/4_vyCKnO7eABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/oD4TCOOG_eABEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/ppworkingfunded'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_ADDON_PPWC_APPLICATION_FUNDED',
            'event_category': 'PPWCFunded',
            'event_action': 'PPWCFunded',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var approved_new = {
        'name': 'approved_new',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'workingcapitalnodeweb/public/templates/loanApplication/index.dust:offerInfoView'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch001/ppwca002+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PPWCAppApproved',
            'event_action': 'approved',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Nd52CJrUzdwBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/4MXVCPeustwBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/Cq-2CJOnstwBEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/WK3aCObVzdwBEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/ppworkingapproved'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_ADDON_PPWC_APL_FINISHAPPROVED',
            'event_category': 'PPWCApproved',
            'event_action': 'PPWCApproved',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var declined_new = {
        'name': 'declined_new',
        'trigger': {
          'type': 'pa.beacon',
          'condition': {
            'e': 'im',
            'page': 'workingcapitalnodeweb/public/templates/loanApplication/messages/warning.dust'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/merch001/ppwca001+standard'
          }
        }, {
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'hitType': 'event',
            'event_category': 'DCM: PPWCAppDeclined',
            'event_action': 'declined',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/lx7dCPek4uABEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/5-VWCMqk4uABELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/VnKsCKGl4uABEKv66t8D'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/teJ6CIml4uABEJy7qMwD'
          }
        }, {
          'name': 'li',
          'vars': {
            'url': 'paypal.com/ppworkingdeclined'
          }
        }, {
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'hitType': 'event',
            'event_name': 'PP_GBL_ADDON_PPWC_APL_FINISHDECLINED',
            'event_category': 'PPWCDeclined',
            'event_action': 'PPWCDeclined',
            'event_label': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var prox_su_end = {
        'name': 'prox_su_end',
        'trigger': {
          'type': 'fn',
          'name': 'handleClick',
          'sel': 'button[type=submit], input[type=submit]',
          'session': {
            'key': 'prox',
            'type': 'end'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu0/proxs00+standard',
            'u2': {
              'type': 'var',
              'path': 'pre.payee.res.data.merchant.id',
              'defaultVal': 'NA'
            },
            'u3': {
              'type': 'int',
              'path': 'pre.cart.res.data.purchase.amounts.total.amount'
            },
            'u4': {
              'type': 'var',
              'path': 'pre.cart.res.data.purchase.amounts.total.currency_code',
              'defaultVal': 'NA'
            },
            'u10': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['us|ca', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-992191228/Hv52CLWGs8cBEPzFjtkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ag|ai|an|ar|aw|bb|bm|bo|br|bs|bz|cl|co|cr|dm|do|ec|fk|gd|gt|gy|hn|jm|kn|ky|lc|ms|mx|ni|pa|pe|py|sr|sv|tc|tt|uy|vc|ve|vg', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-993701045/jBTSCN2l9NcBELXZ6tkD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['au|c2|cn|hk|id|in|jp|kr|my|nz|ph|sg|th|tw|vn', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-965352860/g-dgCM_sztgBEJy7qMwD'
          }
        }, {
          'name': 'gads',
          'enable': {
            'type': 'fn',
            'name': 'conditionalValue',
            'args': ['ad|ae|af|al|am|ao|aq|at|ax|az|ba|be|bf|bg|bh|bi|bj|bv|bw|by|cd|cf|cg|ch|ci|ck|cm|cs|cv|cy|cz|de|dj|dk|dz|ee|eg|eh|er|es|et|fi|fo|fr|fx|ga|gb|ge|gf|gg|gh|gi|gl|gm|gn|gp|gq|gr|gw|hm|hr|hu|ie|il|im|iq|ir|is|it|je|jo|ke|kg|km|kw|kz|lb|li|lr|ls|lt|lu|lv|ly|ma|mc|md|me|mg|mk|ml|mq|mr|mt|mu|mw|mz|na|nc|ne|ng|nl|no|om|pf|pl|pm|ps|pt|qa|re|ro|rs|ru|rw|sa|sc|sd|se|sh|si|sj|sk|sl|sm|sn|so|st|sy|sz|td|tf|tg|tj|tm|tn|tr|tz|ua|ug|uz|va|wf|ye|yt|yu|za|zm|zw', 'fetchCountry']
          },
          'vars': {
            'send_to': 'AW-1006288171/T0apCKytv9gBEKv66t8D'
          }
        }]
      };
      var prox_txn_end = {
        'name': 'prox_txn_end',
        'trigger': {
          'type': 'fn',
          'name': 'handleClick',
          'sel': 'button[type=submit], input[type=submit]',
          'session': {
            'key': 'prox',
            'type': 'end'
          }
        },
        'vendors': [{
          'name': 'dc',
          'vars': {
            'send_to': 'DC-6386697/consu00/proxt00+standard',
            'u2': {
              'type': 'var',
              'path': 'pre.payee.res.data.merchant.id',
              'defaultVal': 'NA'
            },
            'u3': {
              'type': 'int',
              'path': 'pre.cart.res.data.purchase.amounts.total.amount'
            },
            'u4': {
              'type': 'var',
              'path': 'pre.cart.res.data.purchase.amounts.total.currency_code',
              'defaultVal': 'NA'
            },
            'u10': {
              'type': 'var',
              'path': 'laDataLayer.ccpg',
              'defaultVal': ''
            }
          }
        }]
      };
      var fb_pgv = {
        'name': 'fb_pgv',
        'trigger': {
          'type': 'generic',
          'once': false
        },
        'vendors': [{
          'name': 'fb',
          'vars': {
            'ev': 'ViewContent'
          }
        }]
      };
      var ga4_pgv = {
        'name': 'ga4_pgv',
        'trigger': {
          'type': 'generic',
          'once': false
        },
        'vendors': [{
          'name': 'ga4',
          'vars': {
            'send_to': 'G-FQYH6BLY4K',
            'event_name': 'page_view',
            'event_action': 'page_view',
            'page_title': {
              'type': 'var',
              'path': 'document.title'
            },
            'page_location': {
              'type': 'fn',
              'name': 'fetchSanatizedURL'
            }
          }
        }]
      };
      var ga_pgv = {
        'name': 'ga_pgv',
        'trigger': {
          'type': 'generic',
          'once': false
        },
        'vendors': [{
          'name': 'ga',
          'vars': {
            'send_to': 'UA-53389718-12',
            'event_action': 'page_view',
            'page_title': {
              'type': 'var',
              'path': 'document.title'
            },
            'page_location': {
              'type': 'fn',
              'name': 'fetchSanatizedURL'
            }
          }
        }]
      };
      var li_pgv = {
        'name': 'li_pgv',
        'trigger': {
          'type': 'generic',
          'once': false
        },
        'vendors': [{
          'name': 'li'
        }]
      };
      var adobe = {
        'name': 'adobe',
        'enable': [{
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['paypal', 'fetchTenantname']
        }, {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['false', 'isC2']
        }, {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['false', 'isC2ToC3']
        }, {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['us', 'fetchCountry']
        }],
        'enableCookieConsent': false,
        'vars': {
          't': {
            'type': 'var',
            'obj': 'data',
            'path': 't'
          },
          'rsta': {
            'type': 'var',
            'path': 'laDataLayer.rsta'
          },
          'ccpg': {
            'type': 'var',
            'path': 'laDataLayer.ccpg',
            'defaultVal': ''
          },
          'lgin': {
            'type': 'var',
            'obj': 'data',
            'path': 'lgin'
          },
          'page_segment': {
            'type': 'var',
            'obj': 'data',
            'path': 'page_segment'
          },
          'event_name': {
            'type': 'var',
            'obj': 'data',
            'path': 'event_name'
          },
          'e': {
            'type': 'var',
            'obj': 'data',
            'path': 'e'
          },
          'ef_policy': {
            'type': 'var',
            'obj': 'data',
            'path': 'ef_policy'
          },
          'c_prefs': {
            'type': 'var',
            'obj': 'data',
            'path': 'c_prefs'
          },
          'pgrp': {
            'type': 'var',
            'path': 'laDataLayer.pgrp'
          },
          'page': {
            'type': 'var',
            'path': 'laDataLayer.page'
          },
          'gacook': {
            'type': 'var',
            'path': 'laDataLayer.gacook'
          },
          'xe': {
            'type': 'var',
            'path': 'laDataLayer.xe'
          },
          'xt': {
            'type': 'var',
            'path': 'laDataLayer.xt'
          },
          'cust': {
            'type': 'var',
            'obj': 'data',
            'path': 'cust'
          },
          'utm_campaign': {
            'type': 'var',
            'path': 'laDataLayer.utm_campaign'
          },
          'utm_content': {
            'type': 'var',
            'path': 'laDataLayer.utm_content'
          },
          'utm_medium': {
            'type': 'var',
            'path': 'laDataLayer.utm_medium'
          },
          'utm_source': {
            'type': 'var',
            'path': 'laDataLayer.utm_source'
          },
          'utm_term': {
            'type': 'var',
            'path': 'laDataLayer.utm_term'
          },
          'gclid': {
            'type': 'var',
            'path': 'laDataLayer.gclid'
          },
          'ru': {
            'type': 'var',
            'obj': 'data',
            'path': 'ru'
          },
          'comp': {
            'type': 'var',
            'path': 'laDataLayer.comp'
          },
          'pgsf': {
            'type': 'var',
            'obj': 'data',
            'path': 'pgsf'
          },
          'shir': {
            'type': 'var',
            'obj': 'data',
            'path': 'shir'
          },
          'pros': {
            'type': 'var',
            'obj': 'data',
            'path': 'pros'
          },
          'pglk': {
            'type': 'var',
            'obj': 'data',
            'path': 'pglk'
          },
          'pt': {
            'type': 'var',
            'obj': 'data',
            'path': 'pt'
          },
          'product_int': {
            'type': 'var',
            'obj': 'data',
            'path': 'product_int'
          },
          'product_ext': {
            'type': 'var',
            'obj': 'data',
            'path': 'product_ext'
          },
          'visitor_id': {
            'type': 'var',
            'path': 'laDataLayer.visitorId'
          },
          'event_source': {
            'type': 'var',
            'obj': 'data',
            'path': 'event_source'
          },
          'integration_type': {
            'type': 'var',
            'obj': 'data',
            'path': 'integration_type'
          },
          'flow': {
            'type': 'var',
            'obj': 'data',
            'path': 'flow'
          },
          'flow_name': {
            'type': 'var',
            'obj': 'data',
            'path': 'flow_name'
          },
          'field_name': {
            'type': 'var',
            'obj': 'data',
            'path': 'field_name'
          },
          'link': {
            'type': 'var',
            'obj': 'data',
            'path': 'link'
          },
          'pgln': {
            'type': 'var',
            'obj': 'data',
            'path': 'pgln'
          },
          'product': {
            'type': 'var',
            'obj': 'data',
            'path': 'product'
          },
          'subchannel': {
            'type': 'var',
            'obj': 'data',
            'path': 'subchannel'
          },
          'account_type': {
            'type': 'var',
            'obj': 'data',
            'path': 'account_type'
          },
          'acnt': {
            'type': 'var',
            'obj': 'data',
            'path': 'acnt'
          },
          'dclid': {
            'type': 'var',
            'obj': 'data',
            'path': 'dclid'
          },
          'Kwid': {
            'type': 'var',
            'obj': 'data',
            'path': 'Kwid'
          },
          'kw': {
            'type': 'var',
            'obj': 'data',
            'path': 'kw'
          },
          'fbclid': {
            'type': 'var',
            'obj': 'data',
            'path': 'fbclid'
          },
          'dwnl': {
            'type': 'var',
            'obj': 'data',
            'path': 'dwnl'
          },
          'lu': {
            'type': 'var',
            'obj': 'data',
            'path': 'lu'
          }
        },
        'setup': {
          'scriptSrc': 'https://www.paypalobjects.com/martech/tm/paypal/3pjs/adobe/alloy.min.js',
          'preLoadScript': function preLoadScript(vendor, cb) {
            var includedPages = /^main:mktg:personal:|main:mktg:both:product:account-selection:::/;
            var comp = window.laDataLayer && window.laDataLayer.comp || '';
            if (comp === 'ppcmsnodeweb' && !includedPages.test(window.laDataLayer.page)) {
              vendor.setup.scriptSrc = '';
              return cb(vendor);
            }
            function adobeAlloy() {
              if (!window.alloy) {
                window.__alloyNS = window.__alloyNS || [];
                window.__alloyNS.push('alloy');
                window.alloy = function () {
                  var args = arguments;
                  return new Promise(function (resolve, reject) {
                    window.alloy.q.push([resolve, reject, args]);
                  });
                };
                window.alloy.q = [];
                window.alloy('configure', {
                  datastreamId: '8a1e7181-ae23-40e2-985e-7eb68997dd65',
                  orgId: '5CE4123F5245B06C0A490D45@AdobeOrg',
                  edgeDomain: 'i.paypal.com',
                  context: ['web', 'device', 'environment', 'placeContext', 'highEntropyUserAgentHints'],
                  debugEnabled: false,
                  idMigrationEnabled: false,
                  thirdPartyCookiesEnabled: false,
                  clickCollectionEnabled: false
                });
              }
            }
            adobeAlloy();
            cb();
          }
        },
        'triggerEvent': function triggerEvent(vendor) {
          function adobeTagTriggerEvent(vendor) {
            var _alloy = window.alloy;
            var adobeXdm = {};
            if (vendor.vars.cust === '') {
              adobeXdm = {
                identityMap: {
                  FPID: [{
                    id: window.laDataLayer.visitorId || '',
                    authenticatedState: 'ambiguous',
                    primary: true
                  }]
                }
              };
            } else {
              adobeXdm = {
                identityMap: {
                  FPID: [{
                    id: window.laDataLayer.visitorId || '',
                    authenticatedState: 'authenticated',
                    primary: false
                  }],
                  custIdEcrpt: [{
                    id: vendor.vars.cust,
                    authenticatedState: 'authenticated',
                    primary: true
                  }]
                }
              };
            }
            function snakeToCamel(s) {
              return s.replace(/(_\w)/g, function (m) {
                return m === '_id' ? 'ID' : m[1].toUpperCase();
              });
            }
            function convertKeysToCamelCase(obj) {
              if (Array.isArray(obj)) {
                return obj.map(convertKeysToCamelCase);
              }
              if (obj !== null && _typeof(obj) === 'object') {
                return Object.fromEntries(Object.entries(obj).map(function (_ref) {
                  var _ref2 = _slicedToArray(_ref, 2),
                    k = _ref2[0],
                    v = _ref2[1];
                  return [snakeToCamel(k), convertKeysToCamelCase(v)];
                }));
              }
              return obj;
            }
            if (window.ppAepDataLayer && window.ppAepDataLayer.target) {
              var renderedPropositions = window.ppAepDataLayer.target;
              adobeXdm._experience = {
                decisioning: {
                  propositionEventType: {
                    display: 1
                  },
                  propositions: convertKeysToCamelCase(renderedPropositions)
                }
              };
            }
            if (_alloy && vendor.vars) _alloy('sendEvent', {
              xdm: adobeXdm,
              renderDecisions: true,
              data: vendor.vars
            });
          }
          return adobeTagTriggerEvent(vendor);
        },
        'component': ['brcappnodeweb', 'ppcmsnodeweb', 'progressivenodeweb', 'mppnodeweb', 'marketingnodeweb', 'summarynodeweb']
      };
      var dc = {
        'name': 'dc',
        'endpoint': {
          'scheme': 'https',
          'host': 'ad.doubleclick.net',
          'path': '/activity/'
        },
        'enable': [{
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['paypal', 'fetchTenantname']
        }, {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['false', 'isC2ToC3']
        }],
        'seperator': ';',
        'enableCookieConsent': true,
        'consentCategory': 'T',
        'action': 'conversion',
        'vars': {
          'allow_custom_scripts': true,
          'value': {
            'type': 'int',
            'path': 'laDataLayer.amt'
          },
          'transaction_id': {
            'type': 'var',
            'path': 'laDataLayer.trid'
          },
          'npa': {
            'type': 'fn',
            'name': 'mrktConsentOptOut'
          },
          'u1': {
            'type': 'var',
            'path': 'laDataLayer.cust',
            'defaultVal': ''
          },
          'u2': {
            'type': 'var',
            'path': 'laDataLayer.mrid',
            'defaultVal': 'NA'
          },
          'u3': {
            'type': 'int',
            'path': 'laDataLayer.amt'
          },
          'u4': {
            'type': 'var',
            'path': 'laDataLayer.curr',
            'defaultVal': 'NA'
          },
          'u5': {
            'type': 'var',
            'path': 'laDataLayer.trid'
          },
          'u6': {
            'type': 'var',
            'path': 'laDataLayer.page'
          },
          'u7': {
            'type': 'fn',
            'name': 'fetchSanatizedURL'
          },
          'u8': {
            'type': 'var',
            'path': 'laDataLayer.flnm'
          },
          'u9': '',
          'u10': {
            'type': 'var',
            'path': 'laDataLayer.ccpg',
            'defaultVal': ''
          }
        },
        'setup': {
          'scriptSrc': 'https://www.paypalobjects.com/martech/tm/paypal/3pjs/gtag/gtag.js',
          'preLoadScript': function preLoadScript(vendor, cb) {
            function gtagCommonSetup(vendor) {
              window.gDataLayer = window.gDataLayer || [];
              function gtag() {
                window.gDataLayer.push(arguments);
              }
              gtag('js', new Date());
              gtag('set', {
                anonymize_ip: true
              });
              gtag('consent', 'default', {
                ad_user_data: 'granted',
                ad_personalization: 'granted',
                ad_storage: 'granted',
                analytics_storage: 'granted'
              });
              if (vendor.mktConsentOptOut) {
                gtag('set', {
                  allow_ad_personalization_signals: false
                });
                gtag('consent', 'update', {
                  ad_user_data: 'denied',
                  ad_personalization: 'denied',
                  ad_storage: 'denied',
                  analytics_storage: 'denied'
                });
              }
              window.gtag = window.gtag || gtag;
            }
            var mktconf = window.mktconf;
            mktconf.gtagModules = mktconf.gtagModules || [];
            if (mktconf.gtagModules.length === 0) gtagCommonSetup(vendor);
            if (!mktconf.gtagModules.includes(vendor.name)) mktconf.gtagModules.push(vendor.name);
            var comp = window.laDataLayer && window.laDataLayer.comp;
            if (comp === 'honeyapp') {
              window.gtag('config', 'DC-10648833');
            } else {
              window.gtag('config', 'DC-6386697');
            }
            cb();
          }
        },
        'triggerEvent': function triggerEvent(vendor) {
          function gtagTriggerEvent(vendor) {
            var _gtag = window.gtag;
            var actionSrc = vendor.vars.event_action || 'conversion';
            if (_gtag) _gtag('event', actionSrc, vendor.vars);
          }
          return gtagTriggerEvent(vendor);
        },
        'component': 'all'
      };
      var fb = {
        'name': 'fb',
        'consentCategory': 'T',
        'enableCookieConsent': true,
        'endpoint': {
          'scheme': 'https',
          'host': 'www.facebook.com',
          'path': '/tr?'
        },
        'enable': [{
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['paypal', 'fetchTenantname']
        }, {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['false', 'isC2']
        }, {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['false', 'isC2ToC3']
        }],
        'vars': {
          'id': '1674696026155243',
          'noscript': '1',
          'cd[CustomerID]': {
            'type': 'var',
            'path': 'laDataLayer.cust',
            'defaultVal': '',
            'enable': {
              'type': 'fn',
              'name': 'conditionalValue',
              'args': ['us', 'fetchCountry']
            }
          },
          'cd[MerchantID]': {
            'type': 'var',
            'path': 'laDataLayer.mrid',
            'defaultVal': 'NA'
          },
          'cd[MerchantTPV]': {
            'type': 'int',
            'path': 'laDataLayer.amt'
          },
          'cd[MerchantTransaction]': {
            'type': 'var',
            'path': 'laDataLayer.curr',
            'defaultVal': 'NA'
          },
          'cd[P2PTransaction]': {
            'type': 'var',
            'path': 'laDataLayer.curr',
            'defaultVal': 'NA'
          },
          'cd[P2PTPV]': {
            'type': 'int',
            'path': 'laDataLayer.txn_amt',
            'defaultVal': ''
          }
        }
      };
      var ga = {
        'name': 'ga',
        'endpoint': {
          'scheme': 'https',
          'host': 'www.google-analytics.com',
          'path': '/r/collect?'
        },
        'enable': [{
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['paypal', 'fetchTenantname']
        }, {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['false', 'isC2ToC3']
        }],
        'enableCookieConsent': true,
        'consentCategory': 'T',
        'vars': {
          'dimension1': {
            'type': 'var',
            'path': 'laDataLayer.gacook'
          },
          'dimension2': {
            'type': 'var',
            'path': 'laDataLayer.cust',
            'defaultVal': ''
          },
          'dimension3': {
            'type': 'var',
            'path': 'laDataLayer.isLoggedIn'
          },
          'dimension4': {
            'type': 'fn',
            'name': 'fetchSanatizedURL'
          },
          'dimension5': {
            'type': 'var',
            'path': 'laDataLayer.ccpg',
            'defaultVal': ''
          },
          'dimension6': {
            'type': 'var',
            'path': 'laDataLayer.rsta'
          },
          'dimension7': {
            'type': 'var',
            'path': 'laDataLayer.acnt'
          },
          'dimension8': '',
          'dimension9': '',
          'dimension10': {
            'type': 'var',
            'path': 'laDataLayer.comp'
          },
          'dimension19': {
            'type': 'var',
            'path': 'laDataLayer.xe'
          },
          'dimension20': {
            'type': 'var',
            'path': 'laDataLayer.xt'
          },
          'dimension22': {
            'type': 'var',
            'path': 'laDataLayer.pgrp'
          },
          'dimension25': '',
          'dimension26': {
            'type': 'fn',
            'name': 'mrktConsentOptOut'
          },
          'contentGroup1': {
            'type': 'var',
            'path': 'dataLayer.pageType'
          },
          'contentGroup3': {
            'type': 'var',
            'path': 'laDataLayer.isLoggedIn'
          },
          'location': {
            'type': 'fn',
            'name': 'fetchSanatizedURL'
          }
        },
        'setup': {
          'scriptSrc': 'https://www.paypalobjects.com/martech/tm/paypal/3pjs/gtag/gtag.js',
          'preLoadScript': function preLoadScript(vendor, cb) {
            function gtagCommonSetup(vendor) {
              window.gDataLayer = window.gDataLayer || [];
              function gtag() {
                window.gDataLayer.push(arguments);
              }
              gtag('js', new Date());
              gtag('set', {
                anonymize_ip: true
              });
              gtag('consent', 'default', {
                ad_user_data: 'granted',
                ad_personalization: 'granted',
                ad_storage: 'granted',
                analytics_storage: 'granted'
              });
              if (vendor.mktConsentOptOut) {
                gtag('set', {
                  allow_ad_personalization_signals: false
                });
                gtag('consent', 'update', {
                  ad_user_data: 'denied',
                  ad_personalization: 'denied',
                  ad_storage: 'denied',
                  analytics_storage: 'denied'
                });
              }
              window.gtag = window.gtag || gtag;
            }
            var mktconf = window.mktconf;
            mktconf.gtagModules = mktconf.gtagModules || [];
            if (mktconf.gtagModules.length === 0) gtagCommonSetup(vendor);
            if (!mktconf.gtagModules.includes(vendor.name)) mktconf.gtagModules.push(vendor.name);
            window.gtag('config', 'UA-53389718-12', {
              send_page_view: false,
              linker: {
                domains: ['paypal.com', 'paypal.me', 'www.xoom.com']
              },
              cookie_flags: 'secure;samesite=none'
            });
            cb();
          }
        },
        'triggerEvent': function triggerEvent(vendor) {
          function gtagTriggerEvent(vendor) {
            var _gtag = window.gtag;
            var actionSrc = vendor.vars.event_action || 'conversion';
            if (_gtag) _gtag('event', actionSrc, vendor.vars);
          }
          return gtagTriggerEvent(vendor);
        },
        'component': 'all'
      };
      var ga4 = {
        'name': 'ga4',
        'endpoint': {
          'scheme': 'https',
          'host': 'www.google-analytics.com',
          'path': '/g/collect?'
        },
        'enable': [{
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['paypal', 'fetchTenantname']
        }, {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['false', 'isC2ToC3']
        }],
        'enableCookieConsent': true,
        'consentCategory': 'T',
        'vars': {
          'dimension1': {
            'type': 'var',
            'path': 'laDataLayer.gacook'
          },
          'dimension2': {
            'type': 'var',
            'path': 'laDataLayer.cust',
            'defaultVal': ''
          },
          'dimension3': {
            'type': 'var',
            'path': 'laDataLayer.isLoggedIn'
          },
          'dimension4': {
            'type': 'fn',
            'name': 'fetchSanatizedURL'
          },
          'dimension5': {
            'type': 'var',
            'path': 'laDataLayer.ccpg',
            'defaultVal': ''
          },
          'dimension6': {
            'type': 'var',
            'path': 'laDataLayer.rsta'
          },
          'dimension7': {
            'type': 'var',
            'path': 'laDataLayer.acnt'
          },
          'dimension8': '',
          'dimension9': '',
          'dimension10': {
            'type': 'var',
            'path': 'laDataLayer.comp'
          },
          'dimension19': {
            'type': 'var',
            'path': 'laDataLayer.xe'
          },
          'dimension20': {
            'type': 'var',
            'path': 'laDataLayer.xt'
          },
          'dimension22': {
            'type': 'var',
            'path': 'laDataLayer.pgrp'
          },
          'dimension25': '',
          'dimension26': {
            'type': 'fn',
            'name': 'mrktConsentOptOut'
          },
          'contentGroup1': {
            'type': 'var',
            'path': 'dataLayer.pageType'
          },
          'contentGroup3': {
            'type': 'var',
            'path': 'laDataLayer.isLoggedIn'
          },
          'location': {
            'type': 'fn',
            'name': 'fetchSanatizedURL'
          }
        },
        'setup': {
          'scriptSrc': 'https://www.paypalobjects.com/martech/tm/paypal/3pjs/gtag/ga4.js',
          'preLoadScript': function preLoadScript(vendor, cb) {
            function ga4CommonSetup(vendor) {
              window.ga4DataLayer = window.ga4DataLayer || [];
              function ga4tag() {
                window.ga4DataLayer.push(arguments);
              }
              ga4tag('js', new Date());
              ga4tag('config', 'G-FQYH6BLY4K');
              ga4tag('consent', 'default', {
                ad_user_data: 'granted',
                ad_personalization: 'granted',
                ad_storage: 'granted',
                analytics_storage: 'granted'
              });
              if (vendor.enforcePolicy && vendor.mktConsentOptOut) {
                window.ga4tag('config', 'G-FQYH6BLY4K', {
                  allow_ad_personalization_signals: false
                });
                ga4tag('consent', 'update', {
                  ad_user_data: 'denied',
                  ad_personalization: 'denied',
                  ad_storage: 'denied',
                  analytics_storage: 'denied'
                });
              }
              window.ga4tag = window.ga4tag || ga4tag;
            }
            ga4CommonSetup(vendor);
            window.ga4tag('config', 'G-FQYH6BLY4K', {
              send_page_view: false,
              cookie_flags: 'SameSite=None;Secure'
            });
            cb();
          }
        },
        'triggerEvent': function triggerEvent(vendor) {
          function ga4tagTriggerEvent(vendor) {
            var _ga4tag = window.ga4tag;
            var eventName = vendor.vars.event_name;
            var userProps = {
              dimension1: vendor.vars.dimension1,
              dimension2: vendor.vars.dimension2,
              dimension7: vendor.vars.dimension7,
              dimension8: vendor.vars.dimension8,
              dimension26: vendor.vars.dimension26
            };
            Object.keys(userProps).forEach(function (key) {
              delete vendor.vars[key];
            });
            if (_ga4tag) {
              _ga4tag('set', 'user_properties', userProps);
              _ga4tag('event', eventName, vendor.vars);
            }
          }
          return ga4tagTriggerEvent(vendor);
        },
        'component': ['brcappnodeweb', 'btpwebsite', 'capeuinodeweb', 'checkoutuinodeweb', 'cponboardingnodeweb', 'creditapplyweb', 'hermesnodeweb', 'invoicingnodeweb', 'marketingnodeweb', 'moneynodeweb', 'mppnodeweb', 'p2pnodeweb', 'ppcmsnodeweb', 'progressivenodeweb', 'summarynodeweb', 'ucsnodeweb', 'xoonboardingnodeweb']
      };
      var gads = {
        'name': 'gads',
        'consentCategory': 'T',
        'enableCookieConsent': true,
        'endpoint': {
          'scheme': 'https',
          'host': 'www.googleadservices.com/',
          'path': ''
        },
        'enable': [{
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['paypal', 'fetchTenantname']
        }, {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['false', 'isC2ToC3']
        }],
        'setup': {
          'scriptSrc': 'https://www.paypalobjects.com/martech/tm/paypal/3pjs/gtag/gtag.js',
          'preLoadScript': function preLoadScript(vendor, cb) {
            function gtagCommonSetup(vendor) {
              window.gDataLayer = window.gDataLayer || [];
              function gtag() {
                window.gDataLayer.push(arguments);
              }
              gtag('js', new Date());
              gtag('set', {
                anonymize_ip: true
              });
              gtag('consent', 'default', {
                ad_user_data: 'granted',
                ad_personalization: 'granted',
                ad_storage: 'granted',
                analytics_storage: 'granted'
              });
              if (vendor.mktConsentOptOut) {
                gtag('set', {
                  allow_ad_personalization_signals: false
                });
                gtag('consent', 'update', {
                  ad_user_data: 'denied',
                  ad_personalization: 'denied',
                  ad_storage: 'denied',
                  analytics_storage: 'denied'
                });
              }
              window.gtag = window.gtag || gtag;
            }
            var mktconf = window.mktconf;
            mktconf.gtagModules = mktconf.gtagModules || [];
            if (mktconf.gtagModules.length === 0) gtagCommonSetup(vendor);
            if (!mktconf.gtagModules.includes(vendor.name)) mktconf.gtagModules.push(vendor.name);
            var dataLayer = window.laDataLayer || {};
            var gadsMccRegion = dataLayer.region;
            switch (gadsMccRegion) {
              case 'na':
                window.gtag('config', 'AW-992191228');
                window.gtag('event', 'conversion', {
                  send_to: 'AW-992191228' + '/vTDjCL3nvv4CEPzFjtkD'
                });
                break;
              case 'apac':
                window.gtag('config', 'AW-965352860');
                window.gtag('event', 'conversion', {
                  send_to: 'AW-965352860' + '/K7FtCJDsl_4CEJy7qMwD'
                });
                break;
              case 'emea':
                window.gtag('config', 'AW-1006288171');
                window.gtag('event', 'conversion', {
                  send_to: 'AW-1006288171' + '/TUZCCNnXxP4CEKv66t8D'
                });
                break;
              case 'latam':
                window.gtag('config', 'AW-993701045');
                window.gtag('event', 'conversion', {
                  send_to: 'AW-993701045' + '/MgaHCP74vv4CELXZ6tkD'
                });
                break;
            }
            cb();
          }
        },
        'triggerEvent': function triggerEvent(vendor) {
          function gtagTriggerEvent(vendor) {
            var _gtag = window.gtag;
            var actionSrc = vendor.vars.event_action || 'conversion';
            if (_gtag) _gtag('event', actionSrc, vendor.vars);
          }
          return gtagTriggerEvent(vendor);
        },
        'component': 'all'
      };
      var li = {
        'name': 'li',
        'consentCategory': 'T',
        'enableCookieConsent': true,
        'enable': [{
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['paypal', 'fetchTenantname']
        }, {
          'type': 'fn',
          'name': 'conditionalValue',
          'args': ['false', 'isC2ToC3']
        }],
        'endpoint': {
          'scheme': 'https',
          'host': 'px.ads.linkedin.com',
          'path': '/collect/?'
        },
        'vars': {
          'pid': '2786969',
          'fmt': 'gif'
        }
      };
      var pd = {
        'name': 'pd',
        'consentCategory': 'T',
        'enableCookieConsent': true,
        'endpoint': {
          'scheme': 'https',
          'host': 'pi.pardot.com',
          'path': '/analytics/?'
        },
        'vars': {},
        'triggerEvent': function triggerEvent(vendor) {
          var vendorVars = vendor.vars || {};
          var host = location && location.host || '';
          vendorVars.piHostname = host + '/webapps/mpp/rest/pardot';
          window.piAId = vendorVars.piAId || 'piAId';
          window.piCId = vendorVars.piCId || 'piCId';
          window.piHostname = vendorVars.piHostname || 'go.pardot.com';
          var pardotScript = document.createElement('script');
          pardotScript.type = 'text/javascript';
          pardotScript.src = 'https://www.paypalobjects.com/paypalmktg/pardot/pd.js';
          var scripts = document.getElementsByTagName('script')[0];
          scripts.parentNode.insertBefore(pardotScript, scripts);
        }
      };
      mktconf.loadPageViews = function () {
        return ['fb_pgv', 'ga4_pgv', 'ga_pgv', 'li_pgv'];
      };
      mktconf.loadTagConfig = function (tagName) {
        return {
          fb_pgv: fb_pgv,
          ga4_pgv: ga4_pgv,
          ga_pgv: ga_pgv,
          li_pgv: li_pgv,
          pers_acc_upg_fin: pers_acc_upg_fin,
          biz_acc_su_end: biz_acc_su_end,
          pwd_recovery_start: pwd_recovery_start,
          pwd_recovery_end: pwd_recovery_end,
          xolite_end_1: xolite_end_1,
          mer_mx_installment: mer_mx_installment,
          pro_su_start: pro_su_start,
          pro_su_end_app: pro_su_end_app,
          pro_su_end_rev: pro_su_end_rev,
          pro_su_end_dec: pro_su_end_dec,
          biz_check_acc: biz_check_acc,
          biz_create_pwd: biz_create_pwd,
          biz_acc_su_start: biz_acc_su_start,
          biz_bus_info: biz_bus_info,
          biz_pers_info: biz_pers_info,
          pers_acc_upg_start: pers_acc_upg_start,
          biz_acc_su_minimal_acc: biz_acc_su_minimal_acc,
          biz_acc_su_minimal_oldflow: biz_acc_su_minimal_oldflow,
          oct_flow_start: oct_flow_start,
          oct_flow_end: oct_flow_end,
          ln_click: ln_click,
          form_submit: form_submit,
          pardot_im_event: pardot_im_event,
          brc_aoc_landing: brc_aoc_landing,
          scroll_event: scroll_event,
          ppcom_money_hub_viewed_event: ppcom_money_hub_viewed_event,
          ppcom_header_signin_signup_clicked: ppcom_header_signin_signup_clicked,
          ppcom_hero_button_clicked: ppcom_hero_button_clicked,
          setup_xo: setup_xo,
          cape_cc_application_start: cape_cc_application_start,
          cape_cc_application_finish: cape_cc_application_finish,
          cape_cc_application_approved: cape_cc_application_approved,
          credit_app_start_new: credit_app_start_new,
          credit_app_succ_new: credit_app_succ_new,
          appr_uk_2: appr_uk_2,
          succ_end_uk_2: succ_end_uk_2,
          start_uk_2: start_uk_2,
          dec_end_uk: dec_end_uk,
          fundraiser_setCharity_1: fundraiser_setCharity_1,
          fundraiser_setCharity_2: fundraiser_setCharity_2,
          fundraiser_setCharity_3: fundraiser_setCharity_3,
          donate_cause: donate_cause,
          xolite_start: xolite_start,
          xolite_end: xolite_end,
          checkout_payin4_start: checkout_payin4_start,
          checkout_payin4_finish: checkout_payin4_finish,
          checkout_payin3_finish: checkout_payin3_finish,
          checkout_payin3_start: checkout_payin3_start,
          checkout_bnpl_iiw_start: checkout_bnpl_iiw_start,
          checkout_bnpl_iiw_finish: checkout_bnpl_iiw_finish,
          checkout_payin30_start: checkout_payin30_start,
          checkout_payin30_finish: checkout_payin30_finish,
          xolite_start_1: xolite_start_1,
          setup_xo_standard: setup_xo_standard,
          mac_zettle_consent: mac_zettle_consent,
          pers_acc_su_fin: pers_acc_su_fin,
          ztl_su_start: ztl_su_start,
          ztl_su_finish: ztl_su_finish,
          ztl_su_finish_reg: ztl_su_finish_reg,
          credit_app_start: credit_app_start,
          credit_app_succ: credit_app_succ,
          credit_app_decl: credit_app_decl,
          credit_psu_start: credit_psu_start,
          start_uk: start_uk,
          appr_uk: appr_uk,
          succ_end_uk: succ_end_uk,
          credit_app_per_info: credit_app_per_info,
          credit_app_terms: credit_app_terms,
          bizdebit_start: bizdebit_start,
          bizdebit_aprv: bizdebit_aprv,
          bizdebit_aprv_2: bizdebit_aprv_2,
          mac_xo: mac_xo,
          chk_doc_click: chk_doc_click,
          pp_early_dd_finish: pp_early_dd_finish,
          bnpl_msg: bnpl_msg,
          xo_start: xo_start,
          xo_end: xo_end,
          pp_early_dd_start: pp_early_dd_start,
          honey_mobile: honey_mobile,
          honey_desktop: honey_desktop,
          honey_landing: honey_landing,
          inv_cr8_start: inv_cr8_start,
          inv_cr8_end: inv_cr8_end,
          inv_cr8_dt_start: inv_cr8_dt_start,
          inv_cr8_dt_end: inv_cr8_dt_end,
          inv_pay_finish: inv_pay_finish,
          mpp_mp_start: mpp_mp_start,
          land_uk: land_uk,
          rd_curr: rd_curr,
          con_sel: con_sel,
          mer_sel: mer_sel,
          mpp_404: mpp_404,
          acc_sel: acc_sel,
          borderless_cm_form_submit: borderless_cm_form_submit,
          pp_partner_cnt_finish: pp_partner_cnt_finish,
          pp_merchant_cnt_start: pp_merchant_cnt_start,
          pp_merchant_cnt_finish: pp_merchant_cnt_finish,
          con_sel_click: con_sel_click,
          mer_sel_click: mer_sel_click,
          prod_sel_pageview: prod_sel_pageview,
          mpp_offer: mpp_offer,
          pp_home_land: pp_home_land,
          emailClick: emailClick,
          outboundLinkClick: outboundLinkClick,
          videoPlay: videoPlay,
          videoPlay_youTube: videoPlay_youTube,
          downloadFiles: downloadFiles,
          navigationTracking_head: navigationTracking_head,
          navigationTracking_foot: navigationTracking_foot,
          qrc_su_start: qrc_su_start,
          qrc_su_fin: qrc_su_fin,
          bnpl_book_meeting: bnpl_book_meeting,
          payin4_landing_page: payin4_landing_page,
          pp_merchant_ent_cnt_start: pp_merchant_ent_cnt_start,
          pp_merchant_ent_cnt_finish: pp_merchant_ent_cnt_finish,
          download_ios_app: download_ios_app,
          download_android_app: download_android_app,
          mpp_partner_checkout: mpp_partner_checkout,
          mpp_fraud_sec_form_start: mpp_fraud_sec_form_start,
          mac_request_money: mac_request_money,
          pardot_mpp_event: pardot_mpp_event,
          mpp_mobile_apps: mpp_mobile_apps,
          mpp_qrc_dwnld: mpp_qrc_dwnld,
          mpp_uk_acceptpymt: mpp_uk_acceptpymt,
          mpp_uk_business: mpp_uk_business,
          mpp_uk_enterprise_reg: mpp_uk_enterprise_reg,
          mpp_de_expressxo: mpp_de_expressxo,
          mpp_merchfees_it: mpp_merchfees_it,
          pardot_mpp_home_page: pardot_mpp_home_page,
          landing: landing,
          pardot_mpp_contact_sales: pardot_mpp_contact_sales,
          smart_chat: smart_chat,
          mpp_master_creditcard: mpp_master_creditcard,
          mpp_cshbck_master_card: mpp_cshbck_master_card,
          mpp_spotify_premium_landing: mpp_spotify_premium_landing,
          pp_merchant_ent_cnt_start_new: pp_merchant_ent_cnt_start_new,
          mpp_googleplay_getgamin: mpp_googleplay_getgamin,
          pp_merchant_ent_cnt_finish_new: pp_merchant_ent_cnt_finish_new,
          mpp_partner_enterprise_form_submit: mpp_partner_enterprise_form_submit,
          mpp_enterprise_roadmap_form: mpp_enterprise_roadmap_form,
          mpp_download_playbook_form: mpp_download_playbook_form,
          mpp_crypto_stable_coin_start: mpp_crypto_stable_coin_start,
          ppcom_page_viewed_im_events: ppcom_page_viewed_im_events,
          mpp_customize_ai_form_submit: mpp_customize_ai_form_submit,
          mpp_innovation_form_submit: mpp_innovation_form_submit,
          mpp_consumer_app_dwnld_uk: mpp_consumer_app_dwnld_uk,
          mpp_hero_ebook_dwnld_au: mpp_hero_ebook_dwnld_au,
          mpp_ecommerce_report_dwnld_au: mpp_ecommerce_report_dwnld_au,
          merc_acc_summ: merc_acc_summ,
          biz_acc_su_end_mep: biz_acc_su_end_mep,
          pers_acc_upg_fin_mep: pers_acc_upg_fin_mep,
          biz_acc_su_get_started: biz_acc_su_get_started,
          biz_acc_su_end_2: biz_acc_su_end_2,
          mer_appcntr: mer_appcntr,
          mac_landing: mac_landing,
          mac_zettle: mac_zettle,
          mac_bonanza: mac_bonanza,
          mac_grailed: mac_grailed,
          mac_wish: mac_wish,
          mac_google: mac_google,
          mac_walmart: mac_walmart,
          mac_swappa: mac_swappa,
          mac_request_money_get_started: mac_request_money_get_started,
          mer_itx_start: mer_itx_start,
          mer_itx_end: mer_itx_end,
          cons_add_bank_start: cons_add_bank_start,
          cons_add_bank_end_v2: cons_add_bank_end_v2,
          cons_add_card_start: cons_add_card_start,
          cons_add_card_end: cons_add_card_end,
          mer_add_bank_start: mer_add_bank_start,
          mer_add_bank_end_v2: mer_add_bank_end_v2,
          mer_add_card_start: mer_add_card_start,
          mer_add_card_end: mer_add_card_end,
          pers_acc_su_fin_reusable: pers_acc_su_fin_reusable,
          setup_xo_1: setup_xo_1,
          pers_acc_su_start: pers_acc_su_start,
          pers_acc_su_start_new: pers_acc_su_start_new,
          guest_acc_upg_start: guest_acc_upg_start,
          guest_acc_upg_fin: guest_acc_upg_fin,
          pers_acc_su_fin_dis: pers_acc_su_fin_dis,
          xoom_pers_acc_su_fin: xoom_pers_acc_su_fin,
          xoom_pers_acc_su_start: xoom_pers_acc_su_start,
          xoom_pers_acc_su_fin_2: xoom_pers_acc_su_fin_2,
          acc_su_start_edison: acc_su_start_edison,
          acc_su_fin_edison: acc_su_fin_edison,
          p2p_send_mon_start: p2p_send_mon_start,
          req_mon_start: req_mon_start,
          req_mon_fin: req_mon_fin,
          p2p_send_mon: p2p_send_mon,
          p2p_send_mon_int: p2p_send_mon_int,
          p2p_send_gift: p2p_send_gift,
          p2p_buy: p2p_buy,
          p2p_mer_req_mny_start: p2p_mer_req_mny_start,
          p2p_mer_req_mny_fin: p2p_mer_req_mny_fin,
          p2p_mer_send_mny_start: p2p_mer_send_mny_start,
          p2p_mer_send_mny_fin: p2p_mer_send_mny_fin,
          pad_enroll: pad_enroll,
          pypl_savings_userinfo: pypl_savings_userinfo,
          mp_send_amt_ga: mp_send_amt_ga,
          mp_send_note_ga: mp_send_note_ga,
          mp_send_review_ga: mp_send_review_ga,
          mp_create_pref_ga: mp_create_pref_ga,
          mp_create_desc_ga: mp_create_desc_ga,
          mp_create_prev_ga: mp_create_prev_ga,
          mp_create_prepub_ga: mp_create_prepub_ga,
          chipIn_send_guest: chipIn_send_guest,
          chipIn_end_guest: chipIn_end_guest,
          mp_fundraiser_create_finish: mp_fundraiser_create_finish,
          mp_fundraiser_withdraw_start: mp_fundraiser_withdraw_start,
          mp_fundraiser_withdraw_finish: mp_fundraiser_withdraw_finish,
          landing_mpp_workingcapital: landing_mpp_workingcapital,
          account_selection_get_started_clicked: account_selection_get_started_clicked,
          ppcms_payin4_contactsales_au: ppcms_payin4_contactsales_au,
          ppdg_land: ppdg_land,
          ppdg_txn_start: ppdg_txn_start,
          ppdg_txn_end: ppdg_txn_end,
          ppme_start: ppme_start,
          ppme_end: ppme_end,
          pers_acc_su_fin_new: pers_acc_su_fin_new,
          pers_acc_su_fin_new_1: pers_acc_su_fin_new_1,
          psu_credit_succ: psu_credit_succ,
          psu_credit_decl: psu_credit_decl,
          tesla_su_create: tesla_su_create,
          tesla_su_create_1: tesla_su_create_1,
          tesla_su_addcard_start: tesla_su_addcard_start,
          tesla_su_addcard_fin: tesla_su_addcard_fin,
          tesla_su_addbank_start: tesla_su_addbank_start,
          tesla_su_addbank_fin: tesla_su_addbank_fin,
          tesla_su_buy: tesla_su_buy,
          ppcom_intent_selection: ppcom_intent_selection,
          ppcom_onboard_flow_details_tracking: ppcom_onboard_flow_details_tracking,
          ppcom_onboard_flow_phone_entry_tracking: ppcom_onboard_flow_phone_entry_tracking,
          ppcom_onboard_flow_phone_confirmation_tracking: ppcom_onboard_flow_phone_confirmation_tracking,
          ppcom_onboard_flow_password_details_tracking: ppcom_onboard_flow_password_details_tracking,
          ppcom_onboard_flow_personal_info_tracking: ppcom_onboard_flow_personal_info_tracking,
          ppcom_onboard_flow_account_success_tracking: ppcom_onboard_flow_account_success_tracking,
          qrc_su_fin_2: qrc_su_fin_2,
          save_pypl_application_start: save_pypl_application_start,
          finishline_offers: finishline_offers,
          save_offers: save_offers,
          shop_now: shop_now,
          sb_shop_now: sb_shop_now,
          sb_save_offers: sb_save_offers,
          cons_acc_summ: cons_acc_summ,
          ppcom_landing_summary_page: ppcom_landing_summary_page,
          crypto_landing_page: crypto_landing_page,
          crypto_start_activation: crypto_start_activation,
          crypto_finish_activation: crypto_finish_activation,
          crypto_finish_purchase: crypto_finish_purchase,
          crypto_finish_sell: crypto_finish_sell,
          crypto_finish_first_purchase: crypto_finish_first_purchase,
          ccfullsu_start: ccfullsu_start,
          ccfullsu_end: ccfullsu_end,
          ccfullact_start: ccfullact_start,
          ccfullact_end: ccfullact_end,
          acc_su_consent_edison: acc_su_consent_edison,
          biz_acc_su_start_new: biz_acc_su_start_new,
          biz_acc_su_minimal_unified: biz_acc_su_minimal_unified,
          biz_acc_su_start_new_1: biz_acc_su_start_new_1,
          biz_acc_su_minimal_unified_1: biz_acc_su_minimal_unified_1,
          zettle_signup_start_uk: zettle_signup_start_uk,
          zettle_signup_finish_uk: zettle_signup_finish_uk,
          cons_add_bank_end_v1: cons_add_bank_end_v1,
          mer_add_bank_end_v1: mer_add_bank_end_v1,
          start: start,
          approved: approved,
          declined: declined,
          ineligible: ineligible,
          funded: funded,
          start_new: start_new,
          ineligible_new: ineligible_new,
          funded_new: funded_new,
          approved_new: approved_new,
          declined_new: declined_new,
          prox_su_end: prox_su_end,
          prox_txn_end: prox_txn_end
        }[tagName];
      };
      mktconf.loadVendorDefault = function (vendor) {
        return {
          dc: dc,
          gads: gads,
          ga: ga,
          fb: fb,
          li: li,
          ga4: ga4,
          pd: pd,
          adobe: adobe
        }[vendor];
      };
      mktconf.loadTags = function (comp) {
        return {
          activationnodeweb: ['pers_acc_upg_fin', 'biz_acc_su_end'],
          addtrackingnodeweb: [],
          authchallengenodeweb: [],
          authnodeweb: ['pwd_recovery_start', 'pwd_recovery_end'],
          bankingbundlenodeweb: [],
          billingnodeweb: ['xolite_end_1'],
          billinguinodeweb: [],
          bizaccountingnodeweb: [],
          bizactivitynodeweb: [],
          bizcomponentsnodeweb: [],
          bizlistingnodeweb: [],
          bizmanagenodeweb: ['mer_mx_installment'],
          bizmanageusersnodeweb: [],
          bizmoneynodeweb: [],
          bizperformancenodeweb: [],
          bizprofilenodeweb: [],
          bizprovisionnodeweb: [],
          bizreportingnodeweb: [],
          bizsignupnodeweb: ['pro_su_start', 'pro_su_end_app', 'pro_su_end_rev', 'pro_su_end_dec', 'biz_acc_su_end', 'pers_acc_upg_fin', 'biz_check_acc', 'biz_create_pwd', 'biz_acc_su_start', 'biz_bus_info', 'biz_pers_info', 'pers_acc_upg_start', 'biz_acc_su_minimal_acc', 'biz_acc_su_minimal_oldflow'],
          biztransactionsnodeweb: [],
          bizwalletnodeweb: ['oct_flow_start', 'oct_flow_end'],
          brcappnodeweb: ['ln_click', 'form_submit', 'pardot_im_event', 'brc_aoc_landing', 'scroll_event', 'ppcom_money_hub_viewed_event', 'ppcom_header_signin_signup_clicked', 'ppcom_hero_button_clicked'],
          btdocsnodeweb: [],
          btpwebsite: [],
          buttonfactorynodeweb: ['setup_xo'],
          capeuinodeweb: ['cape_cc_application_start', 'cape_cc_application_finish', 'cape_cc_application_approved', 'credit_app_start_new', 'credit_app_succ_new', 'appr_uk_2', 'succ_end_uk_2', 'start_uk_2', 'dec_end_uk'],
          causefundraisernodeweb: ['fundraiser_setCharity_1', 'fundraiser_setCharity_2', 'fundraiser_setCharity_3', 'donate_cause'],
          causemisspiggynodeweb: [],
          checkoutuinodeweb: ['xolite_start', 'xolite_end', 'checkout_payin4_start', 'checkout_payin4_finish', 'checkout_payin3_finish', 'checkout_payin3_start', 'checkout_bnpl_iiw_start', 'checkout_bnpl_iiw_finish', 'checkout_payin30_start', 'checkout_payin30_finish', 'xolite_start_1', 'xolite_end_1'],
          compliancedashboardweb: [],
          commercesetupnodeweb: ['biz_acc_su_end', 'pers_acc_upg_fin', 'setup_xo_standard'],
          compgilersnodeweb: [],
          connectnodeweb: ['mac_zettle_consent'],
          consonbdnodeweb: ['pers_acc_su_fin'],
          conspartneronbnodeweb: [],
          coralnodeweb: [],
          cponboardingnodeweb: ['ztl_su_start', 'ztl_su_finish', 'ztl_su_finish_reg'],
          crcacqportablenodeweb: [],
          crcinstacqnodeweb: [],
          crcrevsvcnodeweb: [],
          creditapplyweb: ['credit_app_start', 'credit_app_succ', 'credit_app_decl', 'credit_psu_start', 'start_uk', 'appr_uk', 'succ_end_uk', 'dec_end_uk', 'credit_app_per_info', 'credit_app_terms', 'scroll_event'],
          creditloanbldrnodeweb: [],
          creditnodeweb: [],
          cspreportnodeweb: [],
          debitcardnodeweb: ['bizdebit_start', 'bizdebit_aprv', 'bizdebit_aprv_2'],
          devdashnodeweb: [],
          devdiscoverynodeweb: ['mac_xo', 'chk_doc_click'],
          devdoc: [],
          developerstudionodeweb: [],
          directdepositnodeweb: ['pp_early_dd_finish'],
          disputesnodeweb: [],
          donatenodeweb: [],
          dpnodeweb: [],
          dualcontrolnodeweb: [],
          financeportalnodeweb: ['ln_click', 'bnpl_msg'],
          fundsmanagementnodeweb: [],
          growthnodeweb: [],
          heliosnodeweb: [],
          helpcenternodeweb: [],
          hermesnodeweb: ['xo_start', 'xo_end', 'xolite_start_1'],
          homeinfonodeweb: ['pp_early_dd_start'],
          honeyapp: ['honey_mobile', 'honey_desktop', 'honey_landing'],
          idassurancenodeweb: [],
          identityappsnodeweb: [],
          invoicingnodeweb: ['inv_cr8_start', 'inv_cr8_end', 'inv_cr8_dt_start', 'inv_cr8_dt_end', 'inv_pay_finish'],
          latinumnodeweb: [],
          marketingnodeweb: ['mpp_mp_start', 'land_uk', 'form_submit', 'rd_curr', 'con_sel', 'mer_sel', 'mpp_404', 'acc_sel', 'borderless_cm_form_submit', 'pp_partner_cnt_finish', 'pp_merchant_cnt_start', 'pp_merchant_cnt_finish', 'con_sel_click', 'mer_sel_click', 'prod_sel_pageview', 'mpp_offer', 'pp_home_land', 'scroll_event', 'emailClick', 'outboundLinkClick', 'videoPlay', 'videoPlay_youTube', 'downloadFiles', 'navigationTracking_head', 'navigationTracking_foot', 'ln_click', 'qrc_su_start', 'qrc_su_fin', 'bnpl_book_meeting', 'payin4_landing_page', 'pp_merchant_ent_cnt_start', 'pp_merchant_ent_cnt_finish', 'download_ios_app', 'download_android_app', 'mac_xo', 'mpp_partner_checkout', 'mpp_fraud_sec_form_start', 'mac_request_money', 'pardot_mpp_event', 'mpp_mobile_apps', 'mpp_qrc_dwnld', 'mpp_uk_acceptpymt', 'mpp_uk_business', 'mpp_uk_enterprise_reg', 'mpp_de_expressxo', 'mpp_merchfees_it', 'pardot_mpp_home_page', 'landing', 'pardot_mpp_contact_sales', 'smart_chat', 'mpp_master_creditcard', 'mpp_cshbck_master_card', 'mpp_spotify_premium_landing', 'pp_merchant_ent_cnt_start_new', 'mpp_googleplay_getgamin', 'pp_merchant_ent_cnt_finish_new', 'mpp_partner_enterprise_form_submit', 'mpp_enterprise_roadmap_form', 'mpp_download_playbook_form', 'mpp_crypto_stable_coin_start', 'ppcom_page_viewed_im_events', 'ppcom_hero_button_clicked', 'ppcom_header_signin_signup_clicked', 'mpp_customize_ai_form_submit', 'mpp_innovation_form_submit', 'mpp_consumer_app_dwnld_uk', 'mpp_hero_ebook_dwnld_au', 'mpp_ecommerce_report_dwnld_au'],
          mepnodeweb: ['merc_acc_summ', 'biz_acc_su_end_mep', 'pers_acc_upg_fin_mep', 'biz_acc_su_get_started', 'biz_acc_su_end_2'],
          merchantbillingnodeweb: [],
          merchanthubnodeweb: ['mer_appcntr', 'biz_acc_su_end_mep', 'pers_acc_upg_fin_mep', 'mac_landing', 'mac_zettle', 'mac_xo', 'mac_bonanza', 'mac_grailed', 'mac_wish', 'mac_google', 'mac_walmart', 'mac_swappa', 'mpp_partner_checkout', 'mac_request_money', 'pardot_im_event', 'mac_request_money_get_started'],
          merchantsignupnodeweb: ['biz_acc_su_start', 'biz_acc_su_end', 'pers_acc_upg_start', 'pers_acc_upg_fin', 'biz_pers_info', 'biz_bus_info', 'biz_create_pwd', 'biz_check_acc'],
          merchmoneynodeweb: ['mer_itx_start', 'mer_itx_end'],
          modularcheckoutnodeweb: [],
          moneynodeweb: ['cons_add_bank_start', 'cons_add_bank_end_v2', 'cons_add_card_start', 'cons_add_card_end', 'mer_add_bank_start', 'mer_add_bank_end_v2', 'mer_add_card_start', 'mer_add_card_end', 'pers_acc_su_fin_reusable'],
          mppnodeweb: ['mpp_mp_start', 'land_uk', 'form_submit', 'rd_curr', 'con_sel', 'mer_sel', 'mpp_404', 'acc_sel', 'borderless_cm_form_submit', 'pp_partner_cnt_finish', 'pp_merchant_cnt_start', 'pp_merchant_cnt_finish', 'con_sel_click', 'mer_sel_click', 'prod_sel_pageview', 'mpp_offer', 'pp_home_land', 'scroll_event', 'emailClick', 'outboundLinkClick', 'videoPlay', 'videoPlay_youTube', 'downloadFiles', 'navigationTracking_head', 'navigationTracking_foot', 'ln_click', 'qrc_su_start', 'qrc_su_fin', 'bnpl_book_meeting', 'payin4_landing_page', 'pp_merchant_ent_cnt_start', 'pp_merchant_ent_cnt_finish', 'download_ios_app', 'download_android_app', 'mac_xo', 'mpp_partner_checkout', 'mpp_fraud_sec_form_start', 'mac_request_money', 'pardot_mpp_event', 'mpp_mobile_apps', 'mpp_qrc_dwnld', 'mpp_uk_acceptpymt', 'mpp_uk_business', 'mpp_uk_enterprise_reg', 'mpp_de_expressxo', 'mpp_merchfees_it', 'pardot_mpp_home_page', 'landing', 'pardot_mpp_contact_sales', 'smart_chat', 'mpp_master_creditcard', 'mpp_cshbck_master_card', 'mpp_spotify_premium_landing', 'pp_merchant_ent_cnt_start_new', 'mpp_googleplay_getgamin', 'pp_merchant_ent_cnt_finish_new', 'mpp_partner_enterprise_form_submit', 'mpp_enterprise_roadmap_form', 'mpp_download_playbook_form', 'mpp_crypto_stable_coin_start', 'ppcom_page_viewed_im_events', 'ppcom_hero_button_clicked', 'ppcom_header_signin_signup_clicked', 'mpp_customize_ai_form_submit', 'mpp_innovation_form_submit', 'ppcom_money_hub_viewed_event'],
          nocodenodeweb: ['setup_xo_1'],
          onboardingnodeweb: ['pers_acc_su_start', 'pers_acc_su_start_new', 'guest_acc_upg_start', 'guest_acc_upg_fin', 'pers_acc_su_fin_dis', 'xoom_pers_acc_su_fin', 'xoom_pers_acc_su_start', 'xoom_pers_acc_su_fin_2', 'acc_su_start_edison', 'acc_su_fin_edison'],
          p2pnodeweb: ['p2p_send_mon_start', 'req_mon_start', 'req_mon_fin', 'p2p_send_mon', 'p2p_send_mon_int', 'p2p_send_gift', 'p2p_buy', 'p2p_mer_req_mny_start', 'p2p_mer_req_mny_fin', 'p2p_mer_send_mny_start', 'p2p_mer_send_mny_fin'],
          padnodeweb: ['pad_enroll'],
          pepnodeweb: [],
          pixnodeweb: [],
          policydashboardnodeweb: ['pypl_savings_userinfo'],
          policydashboardweb: ['pypl_savings_userinfo'],
          poolsnodeweb: ['mp_send_amt_ga', 'mp_send_note_ga', 'mp_send_review_ga', 'mp_create_pref_ga', 'mp_create_desc_ga', 'mp_create_prev_ga', 'mp_create_prepub_ga', 'chipIn_send_guest', 'chipIn_end_guest', 'mp_fundraiser_create_finish', 'mp_fundraiser_withdraw_start', 'mp_fundraiser_withdraw_finish'],
          ppapireference: [],
          ppcmsnodeweb: ['mpp_mp_start', 'land_uk', 'form_submit', 'rd_curr', 'con_sel', 'mer_sel', 'mpp_404', 'acc_sel', 'borderless_cm_form_submit', 'pp_partner_cnt_finish', 'pp_merchant_cnt_start', 'pp_merchant_cnt_finish', 'con_sel_click', 'mer_sel_click', 'prod_sel_pageview', 'mpp_offer', 'pp_home_land', 'scroll_event', 'emailClick', 'outboundLinkClick', 'videoPlay', 'videoPlay_youTube', 'downloadFiles', 'navigationTracking_head', 'navigationTracking_foot', 'ln_click', 'qrc_su_start', 'qrc_su_fin', 'bnpl_book_meeting', 'payin4_landing_page', 'pp_merchant_ent_cnt_start', 'pp_merchant_ent_cnt_finish', 'download_ios_app', 'download_android_app', 'mac_xo', 'mpp_partner_checkout', 'mpp_fraud_sec_form_start', 'mac_request_money', 'pardot_mpp_event', 'mpp_mobile_apps', 'mpp_qrc_dwnld', 'mpp_uk_acceptpymt', 'mpp_uk_business', 'mpp_uk_enterprise_reg', 'mpp_de_expressxo', 'mpp_merchfees_it', 'pardot_mpp_home_page', 'landing', 'pardot_mpp_contact_sales', 'smart_chat', 'mpp_master_creditcard', 'mpp_cshbck_master_card', 'mpp_spotify_premium_landing', 'pp_merchant_ent_cnt_start_new', 'mpp_googleplay_getgamin', 'pp_merchant_ent_cnt_finish_new', 'mpp_partner_enterprise_form_submit', 'mpp_enterprise_roadmap_form', 'mpp_download_playbook_form', 'mpp_crypto_stable_coin_start', 'ppcom_page_viewed_im_events', 'ppcom_hero_button_clicked', 'ppcom_header_signin_signup_clicked', 'landing_mpp_workingcapital', 'mpp_customize_ai_form_submit', 'mpp_innovation_form_submit', 'account_selection_get_started_clicked', 'ppcom_money_hub_viewed_event', 'ppcms_payin4_contactsales_au'],
          ppdgnodeweb: ['ppdg_land', 'ppdg_txn_start', 'ppdg_txn_end'],
          ppme: ['ppme_start', 'ppme_end'],
          ppmenodeweb: [],
          privacynodeweb: [],
          profilenodeweb: [],
          progressivenodeweb: ['pers_acc_su_fin', 'pers_acc_su_fin_new', 'pers_acc_su_fin_new_1', 'pers_acc_su_start', 'pers_acc_su_start_new', 'psu_credit_succ', 'psu_credit_decl', 'tesla_su_create', 'tesla_su_create_1', 'tesla_su_addcard_start', 'tesla_su_addcard_fin', 'tesla_su_addbank_start', 'tesla_su_addbank_fin', 'tesla_su_buy', 'ppcom_page_viewed_im_events', 'ppcom_hero_button_clicked', 'ppcom_header_signin_signup_clicked', 'ppcom_intent_selection', 'ppcom_onboard_flow_details_tracking', 'ppcom_onboard_flow_phone_entry_tracking', 'ppcom_onboard_flow_phone_confirmation_tracking', 'ppcom_onboard_flow_password_details_tracking', 'ppcom_onboard_flow_personal_info_tracking', 'ppcom_onboard_flow_account_success_tracking'],
          qrcnodeweb: ['qrc_su_fin_2'],
          referralsnodeweb: [],
          reportingnodeweb: [],
          rescenternodeweb: [],
          rescenterhomenodeweb: [],
          restoreaccessnodeweb: [],
          rewardsnodeweb: [],
          risksimmerchantnodeweb: [],
          risksimadvmerchnodeweb: [],
          savingsnodeweb: ['save_pypl_application_start'],
          securitysettingnodeweb: [],
          selfhelpnodeweb: [],
          selfservicenodeweb: [],
          settingsnodeweb: [],
          shiplabel: [],
          shippingnodeweb: [],
          shoplistnodeweb: ['finishline_offers', 'save_offers', 'shop_now', 'sb_shop_now', 'sb_save_offers'],
          smartchat: ['smart_chat'],
          smartchatnodeweb: [],
          smartcomponentnodeweb: [],
          smarthelpnodeweb: ['pardot_im_event'],
          smcnodeweb: [],
          summarynodeweb: ['cons_acc_summ', 'ln_click', 'scroll_event', 'pers_acc_su_fin_reusable', 'ppcom_landing_summary_page'],
          tagmanagernodeweb: [],
          tradingnodeweb: ['crypto_landing_page', 'crypto_start_activation', 'crypto_finish_activation', 'crypto_finish_purchase', 'crypto_finish_sell', 'crypto_finish_first_purchase'],
          ucsnodeweb: ['ccfullsu_start', 'ccfullsu_end', 'ccfullact_start', 'ccfullact_end'],
          unifiedloginnodeweb: ['acc_su_consent_edison'],
          unifiedonboardnodeweb: ['biz_acc_su_start_new', 'biz_acc_su_minimal_unified', 'biz_acc_su_start_new_1', 'biz_acc_su_minimal_unified_1', 'zettle_signup_start_uk', 'zettle_signup_finish_uk'],
          unifiedtxnmngrnodeweb: [],
          virtualterminalnodeweb: [],
          walletexpnodeweb: ['cons_acc_summ', 'ln_click', 'cons_add_bank_start', 'cons_add_bank_end_v1', 'cons_add_card_start', 'cons_add_card_end', 'mer_add_bank_start', 'mer_add_bank_end_v1', 'mer_add_card_start', 'mer_add_card_end', 'pers_acc_su_fin_reusable'],
          workingcapitalnodeweb: ['landing', 'start', 'approved', 'declined', 'ineligible', 'funded', 'start_new', 'ineligible_new', 'funded_new', 'approved_new', 'declined_new'],
          xoonboardingnodeweb: ['xo_start', 'xo_end', 'prox_su_end', 'prox_txn_end']
        }[comp];
      };
      mktconf.loadJs = function (comp) {
        var compJSMap = {
          'brcappnodeweb': ['adobe', 'ga4'],
          'ppcmsnodeweb': ['adobe', 'ga4'],
          'progressivenodeweb': ['adobe', 'ga4'],
          'mppnodeweb': ['adobe', 'ga4'],
          'marketingnodeweb': ['adobe', 'ga4'],
          'summarynodeweb': ['adobe', 'ga4'],
          'btpwebsite': ['ga4'],
          'capeuinodeweb': ['ga4'],
          'checkoutuinodeweb': ['ga4'],
          'cponboardingnodeweb': ['ga4'],
          'creditapplyweb': ['ga4'],
          'hermesnodeweb': ['ga4'],
          'invoicingnodeweb': ['ga4'],
          'moneynodeweb': ['ga4'],
          'p2pnodeweb': ['ga4'],
          'ucsnodeweb': ['ga4'],
          'xoonboardingnodeweb': ['ga4']
        };
        var vendors = compJSMap[comp] || [];
        var vCount = vendors.length;
        vendors.push('dc', 'ga', 'gads');
        vCount += 1;
        return {
          vendors: vendors,
          vCount: vCount
        };
      };
    })();

})();
